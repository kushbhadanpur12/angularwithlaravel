import { Component, OnInit, Input, Output } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-errormessage',
  templateUrl: './errormessage.component.html',
  styleUrls: ['./errormessage.component.css']
})

export class ErrormessageComponent implements OnInit {

 @Input() Clientmessage:any;
 @Input() clientClass:any;

  constructor() { }

	
  ngOnInit() {
		
  }
  
   closeErrormsg(){
     $(".err").hide();
   }
}
