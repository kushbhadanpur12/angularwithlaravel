import { Component, OnInit } from '@angular/core';
import { CheckoutService } from '../../services/checkout.service';
declare var $:any;
declare var loadFinanceDetails: any;
declare var FinanceDetails: any;

declare var jquery:any;
declare var $:any;

@Component({
  selector: 'app-deko',
  templateUrl: './deko.component.html',
  styleUrls: ['./deko.component.css']
})
export class DekoComponent implements OnInit {

  public fname:any;
  public lname:any;
  public email:any;
  public orderid:any;
  public dekodata:any;
  activeDeko = [];
  activeDekoPercent = [];
  activeDekoCode:any;
  var_deposit_percentage:any;
  var_cost_of_goods:any;
  userData:any;
  public p2:number;
  public p3:number;
  public p4:number;

  constructor(private checkout: CheckoutService,) { }


  ngOnInit() {
    let tokenkey = localStorage.getItem('tokenkey');
    let tokenid = localStorage.getItem('tokenid');

    let para3 = '?tokenid='+tokenid+'&tokenkey='+tokenkey;
	
      //this.checkout.getOrderDetailsService(para3).subscribe( (response) => {this.var_cost_of_goods = response.orderDetails.total;console.log('aaaaaaaaaaaaaaaa');console.log(response);console.log('aaaaaaaaaaaaaaaa');});
	  
      this.checkout.getCustomerDataWithoutLogin(para3).
      subscribe((response) => { this.userData =  response.userbilling;
	 
          if(this.userData){
            this.fname = this.userData.fname;
            this.lname = this.userData.lname;
          }
           this.email = response.emailID;
     });
	 

     this.checkout.getOrdercustomerid(para3).subscribe((response) => { response;
         this.orderid  = response.orderid;
	  });
	  
	var pid = $('input[name="methodId"]:checked').val();
	let para = '?paymentid='+pid+'&tokenid='+tokenid+'&tokenkey='+tokenkey;
	this.checkout.getSelectedPaymentMethodDetils(para).subscribe((response) => {
		this.dekodata =  response;
		var Array = response.payment_detail.products.status;
		var counter=0;
		for (var items in Array ){
			var arr = { "deko": response.deko[Array[items]], "min_deposite": response.payment_detail.products.min_deposite[Array[items]], "max_deposite": response.payment_detail.products.max_deposite[Array[items]], "step": response.payment_detail.products.step[Array[items]] };
			this.activeDeko.push( arr );
			if(counter==0){
				if(!response.payment_detail.products.step[Array[items]]){
					response.payment_detail.products.step[Array[items]] = 10;
				}
				for(var i=response.payment_detail.products.min_deposite[Array[items]];i<=response.payment_detail.products.max_deposite[Array[items]];(i=i+response.payment_detail.products.step[Array[items]])){
					this.activeDekoPercent.push(i);
					this.activeDekoCode = Array[items];
					this.var_deposit_percentage = i;
				}
			}
			counter = counter+1;
		}
		var thiss = this;
		//thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
		thiss.var_cost_of_goods = parseFloat($(":input[name='ordertotalh']").val());
		thiss.calculateAmounts(this.activeDekoCode,thiss.var_cost_of_goods,this.var_deposit_percentage,0);
	});		   
  }
    calculatePercentage(event){
		var val = event.target.value;
		var min_deposite = parseInt($('select#var_product_type option[value="'+val+'"]').attr("min_deposite"));
		var max_deposite = parseInt($('select#var_product_type option[value="'+val+'"]').attr("max_deposite"));
		var step = parseInt($('select#var_product_type option[value="'+val+'"]').attr("step"));
		if(!step){
			step = 10;
		}
		this.var_deposit_percentage = min_deposite;
		
		this.activeDekoPercent = [];
		for(var i=min_deposite;i<=max_deposite;(i=i+step)){
			this.activeDekoPercent.push(i);
			this.activeDekoCode = val;
		}
		var thiss = this;
		thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
    	thiss.calculateAmounts(this.activeDekoCode,thiss.p2,this.var_deposit_percentage,0);
	}

    calculateByPercentage(event){
		this.activeDekoCode = $(":input[name='var_product_type']").val();
		this.var_deposit_percentage = parseFloat(event.target.value);
		var thiss = this;
		thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
    	thiss.calculateAmounts(this.activeDekoCode,thiss.p2,this.var_deposit_percentage,0);
	}
	
		calculateAmounts(var_product_type='', var_cost_of_goods: number=0, var_deposit_percentage: number=0, var_deposit_amount: number=0) {
		
		var p1 = var_product_type;
		var thiss = this;
		
		this.p2 = parseFloat(var_cost_of_goods.toFixed(2));
		this.p3 = parseFloat(var_deposit_percentage.toFixed(2));
		this.p4 = parseFloat(var_deposit_amount.toFixed(1));;
	
		if (p1 == '' || isNaN(this.p2) || isNaN(this.p3) || isNaN(this.p4)) {
			alert("Please enter all the required fields in order to instantiate a new FinanceDetails object.");
		} else {
			loadFinanceDetails(p1,this.p2,this.p3,this.p4);
		}
		
		function loadFinanceDetails(product_type, cost_of_goods, deposit_percentage, deposit_amount) {
		  
		  var my_fd_obj = new FinanceDetails(product_type, cost_of_goods, deposit_percentage, deposit_amount);
		  
		  $("#product_name").html(my_fd_obj.p_name);			
		  $("#finance_term").html(my_fd_obj.term+' Months');
		  $("#cost_per_month").html(my_fd_obj.m_inst);
		  $("#cost_of_goods").html(my_fd_obj.goods_val);
		  $("#deposit_percentage").html(my_fd_obj.d_pc);
		  $("#deposit_amount").html(my_fd_obj.d_amount);
		  $("#apr").html(my_fd_obj.apr);
		  $("#monthly_repayment").html(my_fd_obj.l_repay);
		  $("#total").html(my_fd_obj.total);
		  $("#credit_amount").html(my_fd_obj.l_amount);
		  $("#loan_cost").html(my_fd_obj.l_cost);
		  $("#loan_true_cost").html(my_fd_obj.l_truecost);
	  
		}
		var thiss = this;
		$(".checkoutfinal").click(function(){
	
		  var p1 = $(":input[name='var_product_type']").val();
		  this.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
		  this.p3 = parseFloat($(":input[name='var_deposit_percentage']").val());
		  this.p4 = parseFloat($(":input[name='var_deposit_amount']").val());
		  thiss.mynewFun(p1,this.p2,this.p3,this.p4);
	  });
	}

	 mynewFun(p1,p2,p3,p4){
		$('.loader').css('display','block');
		var methodId = $('input[name="methodId"]:checked').val();
		let data = {
		   product_type:p1,
		   cost_of_goods:p2,
		   deposit_percentage:p3,
		   deposit_amount:p4,
		   fname:this.fname,
		   lname:this.lname,
		   email:this.email,
		   methodId:methodId,
		   orderid:this.orderid
		}
	
		this.checkout.dekopayment(data).subscribe( (response) => {
			  if(response.status==='true'){
				  var redirUrl = response.redirUrl;
				  $(".finalform").attr("action", redirUrl);
				  $('.finalform').submit();
			  }else{
				
			  }
		});
	 }

}
