import { Component, OnInit } from '@angular/core';
import { CheckoutService } from '../../services/checkout.service';
import { environment as env } from '../../../environments/environment';

declare var $:any;
@Component({
  selector: 'app-bank',
  templateUrl: './bank.component.html',
  styleUrls: ['./bank.component.css']
})
export class BankComponent implements OnInit {

  returnUrl:any;
  actionUrl:any;
  unique_id:any;
  orderItemlist:any;
  oid:any;
  
  constructor(private checkout: CheckoutService) { }

    ngOnInit() {

      let tokenid = localStorage.getItem('tokenid');
      let tokenkey = localStorage.getItem('tokenkey');
      let para = '?tokenid='+tokenid+'&tokenkey='+tokenkey;

      this.checkout.getOrdercustomerid(para).subscribe( (response) => {
      this.oid = response.orderid;  
      var d = new Date();
      var time = d.getTime();
      this.unique_id = 'bank_'+this.oid+'_'+time;
      this.actionUrl = env.responseUrl+'?paymentmethod=banktransfer&status=success&uniqueId='+this.unique_id;
      let data1 = {
        orderId:this.oid,
        uniqueId:this.unique_id
     }
     this.checkout.saveTransactionNumber(data1).subscribe( (response) => { console.log(response); })  
   })

      $(".checkoutfinal").click(function(){
        $(".payment_form").submit();
      })
    }
}
