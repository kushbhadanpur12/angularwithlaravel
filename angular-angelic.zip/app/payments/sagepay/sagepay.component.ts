import { Component, OnInit ,Input, Output, EventEmitter ,AfterViewInit,NgZone} from '@angular/core';
import { CheckoutService } from '../../services/checkout.service';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { HttpModule, Http,  Headers } from '@angular/http';
import { ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { RequestOptions, Request, RequestMethod } from '@angular/http';
import { environment as env } from '../../../environments/environment';


declare var $:any;
declare var mynewfunction: any;
declare var getMarchentToken: any;
declare var String:any;

declare var order_id:any;
 
@Component({
  selector: 'app-sagepay',
  templateUrl: './sagepay.component.html',
  styleUrls: ['./sagepay.component.css']
})
export class SagepayComponent implements OnInit {
	@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
	
	form: FormGroup;
	public merchantSessionKey = [];
	public results = [];
	public shouldShowMM :boolean = false;
	public pay3dform :boolean = false;
	public shouldShowYY :boolean = false;
	public shouldShowCVV :boolean = false;
	public shouldShowCardnum :boolean = false;
	public shouldShowholdername :boolean = false;
	public cardhasError :boolean = false;
	public showcard :boolean = false;
	cardnumber:any
	expiryMonth:any
	expiryYear:any
	cvv:any
	cardholdername:any
	
	tokenid:any;
	tokenkey:any;
	public orderId:any;
	responsMsg:any;
  
  


  constructor( private zone: NgZone, private checkout: CheckoutService,private routers: Router, private http: Http ) { }

  ngOnInit() {
		this.responsMsg = 'The card information entered is not valid. Please check and try again.';
		
		this.tokenid = localStorage.getItem('tokenid');
		this.tokenkey = localStorage.getItem('tokenkey');
		let para = '?tokenid='+this.tokenid+'&tokenkey='+this.tokenkey;
  
    this.form = new FormGroup({
 
       cardnumber: new FormControl('',[Validators.required]),
       expiryMonth: new FormControl('',Validators.required),
       expiryYear: new FormControl('',Validators.required),
       cvv: new FormControl('',Validators.required),
       cardholdername: new FormControl(''),
      
    });



    var self = this;

    $(".checkoutfinal").click(function(){
		$(".err").slideUp();
		//$(".cartLoader").show();
		
		let tokenid = localStorage.getItem('tokenid');
    	let tokenkey = localStorage.getItem('tokenkey');
		let methodId = $('input[name="methodId"]:checked').val();
		let para = '?tokenid='+tokenid+'&tokenkey='+tokenkey+'&methodId='+methodId; 
		self.checkout.initiatePayment(para).subscribe( (response) => {
			if(response.status){
				var cardnumber = $("#card-number").val();
				var expiryMonth = $("#expiryMonth").val();
				var expiryYear = $("#expiryYear").val();
				var cvv = $("#cvv").val();
				var cardholdername = $("#card-holder-name").val();
				var methodId = $('input[name="methodId"]:checked').val();
				
				let operateus = localStorage.getItem('operateus');
				if(operateus=='1'){
					var sagepaymoto = 1;
				}else{
					var sagepaymoto = 0;
				}
				
				var param = '?cardnumber='+cardnumber+ '&mmyy='+expiryMonth+expiryYear+ '&cvv='+cvv+ '&cardholdername='+cardholdername+ '&methodId='+methodId+ '&sagepaymoto='+sagepaymoto;
				
				self.calltoSagepayApi(param); 
				self.somethingChanged();
			}else{
				alert('There are some error. Please try again.');
			}
		});
      })
   }

  calltoSagepayApi(param){
      this.checkout.getMarchentToken(param).subscribe( (response) => { this.merchantSessionKey = response; 
          console.log(response);
           if(response.status==="false"){
			$(".err").show();
            this.cardhasError = true;
			$(".cartLoader").hide();
           }else if(response.status==="true") {
            this.cardhasError = false;
			
           
            var merchantSessionKey = response.merchantSessionKey;
            var cardidentifiers = response.cardIdentifiers;
			var methodId = $('input[name="methodId"]:checked').val();
			
			let operateus = localStorage.getItem('operateus');
			if(operateus=='1'){
				var sagepaymoto = 1;
			}else{
				var sagepaymoto = 0;
			}
				
            var param2 = '?tokenid=' +this.tokenid+'&tokenkey='+this.tokenkey+'&merchantSessionKey=' +merchantSessionKey+'&cardidentifiers='+cardidentifiers+' &methodId='+methodId+' &sagepaymoto='+sagepaymoto;
			
                this.checkout.makeSagepayFinalPayment(param2).subscribe( (response) => { this.results = response; 
     			console.log(response);
				
                if(response.data.statusCode==='0000' && response.data.transactionId!='' && response.status==='true'){

                   this.routers.navigate(['checkout-success.html'],{queryParams:{order_number: response.order_number}});
                  
				   
	             }else if(response.data.statusCode==="2007" && response.data.status==="3DAuth"){
					
					
					this.pay3dform = true;
					var acrurl = response.data.acsUrl;
					var returnUrl = env.responseUrl+'?paymentmethod=sagepay&angelic_transaction_number='+response.angelic_transaction_number;
					var paReq = response.data.paReq;
					var form_md = response.angelic_transaction_number; 
					
					$('.TermUrl').val(returnUrl);
					$('.PaReq').val(paReq);
					$('.MD').val(form_md);
					$(".callto3dform").attr("action", acrurl);
					$('.callto3dform').submit();
	    
				 } else{

					//console.log(response);
                }
              })
           }else if(response.status==="invalid"){
		   	
            this.cardhasError = true;
			$(".err").slideDown().delay(5000).slideUp();
			$(".cartLoader").hide();
           }else if(response.status==="failed"){
		   	this.responsMsg = response.message;
            this.cardhasError = true;
			$(".err").slideDown().delay(5000).slideUp();
			$(".cartLoader").hide();
           }else {
		   	$(".err").show();
            this.cardhasError = true;
			$(".cartLoader").hide();
           }
        })
    }

    savetransactionNumber(order_id,form_md){
      let data = {
                    orderId:order_id,
                    uniqueId:form_md
                 }
       this.checkout.saveTransactionNumber(data).subscribe( (response) => { console.log(response); })
    }
    somethingChanged(){

      if(this.form.get('cardnumber').hasError('required')){
        this.shouldShowCardnum = true;
      }else{
        this.shouldShowCardnum = false;
      }
      
      if(this.form.get('expiryMonth').hasError('required') ){
        this.shouldShowMM = true;
      }else{
        this.shouldShowMM = false;
      }

      if(this.form.get('expiryYear').hasError('required') ){
        this.shouldShowYY = true;
      }else{
        this.shouldShowYY = false;
      }

      if(this.form.get('cvv').hasError('required') ){
        this.shouldShowCVV = true;
      }else{
        this.shouldShowCVV = false;
      }

      if(this.form.get('cardholdername').hasError('required') ){
        this.shouldShowholdername = true;
      }else{
        this.shouldShowholdername = false;
      }

  
   }

   displaycardimage(){
     this.showcard=true;                                    
    }

   hidecardimage(){
     this.showcard=false; 
   }

    validate() {

      $(".allownumericwithoutdecimal").on("keypress keyup blur",function (event) {    
        $(this).val($(this).val().replace(/[^\d].+/, ""));
         if ((event.which < 48 || event.which > 57)) {
             event.preventDefault();
         }
     });
  }
 
}
