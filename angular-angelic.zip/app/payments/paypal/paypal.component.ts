import { Component, OnInit } from '@angular/core';
import { CheckoutService } from '../../services/checkout.service';
import { environment as env } from '../../../environments/environment';
import { Subject }    from 'rxjs/Subject';
declare var  $: any;

@Component({
  selector: 'app-paypal',
  templateUrl: './paypal.component.html',
  styleUrls: ['./paypal.component.css']
})
export class PaypalComponent implements OnInit {

	orderItemlist = [];
	customerAddr:any;
	orderDetails:any;
	cemail:any;
	returnUrl:any;
	siteUrl:any;
	public orderid:any;
	public oid:any;
	public unique_id:any;
	public invoice:any;
  constructor(private checkout: CheckoutService) { }

    private globalorderid = new Subject();
    private uniqueid = new Subject();
	
  ngOnInit() {

       this.returnUrl = env.responseUrl;
       this.siteUrl = env.baseURL;
	   
	   var thisalias = this;

    $(".checkoutfinal").click(function(){
		let tokenid = localStorage.getItem('tokenid');
    	let tokenkey = localStorage.getItem('tokenkey');
		let methodId = $('input[name="methodId"]:checked').val();
		let para = '?tokenid='+tokenid+'&tokenkey='+tokenkey+'&methodId='+methodId; 
		thisalias.checkout.initiatePayment(para).subscribe( (response) => {
			if(response.status){
				$(".payment_form").submit();
			}else{
				alert('There are some error. Please try again.');
			}
		});
    });

    let tokenid = localStorage.getItem('tokenid');
    let tokenkey = localStorage.getItem('tokenkey');
    let para = '?tokenid='+tokenid+'&tokenkey='+tokenkey; 

    this.checkout.getOrderDetailsService(para).subscribe( (response) => {
		this.orderDetails = response.orderDetails;
		this.customerAddr = response.shipping;
		this.cemail = response.useremail.email;
	});

    this.checkout.getOrderListItemPayment(para).subscribe( (response) => { this.orderItemlist = response.products; 
    this.oid =  this.orderItemlist[0].order_id;
        
        var d = new Date();
        var time = d.getTime();
        this.invoice = time;
        this.unique_id = 'paypal_'+this.orderItemlist[0].order_id+'_'+time;
          let data1 = {
            orderId:this.oid,
            uniqueId:this.unique_id
         }
         this.checkout.saveTransactionNumber(data1).subscribe( (response) => { console.log(response); })
    
    });

  }

}
