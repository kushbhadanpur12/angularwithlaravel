import { Component, OnInit , Input } from '@angular/core';
import { CheckoutService } from '../../services/checkout.service';

@Component({ 
  selector: 'app-paymentresponse',
 templateUrl: './paymentresponse.component.html',

  styleUrls: ['./paymentresponse.component.css']
})
export class PaymentresponseComponent implements OnInit {

  constructor(private checkout: CheckoutService) { }

  ngOnInit() {

  }

  
}