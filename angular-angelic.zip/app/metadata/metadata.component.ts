import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';

@Component({
  selector: 'app-metadata',
  templateUrl: './metadata.component.html',
  styleUrls: ['./metadata.component.css']
})
export class MetadataComponent implements OnInit {

  constructor(private meta: Meta, private titleService: Title) { }

  ngOnInit() {
  	
  }

  public setMetaTitle(data: string) {
    if (data) {
		this.titleService.setTitle(data);
    }else{
		this.titleService.setTitle('Beautiful Diamond Jewellery | Angelic Diamonds');
	}
  }

  public setMetaDesc(data: string) {
    if (data) {
		this.meta.updateTag({name: 'description', content: data});
    }else{
		this.meta.updateTag({name: 'description', content: 'Welcome to Angelic Diamonds the diamond jewellery experts. We specialize in beautiful diamond jewellery at unbeatable prices including engagement rings, diamond rings, wedding rings and diamond earrings.'});
	}
  }
}
