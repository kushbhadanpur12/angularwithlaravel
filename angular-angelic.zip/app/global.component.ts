'use strict';

 export var showDialog :boolean = false;
  export const invoice  = `
  
  .page-category #content > .section > .list-container > h1 {
    margin-bottom: 25px!important;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Light.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Light.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Light.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Light.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Light.otf') format('opentype');
 font-weight: 300;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Regular.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Regular.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Regular.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Regular.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Regular.otf') format('opentype');
 font-weight: 400;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Medium.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Medium.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Medium.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Medium.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Medium.otf') format('opentype');
 font-weight: 500;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-SemiBold.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-SemiBold.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-SemiBold.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-SemiBold.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-SemiBold.otf') format('opentype');
 font-weight: 600;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Bold.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Bold.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Bold.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Bold.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Bold.otf') format('opentype');
 font-weight: 700;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Bold.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Bold.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Bold.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Bold.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Bold.otf') format('opentype');
 font-weight: bold;
 font-style: normal;
}
@font-face {
 font-family: 'Montserrat';
 src: url('./assets/frontend/fonts/Montserrat-Regular.eot') format('embedded-opentype'), url('./assets/frontend/fonts/Montserrat-Regular.woff') format('woff'), url('./assets/frontend/fonts/Montserrat-Regular.woff2') format('woff2'), url('./assets/frontend/fonts/Montserrat-Regular.ttf') format('truetype'), url('./assets/frontend/fonts/Montserrat-Regular.otf') format('opentype');
 font-weight: normal;
 font-style: normal;
}
.dialog {
    border: 1px solid #e1dddd;
    margin: 0 0 30px;
    padding: 0;
    page-break-inside: avoid;
    border-radius: 3px 3px 0 0;
}

body .dialog .title {
    background: #b5a27a none repeat scroll 0 0;
    border-radius: 3px 3px 0 0;
    border-bottom: 1px solid #b5a27a;
}
.dialog .content {
    background: transparent none repeat scroll 0 0;
    border: 0 none;
    color: #58595b;
    padding: 10px 10px 20px;
    text-align: left;
}

.order-success-panel .content p {
    font-weight: 300;
    letter-spacing: 0.5px;
    color: #1e1e1e;
    font-size: 13.5px;
}

.text-block {
    margin-bottom: 15px;
}

.social-icon {
    margin-bottom: 30px;
    display: block;
    margin: auto;
    text-align: center;
}

.social-images {
    padding-top: 1%;
    padding-left: 1%;
}
.social-images li {
    display: inline;
    padding-left: 4%;
    padding-right: 4%;
}

.social-images a {
    color: #878787;
    font-size: 12px;
    text-decoration: none;
}

.order-success-panel .social-icon img {
    width: 3% !important;
}

.social-icon img {
    vertical-align: middle;
    width: 4%;
}

.order-success-panel {
     width:100%!important; 
     max-width:100%!important;
}

.target-checkoutSuccess .order-success-panel .dialog .title > h2 {
    font-size: 1.1em;
    font-weight: 600;
    line-height: 26px;
    letter-spacing: 1.5px;
}


body .dialog .title h2 {
    color: #fff;
    font-weight: bold;
}

.dialog .title h2 {
    font-size: 13px;
    margin: 0;
    overflow: hidden;
    padding: 0;
    white-space: nowrap;
}

.dialog .title {
    -moz-border-bottom-colors: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    border-color: -moz-use-text-color -moz-use-text-color #acb7c7;
    border-image: none;
    border-style: none none solid;
    border-width: 0 0 1px;
    color: #253161;
    font-size: 13px;
    font-weight: bold;
    height: 30px;
    line-height: 30px;
    margin: 0;
    overflow: hidden;
    padding: 0 0 0 18px;
    position: relative;
    text-align: left;
    vertical-align: middle;
}

#myelement{
    margin-left:-8px;
}
.order_tophr_line{
    display:none;
}
hr{
    display:none;
}
.order-logo{
    width:100%;
    height:105px;
}
.order-invoice.width-100 td {
    color: #666;
    font-size:11px;
    margin: 0;
    padding: 0;
    white-space: normal;
    letter-spacing: 0.6px;
    font-weight:normal;
    font-family: 'Montserrat', sans-serif;
    vertical-align: top;
    text-align:left;
    line-height:12px;
}
.order-invoice.width-100 strong {
    line-height: 14px;
    letter-spacing: 0.6px;
    font-weight:600;
    color: #63656a;
}
.invoice-data-box table{
    width:100%
}
table.width-100{
    width:100%;
}
#html_order_info {
    width:40%;
    line-height: 14px;
    border-bottom: 1px solid #d1d1d1;
    padding-left:2px;    
    padding-bottom:10px;
}
.invoice-personal-info{
    padding-top:10px;
    padding-bottom: 12px;
}
.invoice-address-title strong{
    width:100%;
    float:left;
    padding-bottom:10px;
    margin-bottom:10px;
    border-bottom: 1px solid #d1d1d1;
}
table.order-invoice{
    width:100%;
}
ul.addresses{
    padding:0px;
}
.address.shipping{
    width: 38.8%;
    float:left;
    margin-right:16%;
}
.address.payment {
    float: right;
    width: 42%;
}
ul.addresses table{
    width:100%;
}
.invoicePersonalInfo{
    width:50px;
}
.address-field td:first-child{
    width:auto !important;
}
.pslcolon{
    width:25px;
    color: #666;
    vertical-align: middle;
}
td.right_td{
    padding-left:10px;
    margin-left:10px;
    display:block;
}
ul.addresses li{
    list-style:none;
}
.address-field td{
    text-align:center;
}

.invoice_product_details{
    margin-top: 55px;
    width: 100%;
}
.invoice_product_details .border_prnt td{
     border-bottom:1px solid #d1d1d1;
}
td.td-product-infor{
    border-bottom:none !important;
}
.invoice_product_details th{
    padding: 9px 5px;
    background-color: #f9f9f9;
    -webkit-print-color-adjust: exact;
    border-bottom: 1px solid #d1d1d1;
    color: #63656a;
    font-size: 14px;
    font-weight: normal;
    vertical-align: middle;
    position: inherit;
    white-space: nowrap;
    font-family: 'Montserrat', sans-serif;
    text-align:center;
}
.invoice_product_details th.item{
    text-align:left;
    padding: 10px 0px;
}
.invoice_product_details th.total {
    padding: 10px 0px;
    text-align:right;
}
.invoice_product_details td{
    color: #666;
    font-size: 11px!important;
    font-weight:normal !important;
    font-family: 'Montserrat', sans-serif;
    vertical-align: top;
    padding:4px 5px;
    text-align: center;
    letter-spacing: 0.6px;
}
.invoice_product_details td.sku{
    text-align: left;
}
.invoice_product_details td.item{
    text-align: left;
}
.invoice_product_details td.item a{
    text-decoration:none;
    font-size: 11px!important;
    font-weight: normal !important;
    color: #666;
    font-family: 'Montserrat', sans-serif;
}
.selected-attribute-values li{
    list-style:none;
    text-align: left;
}
ul.selected-attribute-values{
    width:100%;
    padding:0px !important;
    float:left;
    margin:0px !important;
    text-align: left;
    
}
li.item-attribute-values-list-item{
    width: 45%;
    float:left;
    margin-left:-7px;
}
.item-attribute-values-list-item .attrname{
    font-size: 12px!important;
    font-weight: normal !important;
    color: #63656a;
    word-break: normal;
    float: left;
    text-align:left;
}
.item-attribute-values-list-item .colon{
    font-size: 12px!important;
    font-weight: normal !important;
    color: #63656a;
    word-break: normal;
    float: left;
}

ul.totals.simple-list {
    padding: 0px;
    width: 100%;
    float:left;
    border-bottom:1px solid #d1d1d1;
    padding-bottom:5px;
    margin-bottom:5px;
}
ul.totals li{
    list-style:none;
    width:100%;
    float:left;
    margin-bottom:3px;
}

.title_box_mng{
    float: left;
    font-size: 12px;
    text-align: right !important;
    width: 80% !important;
    font-weight: 600 !important;
    font-family: 'Montserrat', sans-serif;
}
.value_box_mng{
    font-weight: normal !important;
    font-size: 12px;
    float: right;
    width: 19%;
    text-align: right;
    font-family: 'Montserrat', sans-serif;
}
.grandtotatal_box{
    font-size: 15px !important;
    font-weight: bold !important;
    font-family: 'Montserrat', sans-serif;
}
.grandtotatal_values{
    font-size: 15px !important;
    font-weight: bold !important;
    font-family: 'Montserrat', sans-serif;
}
.buttom-company-address {
    width: 100%;
    text-align: center;
}
.buttom-company-address strong{
    margin:0px;
    padding:0px;
    font-size: 12px;
    font-family: 'Montserrat', sans-serif;
}
.buttom-company-address p {
    color: #63656a;
    text-align: center;
     margin:0px;
    padding:0px;
    font-size: 12px;
    font-family: 'Montserrat', sans-serif;
}
.buttom-company-address .url a{
    color: #63656a;
    text-decoration:none;
    font-size: 12px;
    font-family: 'Montserrat', sans-serif;
}
.order-invoice-continue-shopping{
    display:none;
}
  `;
 