export class Registration { 
    
    email : string;
    password : string;
}