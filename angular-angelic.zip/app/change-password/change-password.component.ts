import { Component, OnInit ,Input, Output, EventEmitter} from '@angular/core';
import {Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { RegistrationService } from '../services/registration.service';
import { HomeService } from "../home.service";
import { LoginComponent } from '../login/login.component';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var setCookie:any;
declare var getCookie:any;
declare var eraseCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

	form: FormGroup;
	@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
	
	password:any;
	tokenKey:any;
	results:any;
	attempt:any;
	customeremail:any;
	password_conf:any;
	mycss :boolean = false;
	public shouldShow1 :boolean = false;
	public passMatchError :boolean = false;
	public tokenMismatchError :boolean = false;
	public shouldShow2 :boolean = false;
	public creatPass :boolean = false;
	
	constructor(private router : ActivatedRoute, private route: Router, private register: RegistrationService, private homeService: HomeService, private metadt: MetadataComponent, private linkmd: LinkService) {  
	}
	ngOnInit() {
		this.metadt.setMetaTitle('Change Password');
		this.metadt.setMetaDesc('Angelic Diamonds');
		var canonicalurl = env.baseURL + 'recover-password.html';
		this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
	 this.router.queryParams.subscribe(params => {
		this.tokenKey = params['token'];
		this.attempt = params['attempt'];
		this.customeremail = params['emailid'];
	 });
	 
	 if(this.attempt!= null && this.attempt!=undefined && this.attempt==1){
	 	this.creatPass = true;
	 }
	if(this.tokenKey == null && this.tokenKey==undefined){
		this.tokenKey = getCookie('resetPassToken');
	}
	if(this.customeremail == null && this.customeremail==undefined){
		this.customeremail = getCookie('customerEmail');
	}
	let tokenid =  localStorage.getItem('tokenid');
	let tokenkey =  localStorage.getItem('tokenkey');
	let para = '?tokenid='+tokenid+'&tokenkey='+tokenkey+'&forgotPassToken='+this.tokenKey;
    this.register.checkChangedPasswordToken(para).subscribe( res => { console.log(res);
		if(res.statusCode==404){
			  this.tokenMismatchError = true;
		}else{                                                                                                                                                                             
		if(this.tokenKey!=null && this.tokenKey!=undefined && this.tokenKey!=''){
			setCookie('resetPassToken',this.tokenKey);
			
			setCookie('customerEmail',this.customeremail);
			
			//this.route.navigate(['/']);
		}else{
			this.tokenMismatchError = true;
			console.log('tokenMismatchError');
		}
	}
	 }); 

	
	this.form = new FormGroup({
        password: new FormControl('',Validators.required),
        password_conf: new FormControl('',Validators.required)
      });
	}

	submitForm(form){
	
		let password = form.value.password;
        let password_conf = form.value.password_conf;
		 if(this.form.valid){
		
		    if(password===password_conf){
		     	var resetPassToken = getCookie('resetPassToken');
				console.log(resetPassToken); 
				if(resetPassToken!=null && resetPassToken!='' && resetPassToken!= undefined){
				   var tokenid = localStorage.getItem('tokenid');
				   var tokenkey = localStorage.getItem('tokenkey');
				    let data = {
						tokenid:tokenid,
					    tokenkey:tokenkey,
					    password:password,
						resetPassToken:resetPassToken
					}
					  
				   this.register.changedPassword(data).subscribe(
                            res => { console.log(res); 
							if(res.statusCode==200){
							     this.loginAfterResetpassword(res.email,password);
								  eraseCookie('resetPassToken');
								   this.route.navigate(['/']);
								 
							}
						});
				}
			}else{
			    this.passMatchError = true;
				setTimeout(()=>{ this.passMatchError = false; },4000);
				this.password='';
				this.password_conf='';
				this.shouldShow1 = false;
				this.shouldShow2 = false;
				this.mycss = false;
			}
		 }else{
		      this.mycss = true;
		 }
	 }
	 
 customvalidation(){
    if(this.password =='' || this.password == undefined){
      this.shouldShow1 = true;
    }
    if(this.password_conf =='' || this.password_conf == undefined){
      this.shouldShow2 = true;
    }
  }
  
  loginAfterResetpassword(email,password){
  {
      let postdata = {
        email:email,
        password:password
      }
	  
      this.register.customerLogin(postdata).subscribe((response) => { response;
		if(response){
		 let newv = response;
		 let alldata = newv.access_token;
          if(alldata!=''){
            let token = alldata;
            localStorage.setItem('token',token);
			let tokenid =  localStorage.getItem('tokenid');
			let tokenkey =  localStorage.getItem('tokenkey');
			
            let senddata = {
                token:alldata
              }
			 this.register.customerLoginWithToken(senddata).subscribe( (final_response) => { final_response; 
			   let fnaew = final_response;
               let c_id  = fnaew.id;
               let c_email =  fnaew.email;
               let cfname =  fnaew.fname;
			   setCookie('clientemail',fnaew.email);
			     let log = {
						tokenid:tokenid,
						tokenkey:tokenkey,
						tokenvalue:fnaew.id
					}
			   this.register.generateDynamicJsonToken(log).subscribe( (res) => {  console.log(res); });
               localStorage.setItem('cname',cfname);
               localStorage.setItem('cid',c_id);
               localStorage.setItem('cemail',c_email);
                    if((tokenid!=null && tokenid!=undefined) && (tokenkey!=null && tokenkey!=undefined))
                     {
                          let req = {  userId:c_id, tokenid:tokenid, tokenkey:tokenkey }
                          this.register.updateUserIdSessiontbl(req).subscribe( (res) => { res; });
						  let paragetcartItems = '?tokenid='+tokenid+'&tokenkey='+tokenkey;
						  this.homeService.getcartItems(paragetcartItems).subscribe( (response) => { this.results = response; } );
                     }
                     this.route.navigate(['/']);
          });
          }else{
            let newv11 = response;
           }
         }
      });
  }
  }
}