import { Component, OnInit ,Input, Output, EventEmitter  } from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { Contact } from "./Contact.model";
import { HomeService } from "../home.service";
import { HttpModule, Http} from '@angular/http';
import { RouterModule, Routes, Router}  from '@angular/router';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var $:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();

mycss :boolean = false;
sentmsg :boolean = false;

public shouldShow1 :boolean = false;
public shouldShow2 :boolean = false;
public shouldShow3 :boolean = false;
public shouldShow4 :boolean = false;


email: string;
name: string;
subject: string;
message : string;

 
   form: FormGroup;
   constructor(private http: Http, private homeService: HomeService, private router: Router, private metadt: MetadataComponent, private linkmd: LinkService) { }

  ngOnInit() {
    this.metadt.setMetaTitle('Contact us');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'contactus.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
       var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }

	this.homeService.getUserDataForContactus().subscribe(res=> { console.log(res);
	if(res.statusCode==200){
	    this.email = res.email;
	    this.name = res.name;
	  }
	 });
	
    this.form = new FormGroup({
      name: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required,Validators.email,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
      subject: new FormControl('',[Validators.required]),
      message: new FormControl(''),
    })
  }


  customvalidation(){

    if(this.email =='' || this.email == undefined){
      this.shouldShow1 = true;
    }

    if(this.name =='' || this.name == undefined){
      this.shouldShow2 = true;
    }

    if(this.subject =='' || this.subject == undefined){
      this.shouldShow3 = true;
    }
  }

 somethingChanged(form){
    if(this.form.get('email').hasError('required') || (!this.form.get('email').hasError('required') && 
    (this.form.get('email').hasError('email'))|| this.form.get('email').hasError('pattern'))){
      this.shouldShow2 = true;
    }else{
      this.shouldShow2 = false;
    }

    if(this.form.get('name').hasError('name')){
      this.shouldShow1 = true;
    }else{
      this.shouldShow1 = false;
    }

    if(this.form.get('subject').hasError('required') ){
      this.shouldShow3 = true;
    }else{
      this.shouldShow3 = false;
    }
 }
  addUser(form){
  
     let name = form.value.name;
     let email = form.value.email;
     let subject = form.value.subject;
	 let message = form.value.message
	 if(!message){
	   let message = '';
	  }else {
	    
	  }
    if(this.form.valid){
	
	$('.cartLoader').show();
	
    let postdata = { name:name,email:email,subject:subject, message:message }

    this.homeService.storeDataOfContactus(postdata).subscribe(response => { console.log(response);
    if(response.status=='true'){
	 $('.cartLoader').hide();
		setTimeout(()=>{  this.sentmsg= false; },3000);
	    this.clientClass.emit();
		this.Clientmessage.emit();
		  this.sentmsg= true;
		  this.name;
		  this.email;
		  this.subject='';
		  this.message='';
		  this.mycss = false;
    }
   });

  }else{
    this.mycss = true;
  }
    
   }

}
