import { Component, OnInit } from "@angular/core";
import {
  ReactiveFormsModule,
  Form,
  FormGroup,
  Validators,
  FormControl,
  Validator
} from "@angular/forms";
import { HttpModule, Http } from "@angular/http";
import { RouterModule, Routes, Router, ActivatedRoute } from "@angular/router";
import { FilterService } from "../../services/filter.service";
import { RegistrationService } from "../../services/registration.service";
import { LaravelRoutesService } from "../../services/laravel-routes.service";
import { CartService } from "../../services/cart.service";
import { Subscription } from "rxjs/Subscription";
import { HomeService } from "../../home.service";
import { LinkService } from "../../services/link.service";
import { Input, Output, OnChanges, EventEmitter } from "@angular/core";
import {
  trigger,
  state,
  style,
  animate,
  transition
} from "@angular/animations";
import { Meta, Title } from "@angular/platform-browser";

declare var jquery: any;
declare var $: any;
//declare var CraftyClick:any;
declare var getCookie: any;
declare var eraseCookie: any;

@Component({
  selector: "app-header",
  templateUrl: "./header.component.html",

  styleUrls: ["./header.component.css"]
})
export class HeaderComponent implements OnInit {
  search: string;
  //postsArray: Filter[];
  cat_arr: any;
  jsonResponse: string;
  currenydataArray: any;
  finalCurrency: any;
  form: FormGroup;
  searchstr: FormGroup;
  sortby: any;

  perPage: any;
  resetUserEmail: any;
  current_page: any;
  mycss: boolean = false;
  closedialog: boolean = true;
  public prev = [];
  previous: any;
  ask: any;
  public shouldShow: boolean = false;
  public passshouldShow: boolean = false;
  public isRestPAssReq: boolean = false;
  public closepopup: boolean = true;
  result = [];
  tokenid: any;
  public customer_currency: any;
  currenciesAll: any;
  @Input() results: any;
  profileData: any;
  profileData2: any;
  profileData3: any;
  newSession: any;
  currencyForm: FormGroup;
  loginerror: boolean = false;

  email: string;
  password: string;
  SessionVar: any = [];
  currencyVal: any = [];
  public fC = [];
  postsArray: any;
  getCurrencyw: any;
  currencyData: any;
  subscription: any;
  currencyObj: any;
  currencyrerer: any;
  currency: string;
  n: any;
  showDropDown: boolean;
  displayddl: string;
  tokenkey: any;
  newSess: any;
  public ctype = "";

  public glaballogin: boolean = false;
  public operateasuser: boolean = false;
  cid: any;
  operate_as_id: any;
  hover: boolean;
  loginuser: string;
  loginusername: string;

  constructor(
    private http: Http,
    private router: Router,
    private filterService: FilterService,
    private homeservice: HomeService,
    private cartservice: CartService,
    private meta: Meta,
    private pagenproduct: LaravelRoutesService,
    private title: Title,
    private route: Router,
    private routerQ: ActivatedRoute,
    private register: RegistrationService,
    private linkmd: LinkService
  ) {}

  ngOnInit() {
    this.linkmd.removeTag("next");
    this.linkmd.removeTag("prev");

    this.pagenproduct.metaTitleObservable$.subscribe(res => {
      this.title.setTitle(res);
    });

    this.pagenproduct.metaDescObservable$.subscribe(res => {
      this.meta.addTag({ name: "description", content: res });
    });
    this.form = new FormGroup({
      email: new FormControl("", [
        Validators.required,
        Validators.email,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"),
        Validators.minLength(7)
      ]),
      password: new FormControl("", Validators.required)
    });
    this.searchstr = new FormGroup({
      substring: new FormControl("")
    });
    var resetPassToken = getCookie("resetPassToken");
    if (
      resetPassToken != null &&
      resetPassToken != undefined &&
      resetPassToken != ""
    ) {
      var resetmail = getCookie("customerEmail");
      this.resetUserEmail = resetmail;
      this.isRestPAssReq = true;
    }

    this.getCurrencyw = this.homeservice.getCustomerToken().subscribe(
      response => {
        localStorage.setItem("tokenid", response.tokenid);
        localStorage.setItem("tokenkey", response.tokenkey);
        this.tokenid = localStorage.getItem("tokenid");
        this.tokenkey = localStorage.getItem("tokenkey");
        this.currenciesAll = response.currenciesAll;
        this.customer_currency = JSON.parse(response.customer_currency);
        this.currency = JSON.stringify(this.customer_currency.id);
      },
      (error: Response) => console.log(error)
    );
    this.currencyForm = new FormGroup({
      currency: new FormControl("Pound Sterling")
    });
    let tid = localStorage.getItem("tokenid");
    let tokenkey = localStorage.getItem("tokenkey");
    let para = "?tokenid=" + tid + "&tokenkey=" + tokenkey;
    //this.results = this.homeservice.getcartItems(para);
    this.subscription = this.cartservice.cartDetailForHeaderObservable$.subscribe(
      res => {
        this.results = res;
      }
    );
    this.homeservice.getcartItems(para).subscribe(response => {
      this.results = response;
    });
    let paramsString = window.location.search;
    let searchParams = new URLSearchParams(paramsString);
    if (searchParams.has("operate_as_id")) {
      this.operate_as_id = searchParams.get("operate_as_id");
      this.cid = searchParams.get("cid");
      this.homeservice
        .operateCustomer(this.operate_as_id, this.cid)
        .subscribe(resultArray => {
          console.log(resultArray);
          if (resultArray.access_token) {
            let senddata = {
              token: resultArray.access_token
            };
            localStorage.setItem("token", resultArray.access_token);
            localStorage.setItem("operateus", "1");

            this.operateasuser = true;

            this.register
              .customerLoginWithToken(senddata)
              .subscribe(final_response => {
                final_response;

                let fnaew = final_response;
                let c_id = fnaew.id;
                let c_email = fnaew.email;
                let cfname = fnaew.fname + " " + fnaew.lname;

                localStorage.setItem("cname", cfname);
                localStorage.setItem("cid", c_id);
                localStorage.setItem("cemail", c_email);

                let tokenid = localStorage.getItem("tokenid");
                let tokenkey = localStorage.getItem("tokenkey");

                if (
                  tokenid != null &&
                  tokenid != undefined &&
                  (tokenkey != null && tokenkey != undefined)
                ) {
                  let req = {
                    userId: c_id,
                    tokenid: tokenid,
                    tokenkey: tokenkey
                  };
                  this.register.updateUserIdSessiontbl(req).subscribe(res => {
                    res;
                  });
                }
              });
          }
        });
    }

    this.isLoggedin();
    //setTimeout(CraftyClick(),1000);

    let operateus = localStorage.getItem("operateus");
    if (operateus == "1") {
      this.operateasuser = true;
      this.initOperatingAsUser();
    }
  }
  initOperatingAsUser() {
    console.log("initOperatingAsUser on");
    $(function() {
      $("#operating-as-user-container").draggable();
    });
  }

  onSearchChange(search) {
    $("#instant_search_menu").show();
    if (search.length > 0) {
      this.filterService.getFilter(search).subscribe(cat_arr => {
        this.cat_arr = cat_arr;
        console.log("header" + this.cat_arr);
      });
    } else {
      this.cat_arr = [];
    }
  }

  blankQuickSearch() {
    $("#searchStr").val("");
    $("#instant_search_menu").hide();
  }

  onClickedOutside() {
    $("#instant_search_menu").hide();
  }

  focusQuickSearch() {
    $("#instant_search_menu").show();
  }

  isLoggedin() {
    if (localStorage.getItem("cemail")) {
      var myObj = localStorage.getItem("cemail");
      if (myObj != "" && myObj != undefined && myObj != null) {
        this.loginuser = myObj;
        this.loginusername = localStorage.getItem("cname");
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  logout() {
    this.homeservice.logoutCstomer().subscribe(response => {
      this.results = response;
    });

    localStorage.removeItem("cemail");
    localStorage.removeItem("cname");
    localStorage.removeItem("cid");
    localStorage.removeItem("token");
    localStorage.removeItem("tokenid");
    localStorage.removeItem("tokenkey");
    this.closepopup = true;
    this.isLoggedin();
    this.router.navigate(["/"]);
  }

  resetPasslogout() {
    this.isRestPAssReq = false;
    eraseCookie("customerEmail");
    eraseCookie("resetPassToken");
    this.router.navigate(["/"]);
  }

  checkvalue() {
    let t = this.email;
    if (t == "" || t == undefined) {
      this.shouldShow = true;
    } else {
    }

    if (this.password == "" || this.password == undefined) {
      this.passshouldShow = true;
    } else {
    }
  }
  somethingChanged() {
    if (
      this.form.get("email").hasError("required") ||
      ((!this.form.get("email").hasError("required") &&
        this.form.get("email").hasError("email")) ||
        this.form.get("email").hasError("pattern"))
    ) {
      this.shouldShow = true;
    } else {
      this.shouldShow = false;
    }

    if (this.form.get("password").hasError("required")) {
      this.passshouldShow = true;
    } else {
      this.passshouldShow = false;
    }
  }

  onCurrency(currencyFormaaa) {
    this.n = currencyFormaaa.value.currency;
    this.homeservice.onFindCurrency(this.n).subscribe();
    window.location.reload();
  }

  manualtoggle() {
    this.showDropDown = !this.showDropDown;
    this.displayddl = this.showDropDown ? "inline" : "none";
  }

  removeOrderItem(id, orderid) {
    let tid = localStorage.getItem("tokenid");
    let tokenkey = localStorage.getItem("tokenkey");
    let para =
      "?tokenid=" +
      tid +
      "&tokenkey=" +
      tokenkey +
      "&itemId=" +
      id +
      "&orderid=" +
      orderid;
    this.results = this.homeservice.removeOrderItems(para);
    this.router.navigate(["/cart.html"]);
  }

  searchSubmit(searchstr) {
    this.routerQ.queryParams.subscribe(params => {
      $(".catLoader").show();
      this.searchstr = searchstr;

      if (params["sortby"] != "" && params["sortby"] != undefined) {
        this.sortby = params["sortby"];
      } else {
        this.sortby = "recommended-asc";
      }

      if (params["perPage"] != "" && params["perPage"] != undefined) {
        this.perPage = params["perPage"];
      } else {
        this.perPage = 48;
      }

      if (params["current_page"] != "" && params["current_page"] != undefined) {
        this.current_page = params["current_page"];
      } else {
        this.current_page = 1;
      }

      this.route.navigate(["/search.html"], {
        queryParams: {
          searchstr: searchstr.value.substring,
          sortby: this.sortby,
          perPage: this.perPage,
          current_page: this.current_page
        }
      });
    });
  }
}
