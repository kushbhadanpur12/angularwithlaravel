export class Filter {
    id: number;
    name :string;
    cat_banner_img : string;
    cat_h1_title : string;
}