export class Category {

    id: number;
    name :string;
    cat_banner_img : string;
    cat_h1_title : string;
    

    
       /* "id": 2,
        "parent_id": 0,
        "slug": "diamond-rings",
        "name": "Diamond Rings",
        "description": null,
        "metaTitle": null,
        "metaDesc": "Choose from our exclusive collection of diamond rings. Unbeatable prices, 30 day money back guarantee and free delivery.",
        "metaTags": null,
        "enabled": 1,
        "cat_h1_title": "Diamond Rings",
        "cat_h3_title": null,
        "cat_banner_img": "http://127.0.0.1:8000/images/categories/banner/diamond_ring_sketch_web.jpg",
        "cat_banner_img_alt": null,
        "cat_banner_slogan": null,
        "cat_extra_content": null,
        "created_at": "2017-12-13 04:03:29",
        "updated_at": "2018-01-11 07:20:46" */
}
