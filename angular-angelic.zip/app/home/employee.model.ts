export class Employee {
    id: number;
    name :string;
    sku : string;
    metaDesc: string;
    price: number;
}
