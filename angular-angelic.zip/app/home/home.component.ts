import { Component, OnInit } from '@angular/core';
import { HomeService } from "../home.service";
import { Employee } from "./Employee.model";
import { Category } from "./Category.model";
import { RegistrationService } from '../services/registration.service';
import {RouterModule, Routes, Router, ActivatedRoute, Params} from '@angular/router';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';
declare var $:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  postsArray: Employee[];
  catArray: Category[];
  met_desc:any;
  constructor(private activatedRoute: ActivatedRoute, private router: Router, private homeService: HomeService, private register: RegistrationService, private metadt: MetadataComponent, private linkmd: LinkService) {
  }

ngOnInit() {
		this.metadt.setMetaTitle('Beautiful Diamond Jewellery | Angelic Diamonds');
		this.metadt.setMetaDesc('Angelic Diamonds specialises in stunning jewellery including engagement rings, wedding rings and more. View its collections here.');
		var canonicalurl = env.baseURL;
		//this.linkmd.createLinkForCanonicalURL(canonicalurl);
		
		var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
          this.router.navigate(['recover_password']); 
        }else{
  
			this.homeService.fetchData()
			.subscribe(
			  resultArray => this.postsArray = resultArray,
			  error => console.log("Error :: " + error)
			);
		
		  /*this.homeService.allCategoryData()
		  .subscribe(
			  resultArray => this.catArray = resultArray,
			  error => console.log("Error :: " + error)
		  );*/
		  
		  }
  
}

toggleContent(){
           $("#morehomeinfocontent").toggle(800);
}

}