import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { RouterModule, Routes, Router, ActivatedRoute}  from '@angular/router';
import { HomeService } from '../../home.service';
import { Subscription }   from 'rxjs/Subscription';
import { FilterService } from '../../services/filter.service';
import { CartService } from '../../services/cart.service';
declare var $:any;

@Component({
  selector: 'app-mobilemenu',
  templateUrl: './mobilemenu.component.html',
  styleUrls: ['./mobilemenu.component.css']
})
export class MobilemenuComponent implements OnInit {
	results :any;
	searchstr :any;
	subscription:any;
	form: FormGroup;
	cat_arr :any;
	sortby:any;
	perPage:any;
	current_page:any;
	hover:boolean;
	
	constructor( private homeservice: HomeService, private cartservice : CartService,private filterService : FilterService,private router: Router, private routerQ : ActivatedRoute) { }
	ngOnInit() {
		this.subscription = this.cartservice.cartDetailForHeaderObservable$.subscribe(  res => {  this.results = res;  });
		let tid =  localStorage.getItem('tokenid');
		let tokenkey =  localStorage.getItem('tokenkey');
		let para = '?tokenid='+tid+'&tokenkey='+tokenkey;
		this.homeservice.getcartItems(para).subscribe( (response) => { this.results = response; } );
		this.searchstr = new FormGroup({
		  substring: new FormControl('')
		});
	          }
	
	closeMobileMenu(){
	 $(".mmenuiconclose").trigger('click');
	}
	  onClickedOutside(){
		//$('#instant_search_menu').hide();
	  }
	  
searchSubmit(searchstr){
  	this.routerQ.queryParams.subscribe(params => {
		$(".catLoader").show();
		setTimeout(()=>{  $(".catLoader").hide(); },2500);
		this.searchstr = searchstr;
		
		if(params['sortby']!='' && params['sortby']!=undefined){
			this.sortby = params['sortby'];
		}else{
			this.sortby = 'recommended-asc';
		}
		
		if(params['perPage']!='' && params['perPage']!=undefined){
			this.perPage = params['perPage'];
		}else{
			this.perPage = 48;
		}
		
		if(params['current_page']!='' && params['current_page']!=undefined){
			this.current_page = params['current_page'];
		}else{
			this.current_page = 1;
		}
		console.log(searchstr);
	
		this.router.navigate(['/search.html'], { queryParams: { searchstr: searchstr.value.substring, sortby:this.sortby, perPage:this.perPage, current_page:this.current_page } });
	});
	
  }
  
    
  onSearchChange(search) {
  	$('#instant_search_menu').show();
    if( search.length > 0){
     this.filterService.getFilter(search)
     .subscribe(
      (cat_arr) => { this.cat_arr = cat_arr;
    	$(".catLoader").hide();
	  },
      (error: Response) => console.log(error)
    );
    } else {
      this.cat_arr=[];
    }
  }
    blankQuickSearch() {
	$('#searchStrMob').val('');
	$('#instant_search_menu').toggle();
  }
  
  toggleSearchField(){
   $('.simple-search-product-form').slideToggle(10);
  }
}
