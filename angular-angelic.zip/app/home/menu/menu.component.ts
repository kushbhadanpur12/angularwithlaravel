import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
declare var jquery:any;
declare var $ :any;
declare var setCookie:any;

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  public menuborder : Boolean = false;
  constructor( private router : ActivatedRoute, private route: Router,) { }

  ngOnInit() {
  this.router.params.subscribe(res=>{
           let slug2 = this.router.snapshot.url.length;
		    if(slug2>0){
			    this.menuborder = false;
			}else{
				this.menuborder = true;
			}	 
  });
  
  
  }
  
  saveUrlForResetFilter(url){
    setCookie('filterReset',url);
  }
  
}
