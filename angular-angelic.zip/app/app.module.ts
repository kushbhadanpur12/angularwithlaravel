import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router, ActivatedRoute}  from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './home/header/header.component';
import { MenuComponent } from './home/menu/menu.component';
import { FooterComponent } from './home/footer/footer.component';
import { HomeService } from "./home.service";

import { OrderDetailComponent } from './my-acount/order-detail/order-detail.component';
import { AddressBookComponent } from './my-acount/address-book/address-book.component';
import { OrdersComponent } from './my-acount/orders/orders.component';
import { DetailsComponent } from './my-acount/details/details.component';
import { Component, OnInit, Input, Output, OnChanges, EventEmitter,ElementRef } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';


import { Employee } from "./home/Employee.model";
import { Category } from "./home/Category.model";
import { Registration } from "./registration/Registration.model";
import { Pages } from '../app/pagesnproducts/pages.model';

import { HttpModule} from '@angular/http';
import { MobilemenuComponent } from './home/mobilemenu/mobilemenu.component';
import { ContactusComponent } from './contactus/contactus.component';
import {ReactiveFormsModule,FormsModule } from '@angular/forms';
import { Contact } from "./contactus/Contact.model";
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import{ PagesnproductsComponent } from './pagesnproducts/pagesnproducts.component';

//    all services 
import { FilterService } from './services/filter.service';
import { FootercontentService } from './services/footercontent.service';
import { LaravelRoutesService } from './services/laravel-routes.service';
import { SubcategoryService } from './services/subcategory.service';
import { LinkService } from './services/link.service';
import { empty } from 'rxjs/observable/empty';
import { RegistrationService } from './services/registration.service';
import { WishlistService } from './services/wishlist.service';
import { CartService } from './services/cart.service';
import { CheckoutService } from './services/checkout.service';
import { PaymentresponseService } from './services/paymentresponse.service';
import { SearchService } from './services/Search.service';
import { CommonService } from './services/common.service';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SubcategoryComponent } from './subcategory/subcategory.component';
import { DialogComponent } from './dialog/dialog.component';
import { GloballoginComponent } from './globallogin/globallogin.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CheckoutSuccessComponent } from './checkout/checkout-success/checkout-success.component';
import { PaypalComponent } from './payments/paypal/paypal.component';
import { SagepayComponent } from './payments/sagepay/sagepay.component';
import { BankComponent } from './payments/bank/bank.component';
import { DekoComponent } from './payments/deko/deko.component';
import { PaymentresponseComponent } from './payments/paymentresponse/paymentresponse.component';
import { SearchComponent } from './search/search.component';
import { SafePipe } from './safe.pipe';
import { ClickOutsideModule } from 'ng4-click-outside';
import { NotfoundComponent } from './notfound/notfound.component';
import { ErrormessageComponent } from './errormessage/errormessage.component';
import { RecoverPasswordComponent } from './recover-password/recover-password.component';
import { SitemapComponent } from './sitemap/sitemap.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MetadataComponent } from './metadata/metadata.component';
import { FavouritesComponent } from './my-acount/favourites/favourites.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    MenuComponent,
    FooterComponent,
    FavouritesComponent,
    MobilemenuComponent,
    ContactusComponent,
    RegistrationComponent,
    LoginComponent,
    PagesnproductsComponent,
    SubcategoryComponent,
    DialogComponent,
    WishlistComponent,
    CartComponent,
    AddressBookComponent,
    OrdersComponent,
    DetailsComponent,
    OrderDetailComponent,
    CheckoutComponent,
    CheckoutSuccessComponent,
    PaypalComponent,
    SagepayComponent,
    BankComponent,
    DekoComponent,
    PaymentresponseComponent,
    GloballoginComponent,
    SearchComponent,
    SafePipe,
    NotfoundComponent,
    RecoverPasswordComponent,
	ErrormessageComponent,
	SitemapComponent,
	ChangePasswordComponent,
	MetadataComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpModule,
	ClickOutsideModule,
    RouterModule.forRoot([
     
      { path: 'operate_customer', component: HomeComponent },
      { path: 'contactus.html', component: ContactusComponent },
      { path: 'home',component: HomeComponent },
      { path: '', component: HomeComponent },
      { path: 'registration.html',component: RegistrationComponent },
      { path: 'login.html',component: LoginComponent },
      { path: 'wishlist.html',component: WishlistComponent },
      { path: 'address_book',component:AddressBookComponent },
      { path: 'order_list',component:OrdersComponent },
      { path: 'profile', component:DetailsComponent },  
      /*{ path: 'paypal', component:PaypalComponent },  
      { path: 'sagepay', component:SagepayComponent },  
      { path: 'deko', component:DekoComponent },  
      { path: 'paymentresponse.html',component:PaymentresponseComponent },*/
      { path: 'order_details/:id',component:OrderDetailComponent },
      { path: 'sitemap.html',component: SitemapComponent },
	  { path: 'cart.html',component: CartComponent },
      { path: 'checkout.html',component: CheckoutComponent },
      { path: 'checkout-success.html',component: CheckoutSuccessComponent },
      { path: 'search.html',component:SearchComponent },
	  { path: 'errormsg.html', component:ErrormessageComponent },
	  { path: 'recover-password.html', component:RecoverPasswordComponent },
	  { path: 'recover_password', component:ChangePasswordComponent },
      { path: 'engagement-rings', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'diamond-rings', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'wedding-rings', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'diamond-earrings', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'diamond-pendants', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'gemstone', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'diamond-bracelets', pathMatch: 'full' ,component: SubcategoryComponent },
      { path: 'collection/:slug', component: PagesnproductsComponent },
      { path: ':slug',component: PagesnproductsComponent },
      { path: ':slug/:name1',component: SubcategoryComponent },
      { path: ':slug/:name1/:name2',component: SubcategoryComponent },
      { path: ':slug/:name1/:name2/:name3',component: SubcategoryComponent },
      { path: ':slug/:name1/:name2/:name3/:name4',component: SubcategoryComponent },
    ]),
    
  ],
  exports:[RouterModule],
  providers: [
        HomeService,
        FilterService,
        FootercontentService,
        LaravelRoutesService,
        SubcategoryService,
		LinkService,
        RegistrationService,
        WishlistService,
        CartService,
        CheckoutService,
        PaymentresponseService,
        SearchService,
		CommonService
      ],
  bootstrap: [AppComponent]
})
export class AppModule { 

}