import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import {Observable} from "rxjs/Observable";
import "rxjs/Rx";
import { environment as env } from './../../environments/environment';
///import { Filter } from "../home/header/filter.model";

@Injectable()
export class FilterService {


  constructor(private http:Http) { }

  getFilter(search):Observable<any> {
    const body = JSON.stringify({search:search});
    // let postdata={
    //   search:search
    // }
    const headers = new Headers({'Content-Type': 'application/json'});
    //return this.http.get(this.localurl+'filter?search='+search)
    return this.http.get(env.ROOT+'quickSearch?search='+search)
    .map(
      (response: Response) => {
        return response.json();
      });
  }
}
