import { TestBed, inject } from '@angular/core/testing';

import { LaravelRoutesService } from './laravel-routes.service';

describe('LaravelRoutesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LaravelRoutesService]
    });
  });

  it('should be created', inject([LaravelRoutesService], (service: LaravelRoutesService) => {
    expect(service).toBeTruthy();
  }));
});
