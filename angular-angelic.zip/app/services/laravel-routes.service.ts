import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import  'rxjs/add/operator/map';
import { Subject }    from 'rxjs/Subject';
import { environment as env } from './../../environments/environment';
//import { Pages } from '../pagesnproducts/pages.model';
@Injectable()
export class LaravelRoutesService {
  
  ROOT = "http://127.0.0.1:8000/api/"; 

  private metaTitle = new Subject<string>();
  metaTitleObservable$ = this.metaTitle.asObservable();

  private metaDesc = new Subject<string>();
  metaDescObservable$ = this.metaDesc.asObservable();



  public resultdata = [];
  public Favdata = [];
  public price = [];
  public rate = [];
  public fav = [];
  public availability = [];
  public respData = []; 
  
  constructor(private http :Http) { }

	staticData(URL) {
		return this.http.get(env.ROOT+'pagesnproducts'+URL).map(
			(response: Response) => {
			return response.json(); 
		});
	}
   
   setDynamicMetaTags(URL) {
      return this.http.get(env.ROOT+'pagesnproducts'+URL).map(
        (response: Response) => {
         this.metaTitle.next(response.json().data[0].metaTitle);
         this.metaDesc.next(response.json().data[0].metaDesc);
          return response;
        });
    }

   getFilteredPrice(para) {
		return this.http.get(env.ROOT+'productPrice'+para).map(
		  (response: Response) => {
			return response.json();
		  });
  }

   addToFavouriteData(para) {
		return this.http.get(env.ROOT+'addToFavourite'+para).map(
		  (response: Response) => {
			return response.json();
		  });
  }
  

   categoryData(URL) {
   
   return this.http.get(env.ROOT+'categorydata'+URL).map(
      (response: Response) => {
        return response.json();
      });
  }

  
  checkproductAvailableInWishlist(URL) {
    fetch(env.ROOT+'productAvailableInWishlist'+URL)
   .then(res => res.json())
   .then(rdata => this.availability.push(rdata))
   return this.availability;
  }

  // saveBagProduct(URL) {
  //   fetch(env.ROOT+'saveBagProducts'+URL)
  //  .then(res => res.json())
  //  .then(rdata => this.respData.push(rdata))
  //  return this.respData;
  // }

  saveBagProduct(URL)
  {
    return this.http.get(env.ROOT+'saveBagProducts'+URL).map(
      (response: Response) => {
        return response.json();
      });
    }
}
