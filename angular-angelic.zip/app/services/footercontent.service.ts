import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import {Observable} from "rxjs/Observable";
import { environment as env } from './../../environments/environment';
import "rxjs/Rx";

@Injectable()
export class FootercontentService {

  localurl = "/footercontent/"; 
  public resultdata = [];

  constructor(private http: Http) {
    
   }

   aboutusData() {

     fetch(env.ROOT+this.localurl+'aboutus')
       .then(res => res.json())
       .then(rdata => this.resultdata.push(rdata))
       .catch(err => console.log(err));

       return this.resultdata;
      
       }

       staticData(para) {

        fetch(env.ROOT+this.localurl+'staticPages/'+para)
          .then(res => res.json())
          .then(rdata => this.resultdata.push(rdata))
          .catch(err => console.log(err));
   
          return this.resultdata;
       }                        

}
