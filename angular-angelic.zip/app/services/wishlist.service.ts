import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import { environment as env } from './../../environments/environment';

@Injectable()
export class WishlistService {
  mailid :string;
  public resultdata = [];
  public favdata = [];
  public mails= [];

  
  constructor(private http :Http) { }
 
  staticData(data){
        return this.http.get(env.ROOT+'wishlistData'+data).map(
          (response: Response) => {
            return response.json();
          });
 }

 deletefromFavouriteList(data){
        return this.http.get(env.ROOT+'removeFromFavList'+data).map(
          (response: Response) => {
            return response.json();
          });
 }

  mailWishListItem(mailid) {
   	return this.http.get(env.ROOT+'mailwishList'+mailid).map(
          (response: Response) => {
            return response.json();
          });
  }
  
}
