import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import {Observable} from "rxjs/Observable";
import { Subject }    from 'rxjs/Subject';
import { environment as env } from './../../environments/environment';

@Injectable()
export class CheckoutService {

  ROOT = "http://127.0.0.1:8000/api/";

  public country= [];
  public shipping = [];
  constructor(private http: Http) { }

  private currentToken = new Subject<string>();
  currentTokenObservable$ = this.currentToken.asObservable();

  updateBillingShippingAddr(params)
  {
    return this.http.post(env.ROOT+'updateBillingshipping', params).map(
      (response: Response) => {
        return response.json();
      });
    }

    checkExistorNot(email)
    {
      return this.http.get(env.ROOT+'checkUserEmail'+email).map(
        (response: Response) => {
          return response.json();
        });
      }
  
  updateNotes(note){
 
      return this.http.get(env.ROOT+'updateOrderNotes'+note).map(
        (response: Response) => {
          return response.json();
        });
      }

  checkOrderNotes(note){
        return this.http.get(env.ROOT+'checkOrderNotes'+note).map(
          (response: Response) => {
            return response.json();
          });
        }

	paymentMethods(para){
		return this.http.get(env.ROOT+'payment_methods'+para).map(
		  (response: Response) => {
			return response.json();
		  });
	}
	
	updatePaymentMethods(para){
		return this.http.get(env.ROOT+'updatePaymentMethods'+para).map(
		  (response: Response) => {
			return response.json();
		  });
	}

    shippingMethods(para){
      return this.http.get(env.ROOT+'shipping_methods'+para).map(
        (response: Response) => {
          return response.json();
        });
      }   

      updateShippingMethod(para3){
        return this.http.get(env.ROOT+'customer_shipping_methods'+para3).map(
          (response: Response) => {
            return response.json();
          });
        }   

        
      
      countryList() {
        fetch(env.ROOT+'country_list')
         .then(res => res.json())
        .then(rdata => this.country.push(rdata))
        return this.country;
      }


     getOrderItems(orderid){
        return this.http.get(env.ROOT+'getConfirmOrderDetails'+orderid).map(
          (response: Response) => {
            return response.json();
          });
        }   
        

     ///   This api for all payment data 

     getOrderListItemPayment(tokenid){
      return this.http.get(env.ROOT+'get_order_itemlists_payment'+tokenid).map(
        (response: Response) => {
          return response.json();
        });
      }   

      getCustomerAddr(token){
        return this.http.get(env.ROOT+'get_customer_address'+token).map(
          (response: Response) => {
            return response.json();
          });
        }   
      
        getMarchentToken(para){
          return this.http.get(env.ROOT+'get_sagepay_token'+para).map(
            (response: Response) => { return response.json();
            });
          }  
      
          makeSagepayFinalPayment(para){
            return this.http.get(env.ROOT+'makesagepay_payments'+para).map(
              (response: Response) => { return response.json();
              });
            }  

  getCustomerOrderNumber(para){
        return this.http.get(env.ROOT+'getCustomerOrderNumber'+para).map(
          (response: Response) => { return response.json();
          });
        }  
            
          
          //  these function is alos used in payment gatways component
      getCustomerDataWithoutLogin(data)
      {
        return this.http.get(env.ROOT+'getCustomerDataWithoutLogin'+data).map(
          (response: Response) => {
            return response.json();
          });
        }
      
      getpaymentResponse()
      {
        return this.http.post(env.ROOT+'getPaymentResponse','').map(
          (response: Response) => {
            return response.json();
          });
        }
      
        saveTransactionNumber(data)
        {
          return this.http.post(env.ROOT+'storeTransactionNumber',data).map(
            (response: Response) => {
              return response.json();
            });
          }
          

    //    deko payment getway api

    dekopayment(data)
    {
      return this.http.post(env.ROOT+'dekopaymentdata',data).map(
        (response: Response) => {
          return response.json();
        });
      }
    
   // getting order id for all 3 payment gateways
   
   getOrdercustomerid(data)
   {
     return this.http.get(env.ROOT+'getcustomerorderid'+data).map(
       (response: Response) => {
         return response.json();
       });
     }

 gettingCustomeraddr(data)
   {
     return this.http.get(env.ROOT+'getCustomerAddr'+data).map(
       (response: Response) => {
         return response.json();
       });
     }

     
  getCustBillingandShippingaddr(data)
  {
  return this.http.get(env.ROOT+'billingandshipping'+data).map(
    (response: Response) => {
      return response.json();
    });
  }

	getOrderDetailsService(data)
	{
		return this.http.get(env.ROOT+'getOrderDetails'+data).map(
		  (response: Response) => {
			return response.json();
		  });
	}
	
	updateShippingaddrAsBillingService(data)
	{
		return this.http.get(env.ROOT+'updatesameasbilling'+data).map(
		  (response: Response) => {
			return response.json();
		  });
	}

  updatebillingaddr(data)
  {
    return this.http.get(env.ROOT+'updatebillingaddr'+data).map(
      (response: Response) => {
        return response.json();
      });
    }

    updateshippingaddr(data)
    {
      return this.http.get(env.ROOT+'updateshippingaddr'+data).map(
        (response: Response) => {
          return response.json();
        });
      }


      getCustomerOrderId(param){
        return this.http.get(env.ROOT+'getcustomerorderid'+param).map(
          (response: Response) => {
            return response.json();
          });
        }

	abandoned_carts(param){
	  return this.http.get(env.ROOT+'save_abandoned_cartdata'+param).map(
		(response: Response) => {
		  return response;
		});
	  }

	newsletterSubscribe(param){
    return this.http.get(env.ROOT+'newsletterSubscribe'+param).map(
      (response: Response) => {
        return response;
      });
    }

    getSelectedPaymentMethodDetils(param){
		return this.http.get(env.ROOT+'getSelectedPaymentMethodDetils'+param).map(
		  (response: Response) => {
			return response.json();
		  });
	}
	
	initiatePayment(param){
		return this.http.get(env.ROOT+'initiatePayment'+param).map(
		  (response: Response) => {
			return response.json();
		  });
	}
	
	removeOrderIdAfterConfirm(param){
		return this.http.get(env.ROOT+'removeOrderIdAfterConfirm'+param).map(
		  (response: Response) => {
			return response.json();
		  });
	}
	
	updateVat(param){
		return this.http.get(env.ROOT+'updateVat'+param).map(
		  (response: Response) => {
			return response.json();
		  });
	}
}
