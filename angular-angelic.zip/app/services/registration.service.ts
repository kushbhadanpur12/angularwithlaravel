import { Injectable } from '@angular/core';;
import  'rxjs/add/operator/map';
import { Http, HttpModule, Response, Headers } from "@angular/http";
import { environment as env } from './../../environments/environment';

import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs';


@Injectable()
export class RegistrationService  {

  public resultdata = [];
  
  constructor(private http :Http) { }

  customerLogin(data)
  {
    let headers = new Headers({
      'Content-Type': 'application/json'
      });
    return this.http.post(env.ROOT+'customerlogin',data,{ headers: headers })
    .map(
      (response: Response) => {
        return response.json();
      })
    
    
    }

 staticData(URL) {
     fetch(env.ROOT+'registration')
	  .then(res => res.json())
	  .then(rdata => this.resultdata.push(rdata))
	  return this.resultdata;
   }


  customerRegistration(data)
     {
       return this.http.post(env.ROOT+'registration',data).map(
         (response: Response) => {
           return response.json();
         });
       }



 customerLoginWithToken(data)
    {
      return this.http.post(env.ROOT+'customerData',data).map(
        (response: Response) => {
          return response.json();
        });
      }

  updateUserIdSessiontbl(data)
	{
		var token = localStorage.getItem('token');
	     return this.http.post(env.ROOT+'update_session_data_table?token='+token,data).map(
		(response: Response) => {
		  return response.json();
		});
	  }
	  
	  
	 
	changedPassword(data)
	{
		 return this.http.post(env.ROOT+'changedPassword',data).map(
		  (response: Response) => {
		  return response.json();
		});
	}
	
	
	generateDynamicJsonToken(data)
	{
		 return this.http.post(env.ROOT+'dynamicjsontoken',data).map(
		  (response: Response) => {
		  return response.json();
		});
	}
         
  forgetPassword(data)
	{
		let tokenid = localStorage.getItem('tokenid');
		let tokenkey = localStorage.getItem('tokenkey');
		return this.http.post(env.ROOT+'recoverPassword?tokenid='+tokenid+'&tokenkey='+tokenkey,data).map(
		(response: Response) => {
		  return response.json();
		});
	}
	
  checkChangedPasswordToken(para)
    {
      return this.http.get(env.ROOT+'checkChangedPasswordToken'+para).map(
        (response: Response) => {
          return response.json();
        });
      }
  
}
