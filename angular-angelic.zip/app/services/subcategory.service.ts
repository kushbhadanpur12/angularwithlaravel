import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import { environment as env } from './../../environments/environment';

@Injectable()
export class SubcategoryService {

  ROOT = "http://127.0.0.1:8000/api/"; 

  public resultdata = [];
  public styledata = [];
  public shapedata = [];
  public mensdata = [];
  public ladiesdata = [];
  public metaldata = [];
  public stonedata = [];
  public categoryFilters = [];
  
  
  constructor(private http :Http) { }

/*  subCategoryService(URL) {

    fetch(env.ROOT+'subCategorydata'+URL)
   .then(res => res.json())
   .then(rdata => this.resultdata.push(rdata))
   return this.resultdata;
  }*/

   subCategoryService(data){
        return this.http.get(env.ROOT+'subCategorydata'+data).map(
          (response: Response) => {
            return response.json();
          });
   }



  styleAttribute() {
    fetch(env.ROOT+'styleAttribute')
   .then(res => res.json())
   .then(rdata => this.styledata.push(rdata))
   return this.styledata;
  }

  shapeAttribute() {
    fetch(env.ROOT+'shapeAttribute')
   .then(res => res.json())
   .then(rdata => this.shapedata.push(rdata))
   return this.shapedata;
  }

  metalAttribute() {
    fetch(env.ROOT+'metalAttribute')
   .then(res => res.json())
   .then(rdata => this.metaldata.push(rdata))
   return this.metaldata;
  }
  
  stoneTypeAttribute() {
    fetch(env.ROOT+'stoneTypeAttribute')
   .then(res => res.json())
   .then(rdata => this.stonedata.push(rdata))
   return this.stonedata;
  }

  MensAttribute() {
    fetch(env.ROOT+'MensAttribute')
   .then(res => res.json())
   .then(rdata => this.mensdata.push(rdata))
   return this.mensdata;
  }

  LadiesAttribute() {
    fetch(env.ROOT+'LadiesAttribute')
   .then(res => res.json())
   .then(rdata => this.ladiesdata.push(rdata))
   return this.ladiesdata;
  }


  categoryFiltersFn(cat) {
    fetch(env.ROOT+'categoryFilters?cat='+cat)
   .then(res => res.json())
   .then(rdata => this.categoryFilters.push(rdata))
   return this.categoryFilters;
  }
  
}
