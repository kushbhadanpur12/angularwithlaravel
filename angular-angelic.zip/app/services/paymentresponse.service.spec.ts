import { TestBed, inject } from '@angular/core/testing';

import { PaymentresponseService } from './paymentresponse.service';

describe('PaymentresponseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PaymentresponseService]
    });
  });

  it('should be created', inject([PaymentresponseService], (service: PaymentresponseService) => {
    expect(service).toBeTruthy();
  }));
});
