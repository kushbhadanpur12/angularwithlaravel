import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import { environment as env } from './../../environments/environment';

@Injectable()
export class CommonService {

  constructor(private http :Http) { }
  
    getSitemapData(data){
        return this.http.get(env.ROOT+'getsitemapdata'+data).map(
          (response: Response) => {
            return response.json();
          });
   }

   check_user_islogedIn(data){
        return this.http.get(env.ROOT+'get_loginuserdetails?token='+data).map(
          (response: Response) => {
            return response.json();
          });
   }


}
