import { Injectable } from '@angular/core';
import { Http ,Response } from "@angular/http";
import  'rxjs/add/operator/map';
import { Subject }    from 'rxjs/Subject';
import { environment as env } from './../../environments/environment';

@Injectable()
export class CartService {

  ROOT = env.ROOT+"";
  
	private cartDetailForHeader = new Subject<string>();
	cartDetailForHeaderObservable$ = this.cartDetailForHeader.asObservable();

  public resultdata = [];
  public result1 = [];
  public result112 = [];
  public abn_cart = [];
  constructor(private http :Http) { }

  
  getcartItems(URL) {
    /*fetch(env.ROOT+'allcartData'+URL)
   .then(res => res.json())
   .then(rdata =>this.resultdata.push(rdata))
   return this.resultdata;*/
   
	return this.http.get(env.ROOT+'allcartData'+URL).map(
          (response: Response) => {
		  	this.cartDetailForHeader.next(response.json());
            return response.json();
          });
  }

  removeOrderItems(URL) {
    fetch(env.ROOT+'removeOrderItem'+URL)
   .then(res => res.json())
   .then(rdata =>this.resultdata.push(rdata))
   return this.resultdata;
  }

  updateEngData(URL) {
    fetch(env.ROOT+'SaveEengravingData'+URL)
   .then(res => res.json())
   .then(rdata =>this.result1.push(rdata))
   return this.result1;
   	
  }

  updateQuantity(URL) {
     return this.http.get(env.ROOT+'itemQuantityData'+URL).map(
        (response: Response) => {
               return response.json();
          }
        );
  }

  updateengraving(URL) {
     return this.http.get(env.ROOT+'updatEengraving/'+URL).map(
        (response: Response) => {
               return response.json().order_item;
          }
        );
  }

  insertAdandonCart(URL) {
    fetch(env.ROOT+'SaveAdandonCart'+URL)
   .then(res => res.json())
   .then(rdata =>this.abn_cart.push(rdata))
   return this.abn_cart;
  }
  
  submitCouponCode(params){
  	return this.http.get(env.ROOT+'applyCoupon'+params).map(
        (response: Response) => {
               return response;
          }
        );
  }
  
  removeCouponCode(params){
  	return this.http.get(env.ROOT+'removeCoupon'+params).map(
        (response: Response) => {
               return response;
          }
        );
  }
  

}
