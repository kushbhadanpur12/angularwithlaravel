import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import { environment as env } from './../../environments/environment';

@Injectable()
export class SearchService {

  public resultdata     = [];
  public styledata      = [];
  public shapedata      = [];
  public mensdata       = [];
  public ladiesdata     = [];
  public metaldata      = [];
  public stonedata      = [];
  
  
  constructor(private http :Http) { }

  subCategoryService(URL) {

    fetch(env.ROOT+'search_category'+URL)
   .then(res => res.json())
   .then(rdata => this.resultdata.push(rdata))
   return this.resultdata;
  }

  styleAttribute() {
   return this.http.get(env.ROOT+'styleAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }

  shapeAttribute() {
   return this.http.get(env.ROOT+'shapeAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }

  metalAttribute() {
    return this.http.get(env.ROOT+'metalAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }
  
  stoneTypeAttribute() {
   return this.http.get(env.ROOT+'stoneTypeAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }

  MensAttribute() {
   return this.http.get(env.ROOT+'MensAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }

  LadiesAttribute() {
   	return this.http.get(env.ROOT+'LadiesAttribute').map(
            (response: Response) => {
              return response.json();
            });
  }

  searchService(searchStr,attr_opt,sortby,perPage,current_page) {
   return this.http.get(env.ROOT+'searchStr?searchStr='+searchStr+'&attr_opt='+attr_opt+'&sortby='+sortby+'&perPage='+perPage+'&page='+current_page).map(
            (response: Response) => {
              return response.json();
            });
  }
  
}
