import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

import { Router, RouterModule, ActivatedRoute } from '@angular/router';
declare var jquery:any;
declare var $ :any;
declare var sitemapToggle:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-sitemap',
  templateUrl: './sitemap.component.html',
  styleUrls: ['./sitemap.component.css']
})
export class SitemapComponent implements OnInit {

  constructor(private common: CommonService,private route: Router, private metadt: MetadataComponent, private linkmd: LinkService) { }
  results:any;
  staticpages:any;
  public islogedInUser :boolean = false;

  ngOnInit() {
  	this.metadt.setMetaTitle('Sitemap');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'sitemap.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
      var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.route.navigate(['recover_password']); 
        }
	  let token = localStorage.getItem('token');
	  if(token){
       this.common.check_user_islogedIn(token).subscribe( (response) => { 
		if(response.statusCode==200){
		  	this.islogedInUser = true;
		 }
       });
	   }
		let tokenid = localStorage.getItem('tokenid');
		let tokenkey = localStorage.getItem('tokenkey');
		let url = '?tokenid='+tokenid+'&tokenkey='+tokenkey;
		this.common.getSitemapData(url).subscribe( (response) => { 
		console.log(response);
		this.results =  response;
		this.staticpages =  response.staticPage;
	  });
  
  }
  
  toggleContent(id){
     sitemapToggle(id);
  }

}
