import { Component, OnInit } from '@angular/core';
import { SearchService } from '../services/Search.service';
import {BrowserModule} from '@angular/platform-browser';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { empty } from 'rxjs/observable/empty';
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeService } from '../home.service';
import { Subscription }   from 'rxjs/Subscription';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var jquery:any;
declare var $ :any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  form: FormGroup;
  styleAttr=[];
  ladiesAttr=[];
  mensAttr=[];
  metalAttr=[];
  stoneAttr=[];
  shapeAttr=[];
  searchstr:any;
  sortby:any;
  perPage:any;
  current_page:any;
  results:any;
  attr_opt:any;
  subscription:any;
  customercurrncy:any;
  cust_currency:any;
  public rtOptVal:any;

  constructor(private findservice : SearchService, private router : ActivatedRoute, private fb: FormBuilder,private route: Router, private homeservice :HomeService, private metadt: MetadataComponent, private linkmd: LinkService) { }


  ngOnInit() {
    var canonicalurl = env.baseURL + 'search.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
       var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.route.navigate(['recover_password']); 
        }


	this.router.queryParams.subscribe(params => {
		if(params['searchstr']!='' && params['searchstr']!=undefined){
			$(".catLoader").show();
			this.searchstr = params['searchstr'];
			
			this.metadt.setMetaTitle('Search Results for \''+this.searchstr+'\'');
			this.metadt.setMetaDesc('Search Results for &#039;'+this.searchstr+'&#039');
			
			if(params['attr_opt']!='' && params['attr_opt']!=undefined){
				this.attr_opt = params['attr_opt'];
			}else{
				this.attr_opt = '';
			}
			
			if(params['sortby']!='' && params['sortby']!=undefined){
				this.sortby = params['sortby'];
			}else{
				this.sortby = 'recommended-asc';
			}
			
			if(params['perPage']!='' && params['perPage']!=undefined){
				this.perPage = params['perPage'];
			}else{
				this.perPage = 48;
			}
			
			if(params['current_page']!='' && params['current_page']!=undefined){
				this.current_page = params['current_page'];
			}else{
				this.current_page = 1;
			}

			this.findservice.searchService(this.searchstr,this.attr_opt,this.sortby,this.perPage,this.current_page).subscribe(res=>{
				this.results = res;
				
				console.log(this.rtOptVal);
				
				$(".catLoader").hide();
				$('input[name="substring"]').val('');
				$('input[name="substring"]').next('div').hide();
				
				this.findservice.styleAttribute().subscribe(res=>{
					this.styleAttr = res;
				});
				this.findservice.shapeAttribute().subscribe(res=>{
					this.shapeAttr = res;
				});
				this.findservice.metalAttribute().subscribe(res=>{
					this.metalAttr = res;
				});
				this.findservice.stoneTypeAttribute().subscribe(res=>{
					this.stoneAttr = res;
				});
				this.findservice.MensAttribute().subscribe(res=>{
					this.mensAttr = res;
				});
				this.findservice.LadiesAttribute().subscribe(res=>{
					this.ladiesAttr = res;
				});
			});
		}
	});
	
	this.subscription = this.homeservice.currencyObservable$.subscribe(
        res => {
         this.customercurrncy = res;
        var newwe = this.customercurrncy.customer_currency;
     
         this.cust_currency = JSON.parse(this.customercurrncy.customer_currency);
         
      });
  }
  
	searchFilter(attr_id,opt_id){
		
		var ele = $("#opt"+opt_id);
		if(ele.is(':checked')){
		  ele.prop('checked', false);
		  $(this).removeClass('checked');
		} else {
		  ele.prop('checked', true);
		  $(this).addClass('checked');
		}
		
		var attropt = "";
		
		$('.searchattr').each(function(index) 
		{
			if($(this).is(':checked')){
				var attrid = parseInt($(this).attr("attr_id"));
				attropt = attropt + attrid + ',' + parseInt($(this).val()) + ':';
			}
		});
		this.attr_opt = attropt;
		
		this.router.queryParams.subscribe(params => {
			if(params['searchstr']!='' && params['searchstr']!=undefined){
				this.searchstr = params['searchstr'];
				
				if(params['sortby']!='' && params['sortby']!=undefined){
					this.sortby = params['sortby'];
				}else{
					this.sortby = $('#sortby').val();
				}
				
				if(params['perPage']!='' && params['perPage']!=undefined){
					this.perPage = params['perPage'];
				}else{
					this.perPage = $('#perPage').val();
				}
				
				this.current_page = 1;
				
				this.route.navigate(['/search.html'], { queryParams: { searchstr: this.searchstr, attr_opt:this.attr_opt, sortby:this.sortby, perPage:this.perPage, current_page:this.current_page } });
			}
		});
	}
	
	toggleDiv(div){
		$('#'+div).toggle();
	}
	
	searchSortBy(sortby){
		var attropt = "";
		$('.searchattr').each(function(index) 
		{
			if($(this).is(':checked')){
				var attrid = parseInt($(this).attr("attr_id"));
				attropt = attropt + attrid + ',' + parseInt($(this).val()) + ':';
			}
		});
		this.attr_opt = attropt;
		
		this.router.queryParams.subscribe(params => {
			if(params['searchstr']!='' && params['searchstr']!=undefined){
				this.searchstr = params['searchstr'];
				
				this.sortby = sortby;
				
				if(params['perPage']!='' && params['perPage']!=undefined){
					this.perPage = params['perPage'];
				}else{
					this.perPage = $('#perPage').val();
				}
				
				this.current_page = 1;
				
				this.route.navigate(['/search.html'], { queryParams: { searchstr: this.searchstr, attr_opt:this.attr_opt, sortby:this.sortby, perPage:this.perPage, current_page:this.current_page } });
				$('#sortbyDiv').hide();
			}
		});
	}
	
	searchPerPage(perpage){
		var attropt = "";
		$('.searchattr').each(function(index) 
		{
			if($(this).is(':checked')){
				var attrid = parseInt($(this).attr("attr_id"));
				attropt = attropt + attrid + ',' + parseInt($(this).val()) + ':';
			}
		});
		this.attr_opt = attropt;
		
		this.router.queryParams.subscribe(params => {
			if(params['searchstr']!='' && params['searchstr']!=undefined){
				this.searchstr = params['searchstr'];
				
				if(params['sortby']!='' && params['sortby']!=undefined){
					this.sortby = params['sortby'];
				}else{
					this.sortby = $('#sortby').val();
				}
				
				this.current_page = 1;
				
				this.perPage = perpage;
				
				this.route.navigate(['/search.html'], { queryParams: { searchstr: this.searchstr, attr_opt:this.attr_opt, sortby:this.sortby, perPage:this.perPage, current_page:this.current_page } });
				$('#perPageDiv').hide();
			}
		});
	}
	
	pager(page){
		var attropt = "";
		$('.searchattr').each(function(index) 
		{
			if($(this).is(':checked')){
				var attrid = parseInt($(this).attr("attr_id"));
				attropt = attropt + attrid + ',' + parseInt($(this).val()) + ':';
			}
		});
		this.attr_opt = attropt;
		
		this.router.queryParams.subscribe(params => {
			if(params['searchstr']!='' && params['searchstr']!=undefined){
				this.searchstr = params['searchstr'];
				
				if(params['sortby']!='' && params['sortby']!=undefined){
					this.sortby = params['sortby'];
				}else{
					this.sortby = $('#sortby').val();
				}
				
				if(params['perPage']!='' && params['perPage']!=undefined){
					this.perPage = params['perPage'];
				}else{
					this.perPage = $('#perPage').val();
				}
				
				this.current_page = page;
				
				this.route.navigate(['/search.html'], { queryParams: { searchstr: this.searchstr, attr_opt:this.attr_opt, sortby:this.sortby, perPage:this.perPage, current_page:this.current_page } });
				$('#perPageDiv').hide();
			}
		});
		
		$('html, body').animate({
			scrollTop: $('#page-title').offset().top
		  }, 500);
	}

}