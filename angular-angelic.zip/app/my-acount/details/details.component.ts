import { Component, OnInit ,Input, Output, EventEmitter ,AfterViewInit} from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { AbstractControl} from '@angular/forms';
import { HomeService } from '../../home.service';
import { RegistrationService } from '../../services/registration.service';
import { RouterModule, Routes, Router}  from '@angular/router';
import { MetadataComponent } from '../../metadata/metadata.component';
import { environment as env } from '../../../environments/environment';
import { LinkService } from '../../services/link.service';

declare var $:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})

export class DetailsComponent implements OnInit ,AfterViewInit  {

	
	@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
	
	form: FormGroup;
	mycss :boolean = false;
	registererror :boolean = false;
	successfullyregister :boolean = false;
	public succmsg:boolean = false;
	public shouldShow :boolean = false;
	public shouldShow1 :boolean = false;
	public shouldShow2 :boolean = false;
	public hideupdate :boolean = false;
	public emailexist :boolean = false;
	public showDialog :boolean = false;
 	email: string;
	password: any;
	password_conf: string;
	cust_id: string;
	cemail: string;
	res:any;
	customerinfo:any;
  

  constructor(private homeservice: HomeService,  private router: Router, private register: RegistrationService, private metadt: MetadataComponent, private linkmd: LinkService) { }

  ngOnInit() {
    this.metadt.setMetaTitle('Account details');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'profile';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);

       var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }else{
		
				var token = localStorage.getItem('token');
				let senddata = { token:token }
				this.register.customerLoginWithToken(senddata).subscribe( (response) => { this.customerinfo = response;  
				this.email = response.email;
				if(token =='' || token == null || token == undefined){
				this.router.navigate(['/login.html']);
				}	 
		});
		}
  	
    this.form = new FormGroup(
      {
        email: new FormControl('',[Validators.required,Validators.email]),
        password: new FormControl(''),
        password_conf: new FormControl('')
      },{
        validators: this.MatchPassword 
      }
    );
    
  }

ngAfterViewInit() {

   let succ = localStorage.getItem('register_success_msg');
      if(succ!= null && succ!= undefined){
		    this.hideupdate= true;
			this.clientClass.emit();
			this.Clientmessage.emit();
			localStorage.removeItem('register_success_msg');
			setTimeout(()=>{ this.hideupdate= false; },5000);
	  }

}

  MatchPassword(AC: AbstractControl) {
    let password = AC.get('password').value; // to get value in input tag
    let confirmPassword = AC.get('password_conf').value; // to get value in input tag
     if(password != confirmPassword) {
	// console.log('false');
         AC.get('password_conf').setErrors( {MatchPassword: true} )
     } else {
         //console.log('true');
         return null

   }
 }


somethingChanged(form){
/*  if(this.form.get('email').hasError('required') || (!this.form.get('email').hasError('required') && 
  (this.form.get('email').hasError('email'))|| this.form.get('email').hasError('pattern'))){
    this.shouldShow = true;
  }else{
    this.shouldShow = false;
  }

  if(this.form.get('password').hasError('required')){
    this.shouldShow1 = true;
  }else{
    this.shouldShow1 = false;
  }*/
}

 deletedUserDelete(){
 
    let token  = localStorage.getItem('token');
    let url = '?token='+token;
    this.homeservice.deleteUserProfile(url).subscribe( (res) => { res;
	localStorage.removeItem('token');
	localStorage.removeItem('tokenid');
	localStorage.removeItem('cid');
	localStorage.removeItem('cname');
	localStorage.removeItem('cemail');
	
	
    this.router.navigate(['/']);
	
	 });
	 
 }
  add_profile(form) {

    this.password = form.value.password;   
    this.email = form.value.email;     
	
     if(this.form.valid){
	       	var token = localStorage.getItem('token');
			let postdata = {  email:this.email, password:this.password,token:token  }
			this.homeservice.updateProfile(postdata).subscribe( (res) => {  console.log(res)
			this.email = res.email;
			
			this.clientClass.emit();
			this.Clientmessage.emit();
			
			if(res.statusCode==205){
			     this.emailexist = true
			}else if(res.statusCode==200){
			     this.hideupdate = true;
			}
			setTimeout(()=>{ this.hideupdate = false;
							 this.emailexist = false },
						3000)
			});
            form.reset();  
     }else{
	 
         
	    if(this.form.controls.password_conf.errors.MatchPassword){
			   this.shouldShow2 = true;
			   this.mycss = true;
		}else{
			    this.shouldShow2 = false;
				
			}
     }
  }

}
