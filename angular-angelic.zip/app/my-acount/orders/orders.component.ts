import { Component, OnInit } from '@angular/core';
import { HomeService } from '../../home.service';
import { RouterModule, Routes, Router}  from '@angular/router';
import { MetadataComponent } from '../../metadata/metadata.component';
import { environment as env } from '../../../environments/environment';
import { LinkService } from '../../services/link.service';

declare var jquery:any;
declare var $ :any;
declare var toggleOrderItem:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
  allOrder = [];
  count:any;
  
  constructor( private homeservice: HomeService, private router: Router, private metadt: MetadataComponent, private linkmd: LinkService ) { }
  ngOnInit() {
    this.metadt.setMetaTitle('Orders');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'order_list';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
      var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }


  	var token = localStorage.getItem('token');
	if(token=='' || token==null || token==undefined){
		this.router.navigate(['/login.html']);
	}
	
    let pid = localStorage.getItem('cid');
    this.homeservice.getOrderData(pid)
    .subscribe( (response) => {
        this.allOrder = response.orders
        this.count = response.count
		if(response.count==0){
		this.count = 'No';
		}
      },
      (error: Response) => console.log(error)
  );

  }

  ordertoggle(id){
    toggleOrderItem(id);
 

  }
}
