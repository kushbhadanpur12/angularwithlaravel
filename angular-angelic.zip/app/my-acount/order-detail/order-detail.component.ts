import { Component, OnInit } from '@angular/core';
import {RouterModule, Routes, Router, ActivatedRoute, Params} from '@angular/router';
import { Printd } from 'printd';
import  * as global  from './../../global.component';
import { HomeService } from '../../home.service';
import { CheckoutService } from '../../services/checkout.service';
import { MetadataComponent } from '../../metadata/metadata.component';
import { environment as env } from '../../../environments/environment';
import { LinkService } from '../../services/link.service';

declare var getCookie:any;


@Component({
  providers:[MetadataComponent ],
  selector: 'app-order-detail',
  templateUrl: './order-detail.component.html',
  styleUrls: ['./order-detail.component.css']
})
export class OrderDetailComponent implements OnInit {

  allOrder:any;
  public shippingAddr = [];
  public billingAddr = [];
  public orderItems = [];
  public order = [];
  error : any;
  public showorder:boolean = true;
  
  constructor(private activatedRoute: ActivatedRoute, private router: Router, private homeservice:HomeService, private orderList: CheckoutService, private metadt: MetadataComponent, private linkmd: LinkService) { }

  ngOnInit() {
    this.metadt.setMetaTitle('Order Detail');
	this.metadt.setMetaDesc('Angelic Diamonds');
	

     var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }
  	
	var token = localStorage.getItem('token');
	if(token=='' || token==null || token==undefined){
		this.router.navigate(['/login.html']);
	}

  
	  this.activatedRoute.params.subscribe((params: Params) => {
		  let orderId =  params['id'];
		  
		  var canonicalurl = env.baseURL + 'order_details/'+orderId;
			this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
		  let token = localStorage.getItem('token');
		  let para = '?orderId='+orderId+'&token='+token;
	
		  this.homeservice.getCustomerOrderDetails(para).subscribe( (response) => { 
		  	
			  if(response.statusText=='Success'){
			  		this.showorder = true;
					console.log(response.order.order_invoice_item_details);
					console.log(this.showorder);
					
					this.orderItems = response.order.order_invoice_item_details;
					
					this.order = response.order; 
					this.shippingAddr = response.order.order_shipping_details; 
					this.billingAddr = response.order.order_billing_details; 
		  	  }else{
			  	this.showorder = false;
			  }
		  });
	  
	  });
	}
	
	printInvoiceFn(){
		const d: Printd = new Printd();
		d.print( document.getElementById('myelement'), global.invoice )
	}
}
