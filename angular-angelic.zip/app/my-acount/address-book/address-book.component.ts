import { Component, OnInit, OnChanges,Input, Output, EventEmitter  } from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { RouterModule, Routes, Router}  from '@angular/router';
import { HomeService } from '../../home.service';
import { MetadataComponent } from '../../metadata/metadata.component';
import { environment as env } from '../../../environments/environment';
import { LinkService } from '../../services/link.service';

declare var $:any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-address-book',
  templateUrl: './address-book.component.html',
  styleUrls: ['./address-book.component.css']
})
export class AddressBookComponent implements OnInit {

      form: FormGroup;
      fname:string;
      lname: string;
      addr1: string;
      addr2: string;
      city: string;
      post_code: string;
      phone: string;
      country: string;
      cust_id: string;
      showValue: boolean = false;
      mycss :boolean = false;
      setData : any;
      country_id:number;
      popData: any;
      result=[];
      public closepopup :boolean = true;
      addrId:number;
      countrylisting:any;
      public firstnameldShow :boolean = false;
      public lastnameldShow: boolean = false;
      public streetIdShow: boolean = false;
      public cityIdShow: boolean = false;
      public zipcodeIdShow: boolean = false;
      public phoneIdShow: boolean = false;
	  public shouldShow: boolean = false;
	  public showDialog: boolean = false;
	  
	  
	 
	  
    @Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	  @Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
     
  constructor(private homeservice: HomeService,  private router: Router, private metadt: MetadataComponent, private linkmd: LinkService) { }

  ngOnInit() {
    this.metadt.setMetaTitle('Address book');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'address_book';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);

       var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }


	var token = localStorage.getItem('token');
	if(token=='' || token==null || token==undefined){
		this.router.navigate(['/login.html']);
	}
	
    this.cust_id = localStorage.getItem('cid');
    this.homeservice.getAddrData(this.cust_id).
      subscribe(
        (response) => {
          this.result = response
          console.log(response);
        },
        (error: Response) => console.log(error)
    );

    this.form = new FormGroup({
      
      // firstname: new FormControl('',[Validators.required,Validators.firstname, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"), Validators.minLength(7)]),
      fname: new FormControl('',Validators.required),
      lname: new FormControl('',Validators.required),
      addr1: new FormControl('',Validators.required),
      addr2: new FormControl(''),
      city: new FormControl('', Validators.required),
      post_code: new FormControl('',Validators.required),
      phone: new FormControl('',Validators.required),
      country_id: new FormControl('',Validators.required)
      
    });
     this.cust_id = localStorage.getItem('cid');
     this.countrylisting = this.homeservice.countryList();
	 

     
  }

  getData(id) {
    //console.log(id);
    this.addrId = id;
    this.homeservice.getCustAddrData(id)
     .subscribe(
      (response) => {
        this.fname = response[0].fname
        this.lname = response[0].lname
        this.addr1 = response[0].addr1
        this.addr2 = response[0].addr2
        this.city = response[0].city
        this.post_code = response[0].post_code
        this.phone = response[0].phone
        this.country_id = response[0].country_id
       
      },
      (error: Response) => console.log(error)
    );
    this.showValue = true;
  }


  checkvalue(){
    if(this.fname =='' || this.fname === undefined){
      this.firstnameldShow = true;
    }else{
    }

    if(this.lname ==''|| this.lname === undefined) {
        this.lastnameldShow = true;
    } else {

    }

    if(this.addr1 == '' || this.addr1 === undefined) {
      this.streetIdShow = true;
    } else {

    }

    if(this.city == '' || this.city === undefined) {
      this.cityIdShow = true;
    } else {

    }

    if(this.post_code == '' || this.post_code === undefined) {
      this.zipcodeIdShow = true;
    } else {

    }

    if(this.phone == '' || this.phone === undefined) {
      this.phoneIdShow = true;
    } else {

    }
  }



  somethingChanged(form){
    if(this.form.get('fname').hasError('required') ){
      this.firstnameldShow = true;
    }else{
      this.firstnameldShow = false;
    }

    if(this.form.get('lname').hasError('required') ){
      this.lastnameldShow = true;
    }else{
      this.lastnameldShow = false;
    }

    if(this.form.get('addr1').hasError('required') ) {
      this.streetIdShow = true;
    } else {
      this.streetIdShow = false; 
    }

    // if(this.form.get('addr2').hasError('required') ) {
    //   this.cityIdShow = true;
    // } else {
    //   this.cityIdShow = false;
    // }

    if( this.form.get('city').hasError('required') ) {
      this.zipcodeIdShow = true;
    } else {
      this.zipcodeIdShow = false;
    }

    if( this.form.get('post_code').hasError('required') ) {
      this.zipcodeIdShow = true;
    } else {
      this.zipcodeIdShow = false;
    }
    

    if( this.form.get('phone').hasError('required')) {
        this.phoneIdShow = true;
    } else {
      this.phoneIdShow = false;
    }

 }



  add_Addr(form){
    
    this.fname = form.value.fname;
    this.lname = form.value.lname;
    this.addr1 = form.value.addr1;
    this.addr2 = form.value.addr2;
    this.city = form.value.city;
    this.post_code = form.value.post_code;
    this.phone = form.value.phone;
    this.country_id = form.value.country_id
    
    if(this.form.valid){
      let postdata = {
        fname: this.fname,
        lname: this.lname,
        addr1: this.addr1,
        addr2: this.addr2,
        city: this.city,
        post_code: this.post_code,
        phone: this.phone,
        country: this.country_id
      }
      $(".hideinsert").show();
      this.homeservice.addAddr(postdata,this.cust_id).subscribe( (response) => { response;
	       this.getCustomerData(this.cust_id);
	   });
      
        setTimeout(function(){ $(".hideinsert").hide(); },3000);
      this.form.reset();
      $(".dialog__close-btn").trigger('click');

   
      
  }else {
   this.mycss = true;
 }
    
  }
  
  getCustomerData(cust_id){
  
  this.homeservice.getAddrData(cust_id).subscribe( (response) => { this.result = response }, 
      (error: Response) => console.log(error) );
  
  }
  uodate_Addr(form) {
    //console.log(this.addrId);
    this.fname = form.value.fname;
    this.lname = form.value.lname;
    this.addr1 = form.value.addr1;
    this.addr2 = form.value.addr2;
    this.city = form.value.city;
    this.post_code = form.value.post_code;
    this.phone = form.value.phone;


    if(this.form.valid){
      let postdata = {
        //cust_id: this.cust_id,
        fname: this.fname,
        lname: this.lname,
        addr1: this.addr1,
        addr2: this.addr2,
        city: this.city,
        post_code: this.post_code,
        phone: this.phone,
        country: this.country_id
      }
	  this.clientClass.emit();
	  this.Clientmessage.emit();
	  
      $(".hideupdate").show();
    this.homeservice.updateAddr(postdata,this.addrId) .subscribe((response) => console.log(response) );
    this.getCustomerData(this.cust_id);
    setTimeout(function(){$(".hideupdate").hide(); },4000);
     this.form.reset();
     $(".dialog__close-btn").trigger('click');

     
    }else{
      this.mycss = true;
    }
  }

  getDataDelete(id) {
  
   if (confirm("  Delete this address ?")) {
   
    let result ='';
    $(".hidedelete").show();
    this.homeservice.delete_cust_id(id).subscribe((response) => {response;

	this.Clientmessage.emit();
	this.clientClass.emit();
	
	 });
    setTimeout(function(){$(".hidedelete").hide(); },4000);
        this.getCustomerData(this.cust_id);
   
    }else{
	    return false;
	}
    
   
  }
  newaddrrclicked(){
    this.mycss = false;
    this.form.reset();
    this.country_id = 235;
	console.log( this.country_id);
	
	
  }
 
}
