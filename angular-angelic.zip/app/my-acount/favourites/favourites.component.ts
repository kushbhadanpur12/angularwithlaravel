import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router}  from '@angular/router';
import { MetadataComponent } from '../../metadata/metadata.component';

declare var getCookie:any;
@Component({
  providers:[MetadataComponent ],
  selector: 'app-favourites',
  templateUrl: './favourites.component.html',
  styleUrls: ['./favourites.component.css']
})
export class FavouritesComponent implements OnInit {

  constructor(private router: Router, private metadt: MetadataComponent) { }

  ngOnInit() {
    this.metadt.setMetaTitle('Wishlist');
	this.metadt.setMetaDesc('Angelic Diamonds');
	
     var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }
  	var token = localStorage.getItem('token');
	if(token=='' || token==null || token==undefined){
		this.router.navigate(['/login.html']);
	}
  }

}
