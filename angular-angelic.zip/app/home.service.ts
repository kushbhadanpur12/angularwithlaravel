import { Injectable } from '@angular/core';
import { Http, Response, Headers } from "@angular/http";
import {Observable} from "rxjs/Observable";
import "rxjs/Rx";
import { Employee } from "./home/Employee.model";
import { Category } from "./home/Category.model";
import { Subject }    from 'rxjs/Subject';
import { RouterModule, Routes, Router}  from '@angular/router';
import 'rxjs/add/operator/catch';
import { environment as env } from './../environments/environment';

@Injectable()
export class HomeService {

		private currencySource = new Subject<string>();
		currencyObservable$ = this.currencySource.asObservable();
		private productIdDetailPage = new Subject<string>();
		productIdDetailObservable$ = this.productIdDetailPage.asObservable();
		aaa:any;
		public currency = [];
		public addr = [];
		public cust_data=[];
		public resultdata=[];
		public res=[];
		public country= [];
  
constructor(private http: Http, private router: Router) { }
	ngOnInit(): void{
	   this.aaa='Hello';
	}

  fetchData(): Observable<Employee[]> {
    return this.http
        .get(env.ROOT+'products')
        .map((response: Response) => {
            return <Employee[]>response.json();
        })
        .catch(this.handleError);
}

allCategoryData(): Observable<Category[]> {
  return this.http
      .get(env.ROOT+'/quickSearch')
      .map((response: Response) => {
          return <Category[]>response.json();
      })
      .catch(this.categoryhandleError);
}

private handleError(error: Response) {
  return Observable.throw(error.statusText);
}

private categoryhandleError(error: Response) {
  return Observable.throw(error.statusText);
}

//  Customer Token Service Function   
getCustomerToken() {
	if(localStorage.getItem('tokenid')){
		return this.http.get(env.ROOT+'CustomerToken?tokenid='+localStorage.getItem('tokenid')).map(
			(response: Response) => {
				if(response.json().new==0){
					this.currencySource.next(response.json().result);
					return response.json().result;
				}else if(response.json().new==1){
					localStorage.setItem('tokenid', response.json().result.tokenid);
					localStorage.setItem('tokenkey', response.json().result.tokenkey);
					window.location.reload();
				}
			});
	}else{
		return this.http.get(env.ROOT+'CustomerToken?tokenid=0').map(
			(response: Response) => {
			  return response.json().result;
			});
	}
}

getcartItems(URL) {
	return this.http.get(env.ROOT+'allcartData'+URL).map( (response: Response) => {

	//	Array.prototype.slice.call(response.json().products).forEach(function(element) {	productArr.push(element.object_id); });
	
	this.productIdDetailPage.next(response.json().cartPIDs);
		return  response.json();
	});
}

removeOrderItems(URL) {
  fetch(env.ROOT+'removeOrderItem'+URL)
 .then(res => res.json())
 .then(rdata =>this.res.push(rdata))
 return this.res;
}

onFindCurrency(currencyValue) {
  return this.http.get(env.ROOT+'findCurrency?tokenid='+localStorage.getItem('tokenid')+'&currid='+currencyValue).map(
    (response: Response) => {
      return response.json().getCurrency;
  });
}

	logoutCstomer() {
	  	var token = this.getToken();
		return this.http.get(env.ROOT+'logout?token='+token).map(
		  (response: Response) => {
			return response.json();
		  });
	}

	//---------- SERVICES FOR AFTER LOGIN ---------------//
	getOrderDetails(id) {
		var token = this.getToken();
		return this.http.get(env.ROOT+'orderDetailsData/'+id+'?token='+ token).map( (response: Response) => {
			return response.json();
		}).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	getOrderData(cust_id): Observable<any>{
		var token = this.getToken();
		
		return this.http.get(env.ROOT+'orderData/'+cust_id+'?token='+ token).map( (response: Response) => {
			return response.json();
		}).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	addAddr(data,id){
		var token = this.getToken();
		return this.http.post(env.ROOT+'address/'+id+'?token='+ token ,JSON.stringify(data)).map(
		  (response: Response) => {
			return response.json();
		  }).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	getCustAddrData(addr_id) {
		var token = this.getToken();
			return this.http.get(env.ROOT+'cust_address/'+addr_id+'?token='+ token).map( (response: Response) => {
		return response.json().dataAddress;
		}).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	getAddrData(cust_id)
	{
		var token = this.getToken();
		  
		return this.http.get(env.ROOT+'addressData/'+cust_id+'?token='+ token).map( (response: Response) => {
			return response.json().dataAddress;
		}).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	delete_cust_id(id) {
		var token = this.getToken();
		return this.http.get(env.ROOT+'addressDelete/'+id+'?token='+ token).map(
		  (response: Response) => {
			return response.json().message;
		  }).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	
	updateProfile(data) 
	{
		return this.http.post(env.ROOT+'updateProfile',data).map(
		  (response: Response) => {
			return response.json();
		  })
	}
	
	updateAddr(data,id) {
	  	var token = this.getToken();
		return this.http.post(env.ROOT+'updatecustaddress/'+id+'?token='+ token ,JSON.stringify(data)).map(
		  (response: Response) => {
			return response.json();
		  }).catch((error:any) => {
			return Observable.throw(this.checkLogin(error));
		});
	}
	checkLogin(error){
		//console.clear();
		if (error.status === 401 || error.status === 403) {
			localStorage.removeItem('cemail');
			localStorage.removeItem('cname');
			localStorage.removeItem('cid');
			localStorage.removeItem('token');
			this.router.navigate(['/login.html']);
		}
	}
	
	getToken(){
		return localStorage.getItem('token');
	}
	//---------- SERVICES FOR AFTER LOGIN ---------------//
	
	
	//---------- OPERATE AS CUSTOMER ---------------//
	operateCustomer(key,cid) {
	  	var token = this.getToken();
		return this.http.get(env.ROOT+'operateCustomer?key='+key+'&cid='+cid).map(
		  (response: Response) => {
			return response.json();
		});
	}
    quitOperateCustomer(data) 
	{
		return this.http.post(env.ROOT+'operateCustomerQuit',data).map(
		  (response: Response) => {
			return response.json();
		  })
	}
	
	
	//---------- OPERATE AS CUSTOMER ---------------//

	
	//---------- UPDATE CUSTOMER DATA AFTER LOGIN ---------------//
	updateCustomerSessionData() {
		
	  	var token = this.getToken();
	  	let cid = localStorage.getItem('cid');
	  	let tokenid = localStorage.getItem('tokenid');
	    let tokenkey = localStorage.getItem('tokenkey');
	   
		return this.http.get(env.ROOT+'updateCustomerSessionData/'+cid+'?tokenid='+tokenid+'&tokenkey='+tokenkey+'&token='+token).map(
		  (response: Response) => {
			return response.json();
		});
	}
	//---------- UPDATE CUSTOMER DATA AFTER LOGIN ---------------//


	countryList() {
		fetch(env.ROOT+'country_list')
		 .then(res => res.json())
		.then(rdata => this.country.push(rdata))
		return this.country;
	}
	
	getUserDataForContactus() {
	  	let tokenid = localStorage.getItem('tokenid');
	    let tokenkey = localStorage.getItem('tokenkey');
		return this.http.get(env.ROOT+'getUserDataForContactus?tokenid='+tokenid+'&tokenkey='+tokenkey).map(
		  (response: Response) => {
			return response.json();
		});
	}
	
	storeDataOfContactus(data) {
		return this.http.post(env.ROOT+'contactus',data).map(
		  (response: Response) => {
			return response.json();
		});
	}
	
	newsLetterStoreData(data) {
		return this.http.post(env.ROOT+'newsletter',data).map(
		  (response: Response) => {
			return response.json();
		});
	}
	
	deleteUserProfile(data) {
		return this.http.get(env.ROOT+'deleteUserProfile'+data).map(
		  (response: Response) => {
			return response.json();
		});
	}
	
	getCustomerOrderDetails(orderid){
		return this.http.get(env.ROOT+'getCustomerOrderDetails'+orderid).map(
		  (response: Response) => {
			return response.json();
		  });
	}
}