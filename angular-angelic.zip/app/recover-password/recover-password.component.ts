import { Component, OnInit,Input, Output, EventEmitter  } from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { RegistrationService } from '../services/registration.service';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var $:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-recover-password',
  templateUrl: './recover-password.component.html',
  styleUrls: ['./recover-password.component.css']
})
export class RecoverPasswordComponent implements OnInit {

	@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
		
	form: FormGroup;
	email:any;
	linkSenttoMail:any;
	shouldShow:boolean;
	mycss :boolean = false;
	updateToken :boolean = false;
	className:any
	msg=[];
	public glaballogin: boolean = false;

    constructor( private register: RegistrationService, private metadt: MetadataComponent, private linkmd: LinkService ) { }


  ngOnInit() {
  
  	this.metadt.setMetaTitle('Forgot Password');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'recover-password.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);

    this.form = new FormGroup({
      email: new FormControl('',[Validators.required,Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"), Validators.minLength(7)]),  
    });
  }

  checkvalue(){
    let t = this.email;
    if(t =='' || t == undefined){
      this.shouldShow = true;
      this.mycss = true;
     
    }else{

      if(this.form.get('email').hasError('required') || (!this.form.get('email').hasError('required') && 
      (this.form.get('email').hasError('email'))|| this.form.get('email').hasError('pattern'))){
           this.shouldShow = true;
      }else{
        this.shouldShow = false;
      }
    }
  }

  testingMyFunction(){
    console.log('called succesffully ');

  
  }

  recoverPassword(formdata){

    let email = formdata.value.email;
	$('.cartLoader').show();
  
    if(this.form.valid){
      let postdata = { email:email }
      this.register.forgetPassword(postdata).subscribe( response => { response;
		 $('.cartLoader').hide();
		 if(response.statusCode==404){
				$(".err").show();
				this.updateToken = true;
				this.linkSenttoMail = response.msg;
				this.className = 'message_2';
		 }
		  if(response.statusCode==200){
				$(".err").show();
				this.updateToken = true;
				this.linkSenttoMail = response.msg;
				this.className = 'message_1';
		 }
		 setTimeout(()=>{  this.updateToken = false }, 4000);
      });

     }else{
     
     }
    }

   
}
