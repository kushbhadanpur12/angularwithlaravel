export class Pages {

    id: number;
    name :string;
    description : string;
}