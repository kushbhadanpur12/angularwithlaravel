import { Component, NgModule, OnInit, ElementRef ,ViewChild, OnDestroy,ComponentFactoryResolver ,Input, Output, EventEmitter,AfterViewInit } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { BrowserModule} from '@angular/platform-browser';
import { DomSanitizer } from '@angular/platform-browser';
import { Http } from "@angular/http";
import { LaravelRoutesService } from '../services/laravel-routes.service';
import { Router, RouterModule, ActivatedRoute, Params } from '@angular/router';
import { empty } from 'rxjs/observable/empty';
import { ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { environment as env } from '../../environments/environment';
import { HomeService } from '../home.service';
import { CartService } from '../services/cart.service';
import { Subject } from 'Rxjs';
import { SafePipe } from './../safe.pipe';
declare var getCookie:any;
import { MetadataComponent } from '../metadata/metadata.component';
import { LinkService } from '../services/link.service';
import { Subscription } from 'rxjs/Subscription';

import { forEach } from '@angular/router/src/utils/collection';
declare var jquery:any;
declare var $ :any;
declare var jQuery :any;
declare var loadFinanceDetails: any;
declare var FinanceDetails: any;
declare var call_cboxinjs: any;
declare var accordion_head: any;
declare var scrollparoductpage: any;


@Component({
  providers:[MetadataComponent ],
  selector: 'app-pagesnproducts',
  templateUrl: './pagesnproducts.component.html',
  styleUrls: ['./pagesnproducts.component.css']
})
export class PagesnproductsComponent implements OnInit ,AfterViewInit {

		private newString  = new Subject();
		
		@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
		@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
		i:number = 5;
		userDataresults :any;
		prodResults :any;
		category = [];
		myFavourite : any;
		testcur : any;
		public deko_min_total : number;
		public caratValue : number;
		public clearityValue : number;
		public colorValue : number;
		public certificateValue : number;
		public  certificatePname;
		public colorPname;
		public clearityPname;
		public caratPname;
		public ringsizeValue;
		public ringsizePname;
		selectedProduct: any = [];
		selectedProduct2: any = [];
		public priceChanged : boolean = true;
		public financeCondition : boolean ;
		public myvalue1 : boolean = true;
		public showbag : boolean = false;
		public metalshow : boolean = false;
		public Caratdailogshow : boolean = false;
		public Claritydailogshow : boolean = false;
		public Colourdailogshow : boolean = false;
		public Certificatedailog : boolean = false;
		public RingSizedailog : boolean = false;
		public productExist : boolean = false;
		public productAdded : boolean = false;
		public textdata:any;
		public allResponse:any;
		public sessionData = [];
		public recentViewedProd = [];
		public myvalue2 : boolean = true;
		public myvalue3 : boolean = true;
		public myvalue4 : boolean = true;
		currencyObj:any;
		proPresent :any;
		newPrice=[];
		subscription:any;
		subscriptionCart:any;
		customercurrncy:any;
		cust_currency:any;
		currentUrl :any;
		Finprice:any;
		allcartproductlistIds :any;
		public allpIds:any;
		public ppid:any;
		activeDeko = [];
		activeDekoPercent = [];
		activeDekoCode:any;
		var_deposit_percentage:any;
		var_cost_of_goods:any;
		userData:any;
		public p2:number;
		public p3:number;
		public p4:number;
 
  constructor(private LaravelPnP : LaravelRoutesService, private router : ActivatedRoute,private elm: ElementRef , private routers: Router, 
              private homeservice :HomeService, private cartservice : CartService, private http: Http,private sanitizer: DomSanitizer, private metadt: MetadataComponent, private linkmd: LinkService){}

   ngOnInit() {
              this.getReviews(0); 
		      var resetPassToken = getCookie('resetPassToken');
			  if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
				 this.routers.navigate(['recover_password']);	
			  }
           let tid =  localStorage.getItem('tokenid');
           let tokenkey =  localStorage.getItem('tokenkey');
           let para = '?tokenid='+tid+'&tokenkey='+tokenkey;
       
           //this.userDataresults = this.cartservice.getcartItems(para);   
          this.homeservice.productIdDetailObservable$.subscribe(  res => {
			var io = [];
			if(res){Array.prototype.slice.call(res).forEach(function(element) {	if(element.object_id)io.push(element.object_id); });}
			this.allcartproductlistIds = io;
		});
		  
          this.router.params.subscribe(res=>{
          	 let checkUrl = res.slug;
		  	 var canonicalurl = env.baseURL + checkUrl;
			 this.linkmd.createLinkForCanonicalURL(canonicalurl);
		     let tokenid =  localStorage.getItem('tokenid');
        	 let tokenkey =  localStorage.getItem('tokenkey');
		
            checkUrl = res.slug.substring(0, res.slug.lastIndexOf(".html"));
              if(checkUrl.length > 0){

				   this.LaravelPnP.staticData('/'+res.slug + '?tokenid='+tokenid+'&tokenkey='+tokenkey).subscribe(  res => {
					 	this.prodResults = res;
						this.metadt.setMetaTitle(this.prodResults.data[0].metaTitle);
						this.metadt.setMetaDesc(this.prodResults.data[0].metaDesc);
						this.recentViewedProd = this.prodResults.recentViewedProd;						
	
						this.newPrice['variant_price'] = res.defaultPrice;
						this.newPrice['variant_id'] = res.variant_id;

						if(res.payment_detail != undefined && res.payment_detail !=null)
						{
							if(res.payment_detail.min_total)
							{
								this.deko_min_total = parseFloat(res.payment_detail.min_total);
							}

							var Array = res.payment_detail.products.status;
							var counter=0;
						
							for (var items in Array ){
								var arr = { "deko": res.deko[Array[items]], "min_deposite": res.payment_detail.products.min_deposite[Array[items]], "max_deposite": res.payment_detail.products.max_deposite[Array[items]], "step": res.payment_detail.products.step[Array[items]] };
								this.activeDeko.push( arr );
								if(counter==0){
									if(!res.payment_detail.products.step[Array[items]]){
										res.payment_detail.products.step[Array[items]] = 10;
									}
									for(var i=res.payment_detail.products.min_deposite[Array[items]];i<=res.payment_detail.products.max_deposite[Array[items]];(i=i+res.payment_detail.products.step[Array[items]])){
										this.activeDekoPercent.push(i);
										this.activeDekoCode = Array[items];
										this.var_deposit_percentage = i;
									}
								}
								counter = counter+1;
							}
						}
						
						setTimeout(this.selectedAttrs(),2000);
						
						var thiss = this;
						//thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
						thiss.var_cost_of_goods = parseFloat(res.defaultPrice);
						if(res.defaultPrice >= this.deko_min_total){
							thiss.calculateAmounts(this.activeDekoCode,thiss.var_cost_of_goods,this.var_deposit_percentage,0);
						}
						this.activeDeko.slice();
						this.activeDekoPercent.slice();
					});

                   this.LaravelPnP.setDynamicMetaTags('/'+res.slug + '?tokenid='+tokenid+'&tokenkey='+tokenkey).subscribe( (response) => { response; });
                    
              }else{
					 this.LaravelPnP.categoryData('/'+res.slug).subscribe(  res => {
					 	this.category['loading_contenttype'] = res.loading_contenttype;
					 	this.category['data'] = res.data;
						this.metadt.setMetaTitle(res.data[0].metaTitle);
						
						console.log(this.currentUrl);
						var canonicalurl = env.baseURL + this.currentUrl;
						this.linkmd.createLinkForCanonicalURL(canonicalurl);
					 });
             }
            
     });

      if(sessionStorage.getItem("CurrencyVar")){
        this.currencyObj = JSON.parse(sessionStorage.getItem("CurrencyVar"));
      }
	  
      this.subscription = this.homeservice.currencyObservable$.subscribe(
        res => {
         this.customercurrncy = res;
           var newwe = this.customercurrncy.customer_currency;
            this.cust_currency = JSON.parse(this.customercurrncy.customer_currency);
      
      });

       /// getting product id form cart 

	  
       //this.checkProductAddedOrNot();
	 
       this.triggerReviews();
       this.currentUrl = this.routers.url.replace('/', '');
      
       var thiss = this;
       

       // add to bag from wishlist mail     

      this.router.queryParams.subscribe(params => {
       if(params['action']==='add_from_wishlist'){
                  setTimeout(()=>{ $("#cust-btn").trigger("click");},4000);
         }
        });


      // End Add to bag from wishlist
		setTimeout(()=>{ $(".cireviews").trigger("click"); },1500);
		setTimeout(this.toggleProductTabs(),2000);
		

  }
  
	startSlider(){
	$(".CategoryBanner").not(".slick-initialized").slick({
	  dots: false,
	  infinite: false,
	  arrows: true,
	  autoplay: false,
	  speed: 300,
	  slidesToShow: 3,
	  slidesToScroll: 3,
	  responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 3,
			slidesToScroll: 3,
			infinite: true,
			dots: true
		  }
		},
		{
		  breakpoint: 768,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 2
		  }
		},
		{
		  breakpoint: 600,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
	});
	
	
  	 $(".flexslider").not('.slick-initialized').slick({
	  dots: false,
	  infinite: false,
	  arrows: true,
	  autoplay: true,
	  speed: 300,
	  slidesToShow: 1,
	  slidesToScroll: 1,
	  responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1,
			infinite: true,
			dots: true
		  }
		},
		{
		  breakpoint: 600,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
	});
  
	jQuery('div.product-image-gallery a.imgfirst:first').trigger( "click" );
   
	
}

 ngAfterViewInit() {
					
		let tid =  localStorage.getItem('tokenid');
		let tokenkey =  localStorage.getItem('tokenkey');	  
		let proid = localStorage.getItem('addToFavProdId');
		let redir = localStorage.getItem('addToFavProdRedir');
		if((proid!=null && proid!=undefined) && (redir!=null && redir!=undefined))
		{
		setTimeout(()=>{
			let para = '?productId='+proid+'&tokenid='+tid+'&tokenkey='+tokenkey;
			this.LaravelPnP.addToFavouriteData(para).subscribe( (response) => { response ;
		
			if(response.statuscode==208){
		
				this.productExist = true;
				this.clientClass.emit();
				this.Clientmessage.emit();
				setTimeout(()=>{this.productExist = false; },5000);
				localStorage.removeItem('addToFavProdId');
				localStorage.removeItem('addToFavProdRedir');
		
			}else if(response.statuscode==201){
		
				this.productAdded = true;
				this.clientClass.emit();
				this.Clientmessage.emit();
				setTimeout(()=>{this.productAdded = false; },5000);
				localStorage.removeItem('addToFavProdId');
				localStorage.removeItem('addToFavProdRedir');
		
			}
		})
		
		 },5000);
		}

	setTimeout(() => {
		jQuery('.cloud-zoom').on({            
			click: function(e) {
					e.preventDefault();
					$(".custom_imgzoom .group2").addClass("cboxElement");
					$("." + jQuery(this).attr("data-current-id") + " .group2").colorbox({
							open: true
					});
			}
	});
	
	jQuery('.img_spacing').on({
			click: function(e) {
					e.preventDefault();
					var cpath = $(this).attr("href");
					$('.cloud-zoom img').attr("src", cpath);
					$("a.cloud-zoom").attr("data-current-id", "customimg" + $(this).attr("data-popup-id"));
					$(".product-thumbnail").attr("data-current-img-id", $(this).attr("data-popup-id"));
			}
	});

	jQuery(".accordion_head").click(function(){
            
		if($(this).next(".accordion_body").is(":visible")){
				$(this).next(".accordion_body").slideUp(300);
				$(this).find("img").attr('src','angular-assets/images_theme/arrow-up-pd.png');
		} else{
				$(this).next(".accordion_body").slideDown(300);
				$(this).find("img").attr('src','angular-assets/images_theme/arrow-down-pd.png');
		}							
});	

	}, 1000);

	 
	
}


  ringsize : string ='';

  selectringsize (event: any){
	var ring = event.target.value;
	this.ringsize = ring.split(",");
	this.ringsizeValue = this.ringsize[0];
	this.ringsizePname = this.ringsize[1];
	$('.ring_size_selected_opts').find('span.value').text(this.ringsize[1]);
}

ChnageMetalTypeProd(){
	$(".metalTypeProd").toggle();
}
getFinalAmount(oid,attrid){
	$('.loader').css('display','block');
	this.priceChanged=false;
	var attropt = '.attropt'+oid;
	$('.divspan'+attrid+' .attrimgblock').removeClass("active");
	$(attropt).addClass("active");
	var product_id = $('#product_id').val();
	
  	var para = '?product_id='+product_id+'&variant=';
	$( ".variantAttr span.active" ).each(function( index ) {
		para = para + $(this).attr('opt_id')+",";
	});
	$( ".variantAttr select option:selected" ).each(function( index ) {
		para = para + $(this).attr('opt_id')+",";
	});
	setTimeout(this.selectedAttrs(),2000);
	this.activeDekoCode = [];
	this.activeDekoPercent = [];
	
	this.LaravelPnP.getFilteredPrice(para).subscribe( (response) => {
		this.newPrice = response;
		$('.loader').hide();
		
		if(response.payment_detail != undefined)
		{
			var Array = response.payment_detail.products.status;
			var counter=0;
			
			for (var items in Array ){
				var arr = { "deko": response.deko[Array[items]], "min_deposite": response.payment_detail.products.min_deposite[Array[items]], "max_deposite": response.payment_detail.products.max_deposite[Array[items]], "step": response.payment_detail.products.step[Array[items]] };
				this.activeDeko.push( arr );
				if(counter==0){
					if(!response.payment_detail.products.step[Array[items]]){
						response.payment_detail.products.step[Array[items]] = 10;
					}
					for(var i=response.payment_detail.products.min_deposite[Array[items]];i<=response.payment_detail.products.max_deposite[Array[items]];(i=i+response.payment_detail.products.step[Array[items]])){
						this.activeDekoPercent.push(i);
						this.activeDekoCode = Array[items];
						this.var_deposit_percentage = i;
					}
				}
				counter = counter+1;
			}
		}
		
		var thiss = this;
		//thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
		thiss.var_cost_of_goods = parseFloat(response.defaultPrice);
		if(response.defaultPrice >= this.deko_min_total){
			thiss.calculateAmounts(this.activeDekoCode,thiss.var_cost_of_goods,this.var_deposit_percentage,0);
		}
	});
}
	focusOnFinanaceDiv(event){
	    scrollparoductpage();
	}
	
	
selectedAttrs(){
	var selectedAttrs = '<li class="identifier metal_selected_opts"><div><strong class="type">Metal</strong></div><span class="value">'+$(".metalSelectedProd").text()+'</span> </li>';
	$( ".variantAttr span.active" ).each(function( index ) {
		selectedAttrs = selectedAttrs + '<li class="identifier '+$(this).attr('data-attrname')+'_size_selected_opts"><div><strong class="type">'+$(this).attr('data-attrname')+'</strong></div><span class="value">'+$(this).attr('data-item')+'</span> </li>';
	});
	$( ".attr select option:selected" ).each(function( index ) {
		selectedAttrs = selectedAttrs + '<li class="identifier '+$(this).attr('data-attrname')+'_size_selected_opts"><div><strong class="type">'+$(this).attr('data-attrname')+'</strong></div><span class="value">'+$(this).attr('data-item')+'</span> </li>';
	});
	$("#product_selected_opts").html(selectedAttrs);
}


checkloginThenAddToFavourites(product_id,product_url){

     if(localStorage.getItem("cid")){
		
		//let tid =  localStorage.getItem('tokenid');
		//let tokenkey =  localStorage.getItem('tokenkey');
		let token =  localStorage.getItem('token');
		let para = '?productId='+product_id+'&token='+token;
	    this.LaravelPnP.addToFavouriteData(para).subscribe( (response) => { response ;
		 
		  if(response.statuscode==208){
		     this.productExist = true;
		     this.clientClass.emit();
			 this.Clientmessage.emit();
			  setTimeout(()=>{this.productExist = false; },2000);
			 
		  
		  }else if(response.statuscode==201){
		     this.productAdded = true;
		     this.clientClass.emit();
			 this.Clientmessage.emit();
			  setTimeout(()=>{this.productAdded = false; },2000);
		     
		  }
		  })
		
 }else{
    localStorage.setItem('addToFavProdId',product_id);
    localStorage.setItem('addToFavProdRedir',product_url);
    this.routers.navigate(['login.html']);
 }
} 

 ImageRotation($rotation,videoid){
    if($rotation == 'hasVerticleImage' || $rotation == 'hasHorizontalImage'){
      $('.product-photo').hide();
      $('#video-player-block').show();
      $('#enbededvideo').html('<iframe allowFullScreen allowTransparency="true" class="video-player"' + 'frameborder="0" height="100%" id="vzvd-'+videoid+ '" mozallowfullscreen' +  'name="vzvd-'+videoid+ '" src="https://view.vzaar.com/'+videoid+ '/player?autoplay=true"' +  'title="video" type="text/html" webkitAllowFullScreen width="100%"></iframe>');
    }
  }
  
 hidevideo(){
    $('.product-photo').show();
    $('#video-player-block').hide();
  }


	AddtoBag(){
   
	
	
		var customerTokenId = localStorage.getItem('tokenid');
		var customerTokenkey = localStorage.getItem('tokenkey');
		var variant_id =  $("#variant_id").val();
		var quantity =  $(".quantity").val();
		var product_id = $("#product_id").val();
		var selectOPTs = "";
		
		$('.attrimgblock.active').each(function() 
		{    
			selectOPTs = selectOPTs + $(this).attr("data-pa_id") + '|' + $(this).attr("data-attrname") + '|' + $(this).attr("data-attrid") + '|' + $(this).attr("data-item") + '|' + $(this).attr("opt_id")+'@';
		});
		
		$('.attr-value-select option:selected').each(function() 
		{
			selectOPTs = selectOPTs + $(this).attr("data-pa_id") + '|' + $(this).attr("data-attrname") + '|' + $(this).attr("data-attrid") + '|' + $(this).attr("data-item") + '|' + $(this).attr("opt_id")+'@';
		});
		
		
		
		let param = '?variant_id='+variant_id+'&product_id='+product_id+'&quantity='+quantity+'&customerTokenId='+customerTokenId+'&customerTokenkey='+customerTokenkey+'&selectOPTs='+selectOPTs;
	
    this.LaravelPnP.saveBagProduct(param).subscribe( (res) => { res ;
		this.showbag = true;  } );
		
		let para = '?tokenid='+customerTokenId+'&tokenkey='+customerTokenkey;
    this.cartservice.getcartItems(para).subscribe( (response) => { this.userDataresults = response;});
	
	 
	}
	
	getReviews(j){
   
    this.i = this.i+j;
    $('#loadMoreReviews').attr("data-from",this.i);
    this.http.get('https://widget.reviews.co.uk/rich-snippet-reviews/widget?store=angelic-diamonds&primaryClr=%23027cd1&textClr=%23565656&bgClr=%23f9f9f9&headClr=%23ffffff&height=100%&header=&headingSize=20px&names=1&dates=0&footer=1&numReviews='+this.i+'&tag=favourite')
    .subscribe(data => {
            this.allResponse = data;
       });
 
  }

 hideMoreReviews(){
   this.i=0;
  $('#hideReviews').hide();
  $('#loadMoreReviews').show();
  this.http.get('https://widget.reviews.co.uk/rich-snippet-reviews/widget?store=angelic-diamonds&primaryClr=%23027cd1&textClr=%23565656&bgClr=%23f9f9f9&headClr=%23ffffff&height=100%&header=&headingSize=20px&names=1&dates=0&footer=1&numReviews=5&tag=favourite')
    .subscribe(data => {
      this.allResponse = data;
       });
     $('#loadMoreReviews').attr("data-from",5);
 }

	triggerReviews(){
    $(".cireviews").trigger("click");
  }	
    fbshare(){

    window.open('https://www.facebook.com/sharer/sharer.php?u='+env.URL+this.currentUrl+'&amp;display=popup&amp;ref=plugin&amp;src=like&amp;app_id=172525162793917', 'newwindow', 'width=600, height=400');
     return false;
  }

  googleplus(){
    window.open('https://plus.google.com/share?url='+env.URL+this.currentUrl+'', 'newwindow', 'width=600, height=400');
     return false;
  }

  twittershare(name){
    window.open('https://twitter.com/intent/tweet?text='+name+'r&amp;url='+env.URL+this.currentUrl+'', 'newwindow', 'width=600, height=400');
     return false;
  }

  pinterest(name){
    window.open('http://pinterest.com/pin/create/button/?url='+env.URL+this.currentUrl+'&amp;media=https://www.angelicdiamonds.com/images/product/ENRD3_WG_FLAT.jpg&amp;description='+name+'', 'newwindow', 'width=600, height=400');
     return false;
  }


	call_cbox(aa){
	  call_cboxinjs(aa);
	}

	what_it_comes_with(templatname){
	  this.http.get('angular-assets/template/'+templatname+'.txt').subscribe(data => {
	   	this.textdata = data.text();
		})
	}
	
	toggleProductTabs(){
		$(".accordion_head").off('click').on('click', function() {
			if ($(this).next(".accordion_body").is(':visible')) {
				$(this).next(".accordion_body").slideUp(300);
				$(this).children(".plusminus").html('<img src="angular-assets/images_theme/arrow-down-pd.png" alt="arrow">');
				$(this).children(".plusminus").css('line-height','17px');
			} else {
				$(this).next(".accordion_body").slideDown(300);
				$(this).children(".plusminus").html('<img src="angular-assets/images_theme/arrow-up-pd.png" alt="arrow">');
				$(this).children(".plusminus").css('line-height','15px');
			}
		});
		
	}


	calculatePercentage(event){
		var val = event.target.value;
		var min_deposite = parseInt($('select#var_product_type option[value="'+val+'"]').attr("min_deposite"));
		var max_deposite = parseInt($('select#var_product_type option[value="'+val+'"]').attr("max_deposite"));
		var step = parseInt($('select#var_product_type option[value="'+val+'"]').attr("step"));
		if(!step){
			step = 10;
		}
		this.var_deposit_percentage = min_deposite;
		
		this.activeDekoPercent = [];
		for(var i=min_deposite;i<=max_deposite;(i=i+step)){
			this.activeDekoPercent.push(i);
			this.activeDekoCode = val;
		}
		this.activeDeko.slice();
		this.activeDekoPercent.slice();
		var thiss = this;
		thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
    	thiss.calculateAmounts(this.activeDekoCode,thiss.p2,this.var_deposit_percentage,0);
	}
	
		toggledetails(classnumber){
		   accordion_head(classnumber);
		}
		
    calculateByPercentage(event){
		this.activeDekoCode = $(":input[name='var_product_type']").val();
		this.var_deposit_percentage = parseFloat(event.target.value);
		var thiss = this;
		thiss.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
    	thiss.calculateAmounts(this.activeDekoCode,thiss.p2,this.var_deposit_percentage,0);
	}
	
		calculateAmounts(var_product_type='', var_cost_of_goods: number=0, var_deposit_percentage: number=0, var_deposit_amount: number=0) {
		
		var p1 = var_product_type;
		var thiss = this;
		
		this.p2 = parseFloat(var_cost_of_goods.toFixed(2));
		this.p3 = parseFloat(var_deposit_percentage.toFixed(2));
		this.p4 = parseFloat(var_deposit_amount.toFixed(1));;
	
		if (p1 == '' || isNaN(this.p2) || isNaN(this.p3) || isNaN(this.p4)) {
			alert("Please enter all the required fields in order to instantiate a new FinanceDetails object.");
		} else {
			loadFinanceDetails(p1,this.p2,this.p3,this.p4);
		}
		
		function loadFinanceDetails(product_type, cost_of_goods, deposit_percentage, deposit_amount) {
		  
		  var my_fd_obj = new FinanceDetails(product_type, cost_of_goods, deposit_percentage, deposit_amount);
		  
		  $("#product_name").html(my_fd_obj.p_name);			
		  $("#finance_term").html(my_fd_obj.term+' Months');
		  $("#cost_per_month").html(my_fd_obj.m_inst);
		  $("#cost_of_goods").html(my_fd_obj.goods_val);
		  $("#deposit_percentage").html(my_fd_obj.d_pc);
		  $("#deposit_amount").html(my_fd_obj.d_amount);
		  $("#apr").html(my_fd_obj.apr);
		  $("#monthly_repayment").html(my_fd_obj.l_repay);
		  $("#total").html(my_fd_obj.total);
		  $("#credit_amount").html(my_fd_obj.l_amount);
		  $("#loan_cost").html(my_fd_obj.l_cost);
		  $("#loan_true_cost").html(my_fd_obj.l_truecost);
	  
		}
		var thiss = this;
		$(".checkoutfinal").click(function(){
	
		  var p1 = $(":input[name='var_product_type']").val();
		  this.p2 = parseFloat($(":input[name='var_cost_of_goods']").val());
		  this.p3 = parseFloat($(":input[name='var_deposit_percentage']").val());
		  this.p4 = parseFloat($(":input[name='var_deposit_amount']").val());
		  
	  });
	}

}