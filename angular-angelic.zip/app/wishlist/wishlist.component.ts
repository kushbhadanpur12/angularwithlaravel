import { Component, OnInit } from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { WishlistService } from '../services/wishlist.service';
import { empty } from 'rxjs/observable/empty';
import { RouterModule, Routes, Router}  from '@angular/router';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var jquery:any;
declare var $ :any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  
  form: FormGroup;
  mycss :boolean = false;
  results :any; 
  mailid : any;
  deleteFav : any;
  email: string ;
  sentemail: any ;
  sentmsg: any ;
  public shouldShow :boolean;
  public wishlistTotalItem :boolean = false;;
  
  constructor(private wishservice : WishlistService, private router: Router, private metadt: MetadataComponent, private linkmd: LinkService) { }
  
  ngOnInit() {
	this.metadt.setMetaTitle('Wishlist');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'wishlist.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
	this.form = new FormGroup({
				   email: new FormControl('',[Validators.required,Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"), Validators.minLength(7)]),  
				});
	
    var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.router.navigate(['recover_password']); 
        }else{
		    if(localStorage.getItem("cid")){
				this.getWishlistProduct();
			 }else{
				this.router.navigate(['login.html']);   
				}
		}
  }
  
  getWishlistProduct(){
 
   let token =  localStorage.getItem('token');
   let para = '?token='+token;
   this.wishservice.staticData(para).subscribe( (response) => 
   { 
		this.results = response.wishlistdata;
		$(".catLoader").hide();  
	 });
		   
  }
  
  removeProduct(pid){
  	$(".catLoader").show();	
	let token =  localStorage.getItem('token');
	let para = '?product_id='+pid+'&token='+token;
	
	this.wishservice.deletefromFavouriteList(para).subscribe( (response) => { console.log(response); 
			if(response.statuscode==200){
				 this.getWishlistProduct();
			}
			
		});
     }

  sentMail(form){
    let emails = form.value.email;
    if(this.form.valid){
		$(".catLoader").show();	
		let tid =  localStorage.getItem('tokenid');
		let tokenkey =  localStorage.getItem('tokenkey');
		let para = '?email='+emails+'&tokenid='+tid+'&tokenkey='+tokenkey;
	
		this.wishservice.mailWishListItem(para).subscribe( (response) => {
			if(response.statuscode==200){
				 this.sentemail = 'Yes';
				 this.sentmsg = response.statusText;
			}else{
				this.sentemail = 'No';
				this.sentmsg = 'Email has not been sent! Please try again.';
			}
			$(".catLoader").hide();	
		});
    }else{
      this.mycss = true;
    }

  }

}
