import { Component, OnInit } from '@angular/core';
import { SubcategoryService } from '../services/subcategory.service';
import { LinkService } from '../services/link.service';
import {BrowserModule} from '@angular/platform-browser';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { empty } from 'rxjs/observable/empty';
import { FormControl, FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeService } from '../home.service';
import { Subscription }   from 'rxjs/Subscription';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';

declare var jquery:any;
declare var $ :any;
declare var getCookie:any;

@Component({
  providers:[MetadataComponent ],
  selector: 'app-subcategory',
  templateUrl: './subcategory.component.html',
  styleUrls: ['./subcategory.component.css']
})
export class SubcategoryComponent implements OnInit {
  form: FormGroup;
  selectedItems = [];
  metalId :number;
  metalCHK :any;
  metalurl :any;
  public paramsFilters :any;
  shapeIds :any = [];
  shapeurl :any = [];
  stoneIds :any = [];
  mensIds :any = [];
  ladiesIds :any = [];
  styleIds:any = [];
  alldata:any = [];
  subcat : any;
  styleAttr : any;
  ladiesAttr :any;
  mensAttr :any;
  metalAttr :any;
  stoneAttr:any;
  shapeAttr:any;
  categoryattr :any;
  public products = [];
  public totalrecord : number;
  public currentpagenumber : number;
  public maincat : number;
  myForm: FormGroup;
  sortby:any;
  perPage:any;
  current_page:any;
  pageNumbers=[];
  redirectURL:any;
  currentslug:any;
  metaTitle:any;
  metaDesc:any;
  
  subscription:any;
  customercurrncy:any;
  cust_currency:any;
  
  constructor(private subCatgory : SubcategoryService, private router : ActivatedRoute, private fb: FormBuilder,private route: Router, private homeservice :HomeService, private metadt: MetadataComponent, private linkmd: LinkService) { }

  ngOnInit() {
  
     var resetPassToken = getCookie('resetPassToken');
        if(resetPassToken != null && resetPassToken != undefined && resetPassToken!= ''){
         this.route.navigate(['recover_password']); 
        }

	this.linkmd.removeTag('next');
	this.linkmd.removeTag('prev');
    this.router.queryParams.subscribe(params => {
		this.paramsFilters = params['filter'];
		
    });
	
	this.router.params.subscribe(res=>{
		let slug = res.slug;
		if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
			this.currentslug = this.router.snapshot.url;
		 }
		 
		this.categoryattr = this.subCatgory.categoryFiltersFn(slug);
		this.categoryattr.splice(empty);
	});
	
    this.router.params.subscribe(res=>{
		
		 let slug = res.slug;
		 if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
		 }
		 
		 let name = "";
		 if(res.name1!='' && res.name1!=undefined){
			name = name +',' + res.name1;
		 }
		 
		 if(res.name2!='' && res.name2!=undefined){
			name = name +',' + res.name2;
		 }
		 if(res.name3!='' && res.name3!=undefined){
			name = name +',' + res.name3;
		 }
		 if(res.name4!='' && res.name4!=undefined){
			name = name +',' + res.name4;
		 }
		 
		 let page = null;
		 let filters = "";
		 if(this.paramsFilters!=''){
		 	filters = ","+this.paramsFilters;
		 }
		 
		  function myTrim(x) {
			return x.replace(',','');
		}
		var str = myTrim(name);
		this.redirectURL = slug+'/'+str;
		
		
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
		 
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
		
		this.router.queryParams.subscribe(params => {
			if(params['sortby']!='' && params['sortby']!=undefined){
				this.sortby = params['sortby'];
			}
		});
		if(this.sortby=='' || this.sortby==undefined || this.sortby==0){
			this.sortby = 'recommended-asc';
		}
	
		this.router.queryParams.subscribe(params => {
			if(params['perPage']!='' && params['perPage']!=undefined){
				this.perPage = params['perPage'];
			}
		});
		if(this.perPage=='' || this.perPage==undefined || this.perPage==0){
			this.perPage = 48;
		}
	
		this.current_page = 1;
		
				
		/* this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+name+filters+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
		 this.subcat.splice(empty);*/
		 
		this.subCatgory.subCategoryService('/'+slug+'?newpara='+name+filters+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ;
		 
		 this.maincat = 0;
		 this.metaTitle = '';
		 if(this.subcat.shapeNames){
			 this.subcat.shapeNames.forEach(item => {
				this.metaTitle = this.metaTitle + ' ' + item.name;
				this.maincat = this.maincat + 1;
			  });
		 }
		 if(this.subcat.stoneNames){
			 this.subcat.stoneNames.forEach(item => {
				this.metaTitle = this.metaTitle + ' ' + item.name;
				this.maincat = this.maincat + 1;
			  });
		 }
		 if(this.subcat.styleNames){
			 this.subcat.styleNames.forEach(item => {
				this.metaTitle = this.metaTitle + ' ' + item.name;
				this.maincat = this.maincat + 1;
			  });
		 }
		 if(this.subcat.metalNames && this.metalCHK==1){
			 this.subcat.metalNames.forEach(item => {
				this.metaTitle = this.metaTitle + ' ' + item.name;
				this.maincat = this.maincat + 1;
			  });
		 }
		 console.log(this.maincat);
		 if(this.maincat==1 || this.maincat==0){
		 	this.metadt.setMetaTitle(this.subcat.subCategoryDetails.metaTitle);
			this.metadt.setMetaDesc(this.subcat.subCategoryDetails.metaDesc);
		 }else{
			 this.metaTitle = this.metaTitle + ' ' + this.subcat.categoryDetails.name
			 this.metaDesc = 'Choose from a wide selection of' + this.metaTitle + '. Free delivery and 30 days return policy.';
			 this.metaTitle = this.metaTitle + ' | Angelic Diamonds';
			 this.metadt.setMetaTitle(this.metaTitle);
			 this.metadt.setMetaDesc(this.metaDesc);
		 }
		 let total  = response.products.last_page+1;
		   for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
            }
		 });
		 
		 setTimeout('$(".catLoader").hide();',500);
		 
	});
	
	this.currentpagenumber = 1;
	this.router.queryParams.subscribe(params => {
		if(params['page']!='' && params['page']!=undefined){
			this.currentpagenumber = parseInt(params['page']);
		}
	});
	
	var currentslug = this.redirectURL;
	 currentslug = currentslug.replace(/,/g,'/');
	 var canonicalurl = env.baseURL + currentslug;
	 this.linkmd.createLinkForCanonicalURL(canonicalurl);
	
	if(this.currentpagenumber == 1){
		var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
		console.log(next);
		this.linkmd.addTag( { rel: 'next', href: next} );
	}
	if(this.currentpagenumber > 1){
		var prev = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber-1);
		this.linkmd.addTag( { rel: 'prev', href: prev} );
		var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
		this.linkmd.addTag( { rel: 'next', href: next} );
	}
	
	this.styleAttr = this.subCatgory.styleAttribute();
	this.shapeAttr = this.subCatgory.shapeAttribute();
	this.metalAttr = this.subCatgory.metalAttribute();
	this.stoneAttr = this.subCatgory.stoneTypeAttribute();
	this.mensAttr = this.subCatgory.MensAttribute();
	this.ladiesAttr = this.subCatgory.LadiesAttribute();
	
	this.form = new FormGroup({
	
	});
	
	  this.myForm = this.fb.group({
			 styledata: this.fb.array([]),
			 shapedata: this.fb.array([]),
			 stonedata: this.fb.array([]),
			 mensdata: this.fb.array([]),
			 ladiesdata: this.fb.array([])
	  });
	  
	  this.subscription = this.homeservice.currencyObservable$.subscribe(
        res => {
         this.customercurrncy = res;
        var newwe = this.customercurrncy.customer_currency;
     
         this.cust_currency = JSON.parse(this.customercurrncy.customer_currency);
         
      });
	  
}





	gettingAttrOPT(attr_id,opt_id){
	  $(".catLoader").show();
		this.linkmd.removeTag('next');
	this.linkmd.removeTag('prev');
		
		var ele = $("#opt"+opt_id);
		if(ele.is(':checked')){
		  ele.prop('checked', false);
		  $(this).removeClass('checked');
		} else {
		  ele.prop('checked', true);
		  $(this).addClass('checked');
		}
		
	  this.router.params.subscribe(res=>{
		$(".catLoader").show();	
		
		let slug = res.slug;
		if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
		 }
		let name = "";
		
		
		let StyleURL = "";
		let MetalURL = "";
		let ShapeURL = "";
		let StoneURL = "";
		let MensURL = "";
		let LadyURL = "";
		
		let extra1 = ",";
		let extra2 = "";
		
		let i1=0;
		$('.filterOPTStyle').each(function() 
		{
			if($(this).is(':checked')){
				if(i1==0){
					StyleURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i1++;
			}
		});
		
		
		let i2=0;
		$('.filterOPTMetal').each(function() 
		{    
			if($(this).is(':checked')){
				if(i2==0){
					MetalURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i2++;
			}
		});
		
		let i3=0;
		$('.filterOPTShape').each(function() 
		{    
			if($(this).is(':checked')){
				if(i3==0){
					ShapeURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i3++;
			}
		});
	
		let i4=0;
		$('.filterOPTStone').each(function() 
		{    
			if($(this).is(':checked')){
				if(i4==0){
					StoneURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i4++;
			}
		});
	
		let i5=0;
		$('.filterOPTMens').each(function() 
		{    
			if($(this).is(':checked')){
				if(i5==0){
					MensURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i5++;
			}
		});
	
		let i6=0;
		$('.filterOPTLady').each(function() 
		{   
			if($(this).is(':checked')){
				if(i6==0){
					LadyURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i6++;
			}
		});
		
		
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
		
		if(extra2!=''){
			this.route.navigate(['/'+slug+ShapeURL+StoneURL+StyleURL+MetalURL], { queryParams: { filter: extra2, metalCHK: this.metalCHK } } );
		
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK).subscribe( (response) => {  this.subcat =   response ;
			this.pageNumbers = [];
			setTimeout(()=>{$(".catLoader").hide();},1000);
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			 this.maincat = 0;
			 this.metaTitle = '';
			 if(this.subcat.shapeNames){
				 this.subcat.shapeNames.forEach(item => {
					this.metaTitle = this.metaTitle + ' ' + item.name;
					this.maincat = this.maincat + 1;
				  });
			 }
			 if(this.subcat.stoneNames){
				 this.subcat.stoneNames.forEach(item => {
					this.metaTitle = this.metaTitle + ' ' + item.name;
					this.maincat = this.maincat + 1;
				  });
			 }
			 if(this.subcat.styleNames){
				 this.subcat.styleNames.forEach(item => {
					this.metaTitle = this.metaTitle + ' ' + item.name;
					this.maincat = this.maincat + 1;
				  });
			 }
			 if(this.subcat.metalNames && this.metalCHK==1){
				 this.subcat.metalNames.forEach(item => {
					this.metaTitle = this.metaTitle + ' ' + item.name;
					this.maincat = this.maincat + 1;
				  });
			 }
			 if(this.maincat==1){
				this.metadt.setMetaTitle(this.subcat.subCategoryDetails.metaTitle);
				this.metadt.setMetaDesc(this.subcat.subCategoryDetails.metaDesc);
			 }else{
				 this.metaTitle = this.metaTitle + ' ' + this.subcat.categoryDetails.name
				 this.metaDesc = 'Choose from a wide selection of' + this.metaTitle + '. Free delivery and 30 days return policy.';
				 this.metaTitle = this.metaTitle + ' | Angelic Diamonds';
				 this.metadt.setMetaTitle(this.metaTitle);
				 this.metadt.setMetaDesc(this.metaDesc);
			 }
			 
			 this.router.queryParams.subscribe(params => {
				this.paramsFilters = params['filter'];
				
			});
			 var currentslug = this.redirectURL;
			 currentslug = currentslug.replace(/,/g,'/');
			 var canonicalurl = env.baseURL + currentslug;
		  this.router.queryParams.subscribe(params => {
				if(params['page']!='' && params['page']!=undefined){
					this.currentpagenumber = parseInt(params['page']);
				}
			});
			
			if(this.currentpagenumber == 1){
				var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
				this.linkmd.addTag( { rel: 'next', href: next} );
			}
			if(this.currentpagenumber > 1){
				var prev = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber-1);
				this.linkmd.addTag( { rel: 'prev', href: prev} );
				var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
				this.linkmd.addTag( { rel: 'next', href: next} );
			}
		
			 });
			 
			 
		
		}else{
		
			this.route.navigate(['/'+slug+ShapeURL+StoneURL+StyleURL+MetalURL], { queryParams: { metalCHK: this.metalCHK } });
			
		}
		
	  });
	  
	}

	checkMetalClick(id){
		$(".metalCHK").val(1);
		$('.filterOPTMetal').prop('checked', false);
		$('#Metal'+id).prop('checked', true);
	}
	
	toggleDiv(div){
		$('#'+div).toggle();
	}
	
	catSortBy(sortby){
	  $('#sortbyDiv').hide();
	  $('#perPageDiv').hide();
	  this.linkmd.removeTag('next');
	this.linkmd.removeTag('prev');
	  this.router.params.subscribe(res=>{
		$(".catLoader").show();	
		
		let slug = res.slug;
		if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
		 }
		let name = "";
		
		
		let StyleURL = "";
		let MetalURL = "";
		let ShapeURL = "";
		let StoneURL = "";
		let MensURL = "";
		let LadyURL = "";
		
		let extra1 = ",";
		let extra2 = "";
		
		let i1=0;
		$('.filterOPTStyle').each(function() 
		{
			if($(this).is(':checked')){
				if(i1==0){
					StyleURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i1++;
			}
		});
		
		let i2=0;
		$('.filterOPTMetal').each(function() 
		{    
			if($(this).is(':checked')){
				if(i2==0){
					MetalURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i2++;
			}
		});
		
		let i3=0;
		$('.filterOPTShape').each(function() 
		{    
			if($(this).is(':checked')){
				if(i3==0){
					ShapeURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i3++;
			}
		});
	
		let i4=0;
		$('.filterOPTStone').each(function() 
		{    
			if($(this).is(':checked')){
				if(i4==0){
					StoneURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i4++;
			}
		});
	
		let i5=0;
		$('.filterOPTMens').each(function() 
		{    
			if($(this).is(':checked')){
				if(i5==0){
					MensURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i5++;
			}
		});
	
		let i6=0;
		$('.filterOPTLady').each(function() 
		{   
			if($(this).is(':checked')){
				if(i6==0){
					LadyURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i6++;
			}
		});
		
		
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
		
		this.sortby = sortby;
	
		this.router.queryParams.subscribe(params => {
			if(params['perPage']!='' && params['perPage']!=undefined){
				this.perPage = params['perPage'];
			}
		});
		if(this.perPage=='' || this.perPage==undefined || this.perPage==0){
			this.perPage = 48;
		}
	
		this.current_page = 1;

		if(extra2!=''){
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { filter: extra2, metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } } );
			
			/*this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ;
			
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			
			
			
			 });
			
		}else{
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } });
			/*this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ; 
			
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			
			});
		}
		this.router.queryParams.subscribe(params => {
				this.paramsFilters = params['filter'];
				
			});
		var currentslug = this.redirectURL;
		 currentslug = currentslug.replace(/,/g,'/');
		 var canonicalurl = env.baseURL + currentslug;
	  this.router.queryParams.subscribe(params => {
			if(params['page']!='' && params['page']!=undefined){
				this.currentpagenumber = parseInt(params['page']);
			}
		});
		
		if(this.currentpagenumber == 1){
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
		if(this.currentpagenumber > 1){
			var prev = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber-1);
			this.linkmd.addTag( { rel: 'prev', href: prev} );
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
	  })
	  
	  setTimeout('$(".catLoader").hide();',500);
	}
	
	
	catPerPage(perpage){
	  $('#sortbyDiv').hide();
	  $('#perPageDiv').hide();
	  this.linkmd.removeTag('next');
	this.linkmd.removeTag('prev');
	  this.router.params.subscribe(res=>{
		$(".catLoader").show();	
		
		let slug = res.slug;
		if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
		 }
		let name = "";
		
		
		let StyleURL = "";
		let MetalURL = "";
		let ShapeURL = "";
		let StoneURL = "";
		let MensURL = "";
		let LadyURL = "";
		
		let extra1 = ",";
		let extra2 = "";
		
		let i1=0;
		$('.filterOPTStyle').each(function() 
		{
			if($(this).is(':checked')){
				if(i1==0){
					StyleURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i1++;
			}
		});
		
		let i2=0;
		$('.filterOPTMetal').each(function() 
		{    
			if($(this).is(':checked')){
				if(i2==0){
					MetalURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i2++;
			}
		});
		
		let i3=0;
		$('.filterOPTShape').each(function() 
		{    
			if($(this).is(':checked')){
				if(i3==0){
					ShapeURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i3++;
			}
		});
	
		let i4=0;
		$('.filterOPTStone').each(function() 
		{    
			if($(this).is(':checked')){
				if(i4==0){
					StoneURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i4++;
			}
		});
	
		let i5=0;
		$('.filterOPTMens').each(function() 
		{    
			if($(this).is(':checked')){
				if(i5==0){
					MensURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i5++;
			}
		});
	
		let i6=0;
		$('.filterOPTLady').each(function() 
		{   
			if($(this).is(':checked')){
				if(i6==0){
					LadyURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i6++;
			}
		});
		
		
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
	
		this.router.queryParams.subscribe(params => {
			if(params['sortby']!='' && params['sortby']!=undefined){
				this.sortby = params['sortby'];
			}
		});
		if(this.sortby=='' || this.sortby==undefined || this.sortby==0){
			this.sortby = 'recommended-asc';
		}
		
		this.perPage = perpage;
	
		this.current_page = 1;

		if(extra2!=''){
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { filter: extra2, metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } } );
			/*this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ;
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			
			
			
			 });
			
			
		}else{
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } });
			/*this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ; 
			
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			
			
			});
		}
		this.router.queryParams.subscribe(params => {
				this.paramsFilters = params['filter'];
				
			});
		var currentslug = this.redirectURL;
		 currentslug = currentslug.replace(/,/g,'/');
		 var canonicalurl = env.baseURL + currentslug;
	  this.router.queryParams.subscribe(params => {
			if(params['page']!='' && params['page']!=undefined){
				this.currentpagenumber = parseInt(params['page']);
			}
		});
		
		if(this.currentpagenumber == 1){
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
		if(this.currentpagenumber > 1){
			var prev = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber-1);
			this.linkmd.addTag( { rel: 'prev', href: prev} );
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
		
	  });
	  
	  setTimeout('$(".catLoader").hide();',500);
	}
	
	pager(page){
	  $('#sortbyDiv').hide();
	  $('#perPageDiv').hide();
	this.linkmd.removeTag('next');
	this.linkmd.removeTag('prev');
	  this.router.queryParams.subscribe(params => {
				this.paramsFilters = params['filter'];
				
			});
		var currentslug = this.redirectURL;
		 currentslug = currentslug.replace(/,/g,'/');
		 var canonicalurl = env.baseURL + currentslug;
	  this.currentpagenumber = parseInt(page);
		
		if(this.currentpagenumber == 1){
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
		if(this.currentpagenumber > 1){
			var prev = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber-1);
			this.linkmd.addTag( { rel: 'prev', href: prev} );
			var next = canonicalurl+'?filter=' + this.paramsFilters + '&metalCHK=' + this.metalCHK + ',&sortby=' + this.sortby + ',&perPage=' + this.perPage + ',&page=' +(this.currentpagenumber+1);
			this.linkmd.addTag( { rel: 'next', href: next} );
		}
	  
	  this.router.params.subscribe(res=>{
		$(".catLoader").show();	
		
		let slug = res.slug;
		if(slug==undefined || slug==''){
		 	slug = this.router.snapshot.url;
		 }
		let name = "";
		
		
		let StyleURL = "";
		let MetalURL = "";
		let ShapeURL = "";
		let StoneURL = "";
		let MensURL = "";
		let LadyURL = "";
		
		let extra1 = ",";
		let extra2 = "";
		
		let i1=0;
		$('.filterOPTStyle').each(function() 
		{
			if($(this).is(':checked')){
				if(i1==0){
					StyleURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i1++;
			}
		});
		
		let i2=0;
		$('.filterOPTMetal').each(function() 
		{    
			if($(this).is(':checked')){
				if(i2==0){
					MetalURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i2++;
			}
		});
		
		let i3=0;
		$('.filterOPTShape').each(function() 
		{    
			if($(this).is(':checked')){
				if(i3==0){
					ShapeURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i3++;
			}
		});
	
		let i4=0;
		$('.filterOPTStone').each(function() 
		{    
			if($(this).is(':checked')){
				if(i4==0){
					StoneURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i4++;
			}
		});
	
		let i5=0;
		$('.filterOPTMens').each(function() 
		{    
			if($(this).is(':checked')){
				if(i5==0){
					MensURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i5++;
			}
		});
	
		let i6=0;
		$('.filterOPTLady').each(function() 
		{   
			if($(this).is(':checked')){
				if(i6==0){
					LadyURL = "/"+$(this).attr("data-url");
					extra1 += $(this).attr("data-url")+",";
				}else{
					extra2 += $(this).attr("data-url")+",";
				}
				i6++;
			}
		});
		
		
		this.router.queryParams.subscribe(params => {
			if(params['metalCHK']!='' && params['metalCHK']!=undefined){
				this.metalCHK = params['metalCHK'];
			}
		});
		if(this.metalCHK=='' || this.metalCHK==undefined || this.metalCHK==0){
			this.metalCHK = $(".metalCHK").val();
		}
	
		this.router.queryParams.subscribe(params => {
			if(params['sortby']!='' && params['sortby']!=undefined){
				this.sortby = params['sortby'];
			}
		});
		if(this.sortby=='' || this.sortby==undefined || this.sortby==0){
			this.sortby = 'recommended-asc';
		}
	
		this.router.queryParams.subscribe(params => {
			if(params['perPage']!='' && params['perPage']!=undefined){
				this.perPage = params['perPage'];
			}
		});
		if(this.perPage=='' || this.perPage==undefined || this.perPage==0){
			this.perPage = 48;
		}
	
		this.current_page = page;

		if(extra2!=''){
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { filter: extra2, metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } } );
			/*this.subcat = this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+extra2+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ; 
			
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }

			});
			
		}else{
			this.route.navigate(['/'+slug+ShapeURL+StyleURL+MetalURL], { queryParams: { metalCHK: this.metalCHK, sortby: this.sortby, perPage: this.perPage, page: this.current_page } });
			/*this.subcat =    this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page);
			this.subcat.splice(empty);*/
			this.subCatgory.subCategoryService('/'+slug+'?newpara='+extra1+'&metalCHK='+this.metalCHK+'&sortby='+this.sortby+'&perPage='+this.perPage+'&page='+this.current_page).subscribe( (response) => {  this.subcat =   response ;
			
			this.pageNumbers = [];
			let total  = response.products.last_page+1;
		    for( let count = 2; count < total; count++){
             	this.pageNumbers.push(count);
             }
			
			
			 });
		}
		
		
	  });
	  
	  setTimeout('$(".catLoader").hide();',500);
	  $('html, body').animate({
			scrollTop: $('.angularItemLists').offset().top
		  }, 500);
	}
	
	resetFilterCustom(){
		var myStr = this.redirectURL;
		myStr = myStr.split(",")[0];
		var filterReset = getCookie('filterReset');
		if(filterReset!=null && filterReset!='' && filterReset!=undefined){
				this.route.navigate(['/'+filterReset]);
		}else{	
			this.route.navigate(['/'+myStr]);
		}
	}
	
	calltomobileFunction(){
	 $('#sidebar-first').append('<div class="filterOptionsClose">&nbsp;</div>');
		$('.filterOptions').on('click', function() {
			$('.aaa #sidebar-first').animate({
				"left": "0"
			}, 300);
			$("#page-container").animate({
				"left": "70%"
			}, 300);
			$('#page-container2').append('<div class="mobile-menu-shield">&nbsp;</div>');
			$('body').css("position", "fixed");
		});
		$('.filterOptionsClose').on('click', function() {
			$('.aaa #sidebar-first').animate({
				"left": "-82%"
			}, 300);
			$("#page-container").animate({
				"left": "0"
			}, 300);
			$('.mobile-menu-shield').hide();
			$('body').css("position", "inherit");
		});
	 }
	
}
