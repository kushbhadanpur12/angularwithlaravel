import { Component, OnInit,Input, Output, EventEmitter ,AfterViewInit } from '@angular/core';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
import { RegistrationService } from '../services/registration.service';
import { HttpModule, Http} from '@angular/http';
import { RouterModule, Routes, Router}  from '@angular/router';
import { LaravelRoutesService } from '../services/laravel-routes.service';
import { HomeService } from "../home.service";
import { empty } from 'rxjs/observable/empty';
import { MetadataComponent } from '../metadata/metadata.component';
import { environment as env } from '../../environments/environment';
import { LinkService } from '../services/link.service';

declare var jquery:any;
declare var $ :any;
declare var setCookie:any;
declare var getCookie:any;



@Component({
  providers:[MetadataComponent ],
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


	@Output() Clientmessage: EventEmitter<any> = new EventEmitter<any>();
	@Output() clientClass: EventEmitter<any> = new EventEmitter<any>();
	
	
	
    form: FormGroup;
    mycss :boolean = false;
    public newSession : any;
    public shouldShow :boolean = false;
    public passshouldShow :boolean = false;
    SessionVar: any = [];
    profile: any = [];
    profileData: any = [];
    profileData2: any = [];
    myFavourite : any;
    previousSes:any;
    public prev1 = [];
    loginerror :boolean = false;
    email: string ;
    password :string;
	results: any;
    postsArray: any;

  constructor(private http: Http,  private router: Router,private LaravelPnP : LaravelRoutesService, private register: RegistrationService, private homeService: HomeService, private metadt: MetadataComponent, private linkmd: LinkService) { }
  
  ngOnInit() {
  	
	this.metadt.setMetaTitle('Sign in');
	this.metadt.setMetaDesc('Angelic Diamonds');
	var canonicalurl = env.baseURL + 'login.html';
	this.linkmd.createLinkForCanonicalURL(canonicalurl);
		
	var token = localStorage.getItem('token');
	if(token!='' && token!=null){
		this.router.navigate(['/']);
	}
	
    this.form = new FormGroup({
      email: new FormControl('',[Validators.required,Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$"), Validators.minLength(7)]),
      password: new FormControl('',Validators.required),
      
    });
	
	var isLoginBefore = getCookie('clientemail');
	if(isLoginBefore!=null && isLoginBefore!='' && isLoginBefore!=undefined){
	   this.email = isLoginBefore;
	}
    
  }
  checkvalue(){
    let t = this.email;
    if(t =='' || t == undefined){
      this.shouldShow = true;
    }else{
    }

    if(this.password =='' || this.password == undefined){
      this.passshouldShow = true;
    }else{
    }
  }
 somethingChanged(form){
    if(this.form.get('email').hasError('required') || (!this.form.get('email').hasError('required') && 
    (this.form.get('email').hasError('email'))|| this.form.get('email').hasError('pattern'))){
      this.shouldShow = true;
    }else{
      this.shouldShow = false;
    }

    if(this.form.get('password').hasError('required') ){
      this.passshouldShow = true;
    }else{
      this.passshouldShow = false;
    }

 }

  LoginCustomer(form){
    
     let email = form.value.email;
     let password = form.value.password;
     if(this.form.valid){
	 
      let postdata = {
        email:email,
        password:password
      }
	  
      this.register.customerLogin(postdata).subscribe( (response) => { response;
	  
		      if(response){
               let newv = response;
			   
                let alldata = newv.access_token;
				
            if(response.statusCode==404){
			     this.loginerror=true;
			      setTimeout(()=>{ this.loginerror = false; },3500)
			 
			 this.clientClass.emit();
			 this.Clientmessage.emit();
			}
			   
          if(alldata!=''){
		  
		  
            let token = alldata;
            localStorage.setItem('token',token);
			let tokenid =  localStorage.getItem('tokenid');
			let tokenkey =  localStorage.getItem('tokenkey');
			
            let senddata = {
              token:alldata
              }

			 this.register.customerLoginWithToken(senddata).subscribe( (final_response) => { final_response; 
		 
			   let fnaew = final_response;
               let c_id  = fnaew.id;
               let c_email =  fnaew.email;
               let cfname =  fnaew.fname;
			     setCookie('clientemail',fnaew.email);
			     let log = {
						tokenid:tokenid,
						tokenkey:tokenkey,
						tokenvalue:fnaew.id
					}
			   
			    this.register.generateDynamicJsonToken(log).subscribe( (res) => {  console.log(res); });
             
               localStorage.setItem('cname',cfname);
               localStorage.setItem('cid',c_id);
               localStorage.setItem('cemail',c_email);

                    if((tokenid!=null && tokenid!=undefined) && (tokenkey!=null && tokenkey!=undefined))
                     {

                          let req = {
                              userId:c_id,
                              tokenid:tokenid,
                              tokenkey:tokenkey
                            }

                         
                          this.register.updateUserIdSessiontbl(req).subscribe( (res) => { res; });
						  
						  let paragetcartItems = '?tokenid='+tokenid+'&tokenkey='+tokenkey;
						  this.homeService.getcartItems(paragetcartItems).subscribe( (response) => { this.results = response; } );
                     }
                
                     let proid = localStorage.getItem('addToFavProdId');
                     let redir = localStorage.getItem('addToFavProdRedir');
                     let wish =  localStorage.getItem('redir');
                   		
					
						
                     if((proid!=null && proid!=undefined) && (redir!=null && redir!=undefined))
                     {
  
                        this.router.navigate([redir]);
             
  
                      }else if(wish!=null && wish!=undefined) {
                        this.router.navigate(['wishlist.html']);
                        localStorage.removeItem('redir');
						
                       }else{
                          this.router.navigate(['/profile']);
                       }
              // this.router.navigate(['/']);
			 
          });
          }else{
		  
            let newv11 = response;
			
           }
          
        }
      },
    
      err => { 
				if(err.statusText==='Unauthorized'){
				   this.loginerror=true;
			   }
			  
 });
 
           

   
  }else{
    this.mycss = true;
   // this.shouldShow = true;
  }
 }

  
}