import {
  Component,
  OnInit,
  Input,
  Output,
  OnChanges,
  EventEmitter
} from "@angular/core";
import {
  trigger,
  state,
  style,
  animate,
  transition
} from "@angular/animations";
import {
  ReactiveFormsModule,
  Form,
  FormGroup,
  Validators,
  FormControl,
  Validator
} from "@angular/forms";
import { HttpModule, Http } from "@angular/http";
import { RouterModule, Routes, Router, ActivatedRoute } from "@angular/router";
import { HomeService } from "../home.service";
import { RegistrationService } from "../services/registration.service";
declare var jquery: any;
declare var $: any;
declare var setCookie: any;
declare var getCookie: any;

@Component({
  selector: "app-globallogin",
  templateUrl: "./globallogin.component.html",
  styleUrls: ["./globallogin.component.css"],
  animations: [
    trigger("dialog", [
      transition("void => *", [
        style({ transform: "scale3d(.3, .3, .3)" }),
        animate(100)
      ]),
      transition("* => void", [
        animate(100, style({ transform: "scale3d(.0, .0, .0)" }))
      ])
    ])
  ]
})
export class GloballoginComponent implements OnInit {
  cat_arr: any[];
  jsonResponse: string;
  currenydataArray: any;
  finalCurrency: any;
  form: FormGroup;
  formdata: FormGroup;
  mycss: boolean = false;
  forgotcss: boolean = false;
  closedialog: boolean = true;
  public prev = [];
  previous: any;
  ask: any;
  public shouldShow: boolean = false;
  public shouldShow1: boolean = false;
  public passshouldShow: boolean = false;
  public closepopup: boolean = true;
  public hideaddrbook: boolean = true;
  resetPassword: boolean;

  result = [];
  tokenid: any;
  public customer_currency: any;
  currenciesAll: any;
  profileData: any;
  profileData2: any;
  profileData3: any;
  newSession: any;
  currencyForm: FormGroup;
  loginerror: boolean = false;
  errmsg: boolean = false;
  email: string;
  password: string;
  SessionVar: any = [];
  currencyVal: any = [];
  public fC = [];
  postsArray: any;
  getCurrencyw: any;
  currencyData: any;
  currencyObj: any;
  currencyrerer: any;
  currency: string;
  cemail: any;
  n: any;
  showDropDown: boolean;
  displayddl: string;
  tokenkey: any;
  newSess: any;
  public ctype = "";
  linkSenttoMail: any;
  updateToken: boolean = false;
  className: any;
  public noUserexist: boolean = false;

  @Input() closable = true;
  @Input() visible: boolean;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() againLogin: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() userData: any;
  @Output() userDataChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private http: Http,
    private router: Router,
    private homeservice: HomeService,
    private register: RegistrationService,
    private getUrlData: ActivatedRoute
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = function() {
      return false;
    };
  }

  ngOnInit() {
    this.form = new FormGroup({
      email: new FormControl("", [
        Validators.required,
        Validators.email,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"),
        Validators.minLength(7)
      ]),
      password: new FormControl("", Validators.required)
    });
    this.formdata = new FormGroup({
      email: new FormControl("", [
        Validators.required,
        Validators.email,
        Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$"),
        Validators.minLength(7)
      ])
    });

    var isLoginBefore = getCookie("clientemail");

    if (
      isLoginBefore != null &&
      isLoginBefore != "" &&
      isLoginBefore != undefined
    ) {
      this.email = isLoginBefore;
    }
  }

  close() {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }

  checkvalue() {
    let t = this.email;
    if (t == "" || t == undefined) {
      this.shouldShow = true;
    } else {
    }

    if (this.password == "" || this.password == undefined) {
      this.passshouldShow = true;
    } else {
    }
  }
  checkEmailvalue() {
    let t = this.email;
    if (t == "" || t == undefined) {
      this.shouldShow = true;
      console.log("checkEmailvalue()");
    } else {
      return true;
    }
  }

  somethingChanged() {
    /*  if(this.form.get('email').hasError('required') || (!this.form.get('email').hasError('required') && 
    (this.form.get('email').hasError('email'))|| this.form.get('email').hasError('pattern'))){
      this.shouldShow = true;
    }else{
      this.shouldShow = false;
    }

    if(this.form.get('password').hasError('required') ){
      this.passshouldShow = true;
    }else{
      this.passshouldShow = false;
    }*/
  }

  LoginCustomer(form) {
    let email = form.value.email;
    let password = form.value.password;
    if (this.form.valid) {
      let postdata = {
        email: email,
        password: password
      };

      this.register.customerLogin(postdata).subscribe(
        response => {
          response;

          if (response) {
            let newv = response;
            let alldata = newv.access_token;

            if (alldata != "") {
              let token = alldata;
              localStorage.setItem("token", token);

              let senddata = {
                email: email,
                password: password,
                token: alldata
              };

              this.register.customerLoginWithToken(senddata).subscribe(
                final_response => {
                  final_response;

                  $(".cartLoader").show();
                  let fnaew = final_response;
                  let c_id = fnaew.id;
                  let c_email = fnaew.email;
                  let cfname = fnaew.fname;

                  setCookie("clientemail", fnaew.email);

                  localStorage.setItem("cid", c_id);
                  localStorage.setItem("cname", cfname);
                  localStorage.setItem("cemail", c_email);

                  let tokenid = localStorage.getItem("tokenid");
                  let tokenkey = localStorage.getItem("tokenkey");

                  if (tokenid == null || tokenid == undefined) {
                    this.getCurrencyw = this.homeservice
                      .getCustomerToken()
                      .subscribe(
                        response => {
                          localStorage.setItem("tokenid", response.tokenid);
                          localStorage.setItem("tokenkey", response.tokenkey);
                          tokenid = localStorage.getItem("tokenid");
                          tokenkey = localStorage.getItem("tokenkey");

                          this.processAfterLogin(
                            tokenid,
                            tokenkey,
                            fnaew,
                            c_id
                          );
                        },
                        (error: Response) => console.log(error)
                      );
                  } else {
                    this.processAfterLogin(tokenid, tokenkey, fnaew, c_id);
                  }

                  this.close();
                  this.closeGloballogin();
                },
                err => {
                  if (err.statusText === "Unauthorized") {
                    this.loginerror = true;
                    this.errmsg = true;
                  }
                }
              );
            } else {
              let newv11 = response;
            }
          }
        },

        err => {
          if (err.statusText === "Unauthorized") {
            this.loginerror = true;
          }
        }
      );
    } else {
      this.mycss = true;
    }
  }

  processAfterLogin(tokenid, tokenkey, fnaew, c_id) {
    let log = {
      tokenid: tokenid,
      tokenkey: tokenkey,
      tokenvalue: fnaew.id
    };

    if (
      tokenid != null &&
      tokenid != undefined &&
      (tokenkey != null && tokenkey != undefined)
    ) {
      let req = {
        userId: c_id,
        tokenid: tokenid,
        tokenkey: tokenkey
      };

      this.register.updateUserIdSessiontbl(req).subscribe(res => {
        let paragetcartItems = "?tokenid=" + tokenid + "&tokenkey=" + tokenkey;
        this.homeservice.getcartItems(paragetcartItems).subscribe(response => {
          this.userData = response;
          this.userDataChange.emit(this.userData);
					$(".cartLoader").hide();

					this.getUrlData.params.subscribe(res => {
						if (this.getUrlData.snapshot.url.length > 0) {
							if (
								this.getUrlData.snapshot.url[0].path ==
								"registration.html"
							) {
								this.router.navigate(["/"]);
							}
							if (
								this.getUrlData.snapshot.url[0].path == "login.html"
							) {
								this.router.navigate(["/"]);
							}

							if (
								this.getUrlData.snapshot.url[0].path == "cart.html" ||
								this.getUrlData.snapshot.url[0].path == "checkout.html"
							) {
								this.router.navigated = false;
								this.router.navigate([this.router.url]);
							}
						}
					});
        });
      });
    }

    this.register.generateDynamicJsonToken(log).subscribe(res => {
      console.log(res);

      $(".cartLoader").hide();
      this.cemail = fnaew.email;
      this.form.reset();
      this.hideaddrbook = true;
      this.close();
    });
  }

  isLoggedin() {
    if (localStorage.getItem("cemail")) {
      var myObj = localStorage.getItem("cemail");
      if (myObj != "" && myObj != undefined && myObj != null) {
        this.jsonResponse = myObj;
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  logout() {
    localStorage.removeItem("cemail");
    localStorage.removeItem("cname");
    localStorage.removeItem("user_email");
    localStorage.removeItem("cid");
    localStorage.removeItem("token");
  }

  closeGloballogin() {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }

  openGloballogin() {
    this.visible = true;
    this.visibleChange.emit(this.visible);
    this.resetPassword = false;
  }

  recoverPassword(formdata) {
    let email = formdata.value.email;
    if (email == "" || email == null || email == undefined) {
      this.forgotcss = true;
    }
    //$('.cartLoader').show();
    $(".loader").css("display", "block");
    if (this.formdata.valid) {
      let postdata = { email: email };
      this.register.forgetPassword(postdata).subscribe(response => {
        response;
        console.log(response);
        // $('.cartLoader').hide();
        $(".loader").css("display", "none");
        if (response.statusCode == 404) {
          $(".err").show();
          this.shouldShow1 = true;
          this.noUserexist = true;
          this.linkSenttoMail = response.msg;
          this.forgotcss = true;
        }
        if (response.statusCode == 200) {
          $(".err").show();
          this.updateToken = true;
          this.linkSenttoMail = response.msg;
          this.className = "message_1";
          setTimeout(() => {
            this.closeGloballogin();
            $("#hiddenform").hide();
          }, 4000);
        }
        setTimeout(() => {
          this.updateToken = false;
          this.forgotcss = false;
          this.noUserexist = false;
        }, 4000);
      });
    } else {
      this.forgotcss = true;
      // $('.cartLoader').hide();
      $(".loader").css("display", "none");
    }
  }
}
