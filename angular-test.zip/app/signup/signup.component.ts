import { Component, OnInit } from '@angular/core';
import { SignupService } from './../services/signup.service';
import {ReactiveFormsModule ,Form, FormGroup, Validators ,FormControl,Validator } from '@angular/forms';
declare var $:any;
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

   form: FormGroup;
  constructor(private signup: SignupService) { }

  ngOnInit() {
  
   this.form = new FormGroup({
      email: new FormControl('',[Validators.required,Validators.email,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]),
      password: new FormControl('',[Validators.required])
    })
  }

  addUser(form){
  
     let email = form.value.email;
     let password = form.value.password;

    if(this.form.valid){
	
	 let postdata = {
    	  email:email,
     	 password:password  
      }
	     $('.successalert').show();
	     this.signup.register(postdata).subscribe(res => res);
	     setTimeout(()=>{ $('.successalert').hide() },2500)
         //this.form.reset();
      }else{
	  	 $('.erroralert').hide();
	     setTimeout(()=>{$('.erroralert').hide() },2500);

	  }
	  
	  }
}
