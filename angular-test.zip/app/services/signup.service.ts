import { Injectable } from '@angular/core';
import { Http ,Response,Headers,RequestOptions} from "@angular/http";
import  'rxjs/add/operator/map';

@Injectable()
export class SignupService {

  constructor(private http:Http) { }
 
     URL = 'http://127.0.0.1:8000/api/';
       register(data){

  	/*return this.http.post(this.URL+'registration',data).map(
        (response: Response) => {
				console.log(response);
               return response;
          }
        );*/
		
			return this.http.get(this.URL+'getData').map(
             (response: Response) => {
				console.log(response);
               return response;
          }
        );
  }

}
