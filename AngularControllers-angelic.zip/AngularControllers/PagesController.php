<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

class PagesController extends Controller
{
   public function staticPages($page)
     {
        $data = DB::table('static_pages')
                      ->where('id',$page['page_id'])
                      ->get();
            return response()->json(array('data'=>$data,'loading_contenttype'=>1),201);
     }

    public function categoryData(Request $request, $slug){
      
      $RES = DB::table('clean_urls')->where('cleanUrl','=',$slug)->first();
      if(!empty($RES->category_id)){

        $data = DB::table('categories')
        ->where('id',$RES->category_id)
        ->where('parent_id',1)  
        ->get();
     
        return response()->json($data,201);

      }else{
        $result = array('notfound'=>1);
          return json_encode($result);
      }

     }


}
