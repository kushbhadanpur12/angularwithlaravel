<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Hash;
use App\Customer;
use App\User;
use App\CustAddrBook;
use App\CustomerSessionData;
use App\CustomerSession;
use App\Order;
use App\GlobalSetting;

use DB;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
class CustomerRegistrationController extends Controller
{
      
   public function __construct()
   {
       $this->middleware('jwt.auth', ['except' => ['authenticate','registration']]);
   }

   public function store(Request $request)
    {

   $exist = User::select('id')->where('email',$request->email)->where('password','!=','')->where('password','!=',Null)->get();
       if(count($exist)>0){
        return response()->json(['msg'=>'already exist','status'=>'true','statusCode'=>202],201);
       }else{
        $user = new User;
        $user->email = $request->email;
        $password = $request->password; 
        $user->password = Hash::make($password);
        $user->save();
        return response()->json(['customerSaveData'=>$user,'status'=>'true','statusCode'=>200],201);
       }
    }
     public function deleteUserProfile(Request $request)
    {
      $token     =  $request->token;
	  if($token!=''){
		  $userdata = auth('api')->user();
			if($userdata){
	     		 $data = User::where('id','=',$userdata->id) ->update([ 'isDeleted' =>'yes' ]);
				  if($data){ 
					   return response()->json(array('msg'=>'profile Deleted Successfully','statusText'=>'Success','statusCode'=>200 ));
					}else{
						return response()->json(array('msg'=>'Error to delete profile','statusText'=>'Error','statusCode'=>210 ));
					}
			}else{
			return response()->json(array('msg'=>'Token does not match','statusText'=>'Error' ));
			}
	  } else{
	   		return response()->json(array('msg'=>'Token does not match','statusText'=>'Error' ));
	   }
   } 

  public function changedPassword(Request $request)
    {
      $tokenkey        =  $request->tokenkey;
      $tokenid         =  $request->tokenid;
      $password        =  $request->password;
      $pass            =  Hash::make($password);
      $resetPassToken  =  $request->resetPassToken;
      $admin_email = GlobalSetting::where('name','=','admin_email')->first();

      $sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
      if($sessionData){

        $tokenexist = User::select('id','email')->where('reSetPasswordToken',$resetPassToken)->get();
          if(count($tokenexist)>0){
             foreach ($tokenexist as $value) {
                 $dataUpdated = User::where('id','=',$value->id) ->update(['password' =>$pass,'reSetPasswordToken'=>'','reSetPasswordTime'=>0]);
              }
               return response()->json(array('msg'=>'password changed Successfully','statusText'=>'true','statusCode'=>200,'email'=>$tokenexist[0]->email));
          }else{
            return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','token'=>$resetPassToken));
          }
       }else{  
             return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','token'=>$sessionData));
       }
   }

   public function checkChangedPasswordToken(Request $request)
    {
      $tokenkey         =  $request->tokenkey;
      $tokenid          =  $request->tokenid;
      $forgotPassToken  =  $request->forgotPassToken;

      $sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
      if($sessionData){
        $reSetPasswordTime =  time();
        $tokenexist = User::select('id')->where('reSetPasswordToken',$forgotPassToken)->where(DB::raw($reSetPasswordTime.' - reSetPasswordTime'),'<',3600)->get();
          if(count($tokenexist)>0){
               return response()->json(array('msg'=>'Token match','statusText'=>'true','statusCode'=>200));
          }else{
            return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','statusCode'=>404));
          }
       }else{  
             return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','statusCode'=>404,'token'=>$sessionData));
       }
   }
    
}
