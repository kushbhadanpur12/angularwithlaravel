<?php

namespace App\Http\Controllers\AngularControllers;

use App\Product;
use App\Wishlist;
use App\ProductAttribute;
use App\Order;
use App\OrderItem;
use App\Vat;
use App\OrderItemAttributeValue;
use App\Currency;
use App\CustomerSession;
use App\CustomerSessionData;
use App\ProductVariants;
use App\AttributesOptionModel;
use App\AbandonedCart;
use App\Coupon;
use App\OrderCoupon;
use App\CategoryProduct;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class CartController extends Controller
{
	public function index(Request $req){

       $tokenid  = $req->tokenid;
       $tokenkey = $req->tokenkey;
       $orderId ='';


       $custmer_exist = CustomerSession::select('id')
                 ->where('id',$tokenid)
				 ->where('custome_token',$tokenkey)
				 ->first();

		 if($custmer_exist){
			 $custmerOrder = CustomerSessionData::select('value')->where('sid',$custmer_exist->id)->where('name','customer_orderid')->first();
			 if($custmerOrder){
                    $orderId =  $custmerOrder->value;
              }
			 if($orderId){
				$OrderDetails =  Order::where('id','=',$orderId)->with("orderCoupon")->first();
	 	        $DefaultCurrency =  Currency::find($OrderDetails->currency_id);
	 	        $product =  OrderItem::where("order_id","=",$orderId)->with('productDetails')->with('product_variant')->with('variant_option')->with('clean_url')->with('productImg')->with('attr_options')->get();
	 	        
				$cartPIDs =  OrderItem::select("object_id")->where("order_id","=",$orderId)->groupBy("object_id")->get();
				
				$totalCartItems = OrderItem::where('order_id','=',$orderId)->sum('amount');

		 	 	return response()->json(array('totalCartItems'=>$totalCartItems, 'orderDetails'=>$OrderDetails,'DefaultCurrency'=>$DefaultCurrency,'products'=>$product,'cartPIDs'=>$cartPIDs,'status'=>'true','statusText'=>'success'));
			 			
			 }else{

               return response()->json(array('message'=>'order not placed','status'=>'true','statusText'=>'success','totalCartItems'=>0));
			 }

		 }else{
        
        return response()->json(array('message'=>'customer does not exist','status'=>'true','statusText'=>'success'));
		 }
	}

	public function removeItem(Request $request){

      $tokenid      =   $request->input('tokenid');
      $tokenkey	    =   $request->input('tokenkey');
      $itemId	    =   $request->input('itemId');
      $orderid	    =   $request->input('orderid');

      $custmer_exist = CustomerSession::select('id')
                 ->where('id',$tokenid)
				 ->where('custome_token',$tokenkey)
				 ->first();

	  if($custmer_exist){

		$del = OrderItem::where('id',$itemId)->where('order_id',$orderid)->delete();
		$customer_order_id = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_orderid')->first();
		$countItems = OrderItem::where('order_id','=',$customer_order_id->value)->count();
		
		$vat = Vat::find(1)->price;
		
		if($countItems>0){
			//$totalOrderValue = OrderItem::where('order_id','=',$customer_order_id->value)->sum(DB::raw('discountedSubtotal * amount'));
			//$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
			//Order::where('id',$customer_order_id->value)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
			$this->recalculateOrderTotal($customer_order_id->value);
		}else{
			CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_orderid')->delete();
			Order::where('id',$customer_order_id->value)->delete();
		}

		return response()->json(array('status'=>'true','statusText'=>'success'));

	  }
	}

   public function addBagProducts(Request $request){

			$variant_id         =   $request->input('variant_id');
			$product_id         =   $request->input('product_id');
			$quantity           =   $request->input('quantity');
			$customerTokenId    =   $request->input('customerTokenId');
			$customerTokenkey   =   $request->input('customerTokenkey');
			$selectOPTs   =   $request->input('selectOPTs');
			
			$vat = Vat::find(1)->price;
			
			$fetchOIDetails = 'SELECT  A.item_id FROM order_item_attribute_values  A Where ';
			
			if($selectOPTs!=''){
				$selOPT = array_filter(explode("@",$selectOPTs));
				$paids = array();
				$oritde = array();
				foreach($selOPT as $OPT){
					$aaa = explode("|",$OPT);
					$paids[] = $aaa[0];
					$oritde[] = $aaa;
					$fetchOIDetails .= ' Exists
			
										(
											Select  *
											From    order_item_attribute_values  B
											Where   A.item_id = B.item_id
											And     B.product_attribute_id = '.$aaa[0].'
										)
										And ';
					unset($aaa);
				}
			}
			$fetchOIDetails .= ' 1 GROUP BY A.item_id';
			
			$defaultCurrency = Currency::where('default','=',1)->first();
			
			$orderId = '';
			$profile = CustomerSession::select('id')
						 ->where('custome_token',$customerTokenkey)
						 ->first();
			
			$vdata = ProductVariants::where('id',$variant_id)->where('product_id',$product_id)->first();
			$v_price = ($vdata->variant_price*100)/(100+$vat);
			$pdata = Product::find($product_id);
			$p_name = 	$pdata->name;
			$p_sku = 	$pdata->sku;
			
			$login_user_id = CustomerSessionData::select('name','value')
							->where('sid','=',$customerTokenId)
							->where('name','=','login_user_id')
							->first();
							
			if(!empty($login_user_id->value)){
				$orig_profile_id = $login_user_id->value;
			}else{
				$orig_profile_id = 0;
			}

			$user_id = CustomerSessionData::select('name','value')
						->where('sid','=',$customerTokenId)
						->where('name','=','user_id')
						->first();
			if(!empty($user_id->value)){
				$profile_id = $user_id->value;
			}else{
				$profile_id = 0;
			}
			if($profile_id==0){
				if(!empty($login_user_id->value)){
					$profile_id = $login_user_id->value;
				}else{
					$profile_id = $customerTokenId;
				}
			}
			
			$customer_currency = CustomerSessionData::where('name','=','customer_currency')->where('sid','=',$customerTokenId)->first();
			$multicurr = json_decode($customer_currency['value']);
			
			$cust_ses = CustomerSessionData::select('name','value')
						->where('sid','=',$customerTokenId)
						->where('name','=','customer_orderid')
						->first();
				
				if($cust_ses){
						
					$orderId = $cust_ses->value;
					 
					$checkVarExist = DB::select($fetchOIDetails);
					
					$cur_item_id = 0;
					foreach($checkVarExist as $val){
						$prod = OrderItem::find($val->item_id);
						if($prod){
							$cur_item_id = $prod->id;
							break;
						}else{
							continue;
						}
					}
						
					if($cur_item_id > 0){
						$response = OrderItem::where('order_id',$orderId)->where('id',$cur_item_id)->update(array('amount'=>DB::raw("(amount + 1)"),'subtotal'=>DB::raw("price * amount"),'total'=>DB::raw("price * amount")));
						//$totalOrderValue = OrderItem::where('order_id','=',$cust_ses->value)->sum(DB::raw('discountedSubtotal * amount'));
						//$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
						//Order::where('id',$cust_ses->value)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
						$this->recalculateOrderTotal($orderId);
					}else{
					
						$orderitem = new OrderItem;
						$orderitem->object_id = $product_id;
						$orderitem->order_id = $cust_ses->value;
						$orderitem->xpcFakeItem = NULL;
						$orderitem->name = $p_name;
						$orderitem->sku = $p_sku;
						$orderitem->price = $v_price;
						$orderitem->itemNetPrice = $v_price;
						$orderitem->discountedSubtotal = $v_price;
						$orderitem->amount = 1;
						$orderitem->total = $v_price;
						$orderitem->subtotal = $v_price;
						$orderitem->object_type = '';
						$orderitem->variant_id = $variant_id;
						$orderitem->save();
						
						if(count($oritde)>0){
							foreach($oritde as $val){
								$OrderItemAttributeValue = new OrderItemAttributeValue;
								$OrderItemAttributeValue->item_id = $orderitem->id;
								$OrderItemAttributeValue->product_attribute_id = $val[0];
								$OrderItemAttributeValue->attribute_name = $val[1];
								$OrderItemAttributeValue->attribute_id = $val[2];
								$OrderItemAttributeValue->attribute_option_name = $val[3];
								$OrderItemAttributeValue->attribute_option_id = $val[4];
								$OrderItemAttributeValue->attribute_option_detail = $val[3];
								$OrderItemAttributeValue->save();
							}
						}
					
					}
					
					//$totalOrderValue = OrderItem::where('order_id','=',$cust_ses->value)->sum(DB::raw('discountedSubtotal * amount'));
					//$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
					//Order::where('id',$cust_ses->value)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
					$this->recalculateOrderTotal($cust_ses->value);
				}else{

					$order = new Order;
					$order->profile_id = $profile_id;
					$order->orig_profile_id = $orig_profile_id;
					$order->payment_status_id = 1;
					$order->payment_method_id = '0';
					$order->payment_method_name = NULL;
					$order->shipping_status_id = '0';
					$order->currency_id = $defaultCurrency->id;
					$order->auctionIncPackage = '';
					$order->fraud_status_xpc	 = '';
					$order->fraud_type_xpc = ''; 
					$order->shipping_id = 0;
					$order->shipping_method_name = NULL;
					$order->tracking = '0';
					$order->date = time();
					$order->lastRenewDate = 0; 
					$order->notes = '';
					$order->adminNotes = '';
					$order->orderNumber = 0;
					$order->recent = 0;
					$order->xcPendingExport = 0; 
					$order->vat = $vat;
					$order->total = 0;
					$order->subtotal = 0;
					$order->is_order = 0;
					$order->multi_currency_id = $multicurr->id;
					$order->selectedMultiCurrencyRate = $multicurr->rate; 
					$order->not_finished_order_id = 0;
					$order->recovered = 0;
					$order->cart_reminders_sent = 0;
					$order->cart_reminder_date = 0;
					$order->lost = 0; 
					$order->lastVisitDate = time(); 
     				$order->save();
					
     			  	$orderId = $order->id;

					$csd = new CustomerSessionData;
					$csd->sid = $customerTokenId;
					$csd->name = 'customer_orderid';
					$csd->value = $orderId;
					$csd->save();
					
					$orderitem = new OrderItem;
					$orderitem->object_id = $product_id;
					$orderitem->order_id = $orderId;
					$orderitem->xpcFakeItem = NULL;
					$orderitem->name = $p_name;
					$orderitem->sku = $p_sku;
					$orderitem->price = $v_price;
					$orderitem->itemNetPrice = $v_price;
					$orderitem->discountedSubtotal = $v_price;
					$orderitem->amount = 1;
					$orderitem->total = $v_price;
					$orderitem->subtotal = $v_price;
					$orderitem->object_type = '';
					$orderitem->variant_id = $variant_id;
					$orderitem->save();
					
					if(count($oritde)>0){
						foreach($oritde as $val){
							$OrderItemAttributeValue = new OrderItemAttributeValue;
							$OrderItemAttributeValue->item_id = $orderitem->id;
							$OrderItemAttributeValue->product_attribute_id = $val[0];
							$OrderItemAttributeValue->attribute_name = $val[1];
							$OrderItemAttributeValue->attribute_id = $val[2];
							$OrderItemAttributeValue->attribute_option_name = $val[3];
							$OrderItemAttributeValue->attribute_option_id = $val[4];
							$OrderItemAttributeValue->attribute_option_detail = $val[3];
							$OrderItemAttributeValue->save();
						}
					}
			}
		
		//$totalOrderValue = OrderItem::where('order_id','=',$orderId)->sum(DB::raw('discountedSubtotal * amount'));
		//$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
		//Order::where('id',$orderId)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
		$this->recalculateOrderTotal($orderId);
		return response()->json(array('msg'=>'success')); 
     }
	 
     public function updateEngraving(Request $request){

		//$engfont    =   $request->input('engfont');
		//$eng_text   =   $request->input('eng_text');
		$itemId	    =   $request->input('itemId');
		$tokenid    =   $request->input('tokenid');
		$tokenkey   =   $request->input('tokenkey');
		$orderId    =   $request->input('orderId');
		
		$userExist = CustomerSession::select('id')
						->where('custome_token',$tokenkey)
						->where('id',$tokenid)
						->first();
		
		if($userExist){
		
		//  			  $oi = OrderItem::where('order_id',$orderId)->where('id',$itemId)->update(
		//           array(
				//    'engrav_text'=>$eng_text,
				//    'engrav_font'=>$engfont
				// )
		//       );
		//       if($oi){	
		//  			      return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'success'));		
		//  			      	}
		
		$data =  OrderItem::select('engrav_text','engrav_font')
					->where('order_id','=',$orderId)
					->where('id','=',$itemId)
					->get();
					$response = [
					'order_item' => $data
					];
		
		return response()->json($response,201);  
		
		}else{
		
		
		}
    }
	  
	public function savedata(Request $request){
	
					$eng_text   =   $request->input('eng_text');
					if($eng_text!=''){$engfont    =   $request->input('engfont');}else{$engfont = '';}
					$itemId	    =   $request->input('itemId');
					$tokenid    =   $request->input('tokenid');
					$tokenkey   =   $request->input('tokenkey');
					$orderId    =   $request->input('orderId');
	
					$userExist = CustomerSession::select('id')
							->where('custome_token',$tokenkey)
							->where('id',$tokenid)
							->first();
	
					if($userExist){
	
						  $oi = OrderItem::where('order_id',$orderId)->where('id',$itemId)->update(
								   array(
										   'engrav_text'=>$eng_text,
										   'engrav_font'=>$engfont
										)
							   );
						 if($oi){	
							  return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'success'));		
								}
					}else{
	
	
					}
	
	}


	public function itemQuantityData(Request $request){
	
		$quantity    =   $request->input('quantity');
		$itemId	    =   $request->input('itemId');
		$tokenid    =   $request->input('tokenid');
		$tokenkey   =   $request->input('tokenkey');
		$orderId    =   $request->input('orderId');
	
		$userExist = CustomerSession::select('id')
				->where('custome_token',$tokenkey)
				->where('id',$tokenid)
				->first();
		
		if($userExist){
			$customer_order_id = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_orderid')->first();
			
			$oi = OrderItem::where('order_id',$orderId)->where('id',$itemId)->update(array('amount'=>$quantity,'subtotal'=>DB::raw("price * $quantity"),'total'=>DB::raw("price * $quantity"),));
			
			$vat = Vat::find(1)->price;
			
			//$totalOrderValue = OrderItem::where('order_id','=',$customer_order_id->value)->sum(DB::raw('discountedSubtotal * amount'));
			//$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
			//Order::where('id',$customer_order_id->value)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
			$this->recalculateOrderTotal($customer_order_id->value);
			return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'success'));
		}else{
	
	
		}
	
	}

	public function saveAdandonCart(Request $request){
	
		$orderId    =   $request->input('orderid');
		
		$chk = AbandonedCart::where('order_id',$orderId)->count();
		if(!$chk){
			$abd_cart = new AbandonedCart;
			$abd_cart->order_id = $orderId;
			$abd_cart->cart_send = '0';
			$abd_cart->last_send_time = '12345';
			$abd_cart->save();
			return response()->json(array('message'=>'Order saved successfully','status'=>'true','statusText'=>'success'));		
		}else{
			return response()->json(array('message'=>'Already added','status'=>'true','statusText'=>'success'));	
		}
	
	}

	static function recalculateOrderTotal($orderid){
		$orderDetails = Order::find($orderid);
		$vat = $orderDetails->vat;
		
		$OrderCoupon = OrderCoupon::where('order_id',$orderid)->with(["orderCouponDetails"])->first();
		
		if($OrderCoupon){
			$couponcode_exist = $OrderCoupon->orderCouponDetails[0];
			
			$alldata =  OrderItem::where('order_id',$orderid)->get();
			$discountProd = array();
			
			 $availableCategories = array_unique(explode(",",$couponcode_exist->categories));
			 foreach($alldata as $item){
				$CategoryProduct = CategoryProduct::where('product_id',$item->object_id)->get();
				foreach ($CategoryProduct as $ct) {
					if(in_array($ct->category_id,$availableCategories)){
						$discountProd[] = $item->object_id;
					}
				}
			 }
			 $discountProd = array_unique($discountProd);
			
			if($couponcode_exist->discount_type=='P'){
				$totaldiscounted = 0;
				foreach($alldata as $item){
					if(in_array($item->object_id,$discountProd)){
						$disPro =  OrderItem::find($item->id);
						if($couponcode_exist->discount_amount < 100){
							$totaldiscounted = $totaldiscounted + ($disPro->amount * (($disPro->price * $couponcode_exist->discount_amount)/100));
							$disPro->discountedSubtotal = $disPro->price - (($disPro->price * $couponcode_exist->discount_amount)/100);
						}else{
							$totaldiscounted = $totaldiscounted + ($disPro->amount * $disPro->price);
							$disPro->discountedSubtotal = 0;
						}
						$disPro->save();
					}
				}
				$orderDetails = Order::find($orderid);
				$vat = $orderDetails->vat;
				$totalSubTotalValue = $totalOrderValue = OrderItem::where('order_id','=',$orderid)->sum(DB::raw('price * amount'));
				$totalOrderValue = $totalOrderValue = OrderItem::where('order_id','=',$orderid)->sum(DB::raw('discountedSubtotal * amount'));
				
				if($totalOrderValue>0){
					$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
				}else{
					$totalOrderValueVat =  0;
				}
				
				Order::where('id',$orderid)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalSubTotalValue.' + shipping_cost')));
				$OrderCoupon->discounted_value = $totaldiscounted;
				$OrderCoupon->save();
				
			}elseif($couponcode_exist->discount_type=='F'){
				$orderDetails = Order::find($orderid);
				$vat = $orderDetails->vat;
				$totalSubTotalValue = $totalOrderValue = OrderItem::where('order_id','=',$orderid)->sum(DB::raw('discountedSubtotal * amount'));
				if($couponcode_exist->discount_amount>=$totalOrderValue){
					$totalDisountValue = $totalOrderValue;
					$totalOrderValue = 0;
				}else{
					$totalOrderValue = $totalOrderValue - $couponcode_exist->discount_amount;
					$totalDisountValue = $couponcode_exist->discount_amount;
				}
				
				if($totalOrderValue>0){
					$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
				}else{
					$totalOrderValueVat =  0;
				}
				
				Order::where('id',$orderid)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalSubTotalValue.' + shipping_cost')));
				$OrderCoupon->discounted_value = $totalDisountValue;
				$OrderCoupon->save();
			}
		}else{
			$totalOrderValue = OrderItem::where('order_id','=',$orderid)->sum(DB::raw('discountedSubtotal * amount'));
			$totalOrderValueVat = $totalOrderValue + (($totalOrderValue*$vat)/100);
			Order::where('id',$orderid)->update(array('total'=>DB::raw($totalOrderValueVat.' + shipping_cost'),'subtotal'=>DB::raw($totalOrderValue.' + shipping_cost')));
		}
		
		return response()->json(array('message'=>'Order recalculated successfully','status'=>'true','statusText'=>'success'));	
	}

}	