<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;

use App\Product;
use App\Category;
use App\CategoryProduct;
use App\ProductAttribute;
use App\AttributesModel;
use App\AttributesOptionModel;
use App\cleanUrl;

class CategoryController extends Controller
{
   public function mainCategory($page)
     {
        $data = DB::table('categories')
	              ->where('id',$page['cat_id'])
	              ->get();
       
          return response()->json(['data'=>$data,'loading_contenttype'=>3]);
     }

	
	public function combinations($arrays, $i = 0) {
		if (!isset($arrays[$i])) {
			return array();
		}
		if ($i == count($arrays) - 1) {
			return $arrays[$i];
		}
	
		// get combinations from subsequent arrays
		$tmp = $this->combinations($arrays, $i + 1);
	
		$result = array();
	
		// concat each array from tmp with each element from $arrays[$i]
		foreach ($arrays[$i] as $v) {
			foreach ($tmp as $t) {
				$result[] = is_array($t) ? 
					array_merge(array($v), $t) :
					array($v, $t);
			}
		}
	
		return $result;
	}

    public function subCategorydata(Request $request, $para)
    {

		$allproductData = array();
		
		$metalOPT = array(1,2,3,4,5,6,7,8);
		$metaltrue = 0;
		
		$style_id   = 10;
		$metal_id   = 1;
		$stone_id   = 2;
		$shape_id   = 11;
		$mens_id    = 16;
		$ladies_id  = 17;
		
		$sortby = $request->input('sortby');
		$perPage = (($request->input('perPage'))?$request->input('perPage'):48);
		$page = (($request->input('page'))?$request->input('page'):1);
		
		
		if($sortby!=''){
			$sortby2 = explode("-",$sortby);
		}else{
			$sortby2[0] = 'name';
			$sortby2[1] = 'ASC';
			$sortby = 'recommended-asc';
		}
		
		$options = array();
		$optionsVals = array();
		$attrfil = array();
		
		$cat    = $para['cat_id'];
		$subcat   = $para['subcat'];
		$metalCHK   = $para['metalCHK'];
		
		$newpara = array_filter(explode(",",$para['newpara']));
		$newpara = array_diff($newpara, ["undefined"]);
		$optslug = implode(",",$newpara);
		
		$optids = AttributesOptionModel::whereRaw("FIND_IN_SET(slug,'".$optslug."')")->get();
		
		$breadcrumb = $metalNames = $styleNames = $shapeNames = array();
		
		foreach ($optids as $value){
			$optionsVals[$value->attr_id][] = $value->id;
			$options[] = $value->id;
			if(in_array($value->id, $metalOPT)){
				$metaltrue = 1;
			}
			if($value->attr_id==1){
				$metalNames[] = array('name'=>$value->heading_cat_name, 'slug'=>$value->slug);
			}
			if($value->attr_id==10){
				$styleNames[] = array('name'=>$value->heading_cat_name, 'slug'=>$value->slug);
			}
			if($value->attr_id==11){
				$shapeNames[] = array('name'=>$value->heading_cat_name, 'slug'=>$value->slug);
			}
		}
		
		//echo '<pre>';print_r($optids);die;
		if($metaltrue==0){
			$options[] = 4;
			$optionsVals[1][] = 4;
			$metalNames[] = array('name'=>'18K White Gold', 'slug'=>'18k-white-gold');
		}
		
		if(count($attrfil)<1){
		  $attrfil[] = 1;
		}
		
		if(count($options)<1){
		  $options[] = 4;
		  $optionsVals[1][] = 4;
		}
		
		$optids = json_decode(json_encode($optids), true);
		
		if(count($shapeNames)>0){
			$breadcrumb = array('name'=>$shapeNames[0]['name'], 'slug'=>$shapeNames[0]['slug']);
		}else if(count($styleNames)>0){
			$breadcrumb = array('name'=>$styleNames[0]['name'], 'slug'=>$styleNames[0]['slug']);
		}else{
			$breadcrumb = array('name'=>$metalNames[0]['name'], 'slug'=>$metalNames[0]['slug']);
		}
		
		if($request->input('page')){
		  $page = $request->input('page');
		}else{
		  $page = 1;
		}
		
		
		$optionsVals = array_values($optionsVals);
		if(count($options)==1){
			$combinations[][] = $options[0];
		}else{
			$combinations = $this->combinations($optionsVals);
		}
		//echo '<pre>';print_r($combinations);die;
		
		
		$fetchOIDetails = 'SELECT  A.products_id FROM product_attributes A Where ';
		$counter = 1;
		foreach($combinations as $com){
			$fetchOIDetails .= '(';
			foreach($com as $OPT){
				$fetchOIDetails .= ' Exists
									(
										Select  *
										From    product_attributes  B
										Where   A.products_id = B.products_id
										And     B.options_id = '.$OPT.'
									)
									And ';
			}
			$fetchOIDetails .= '1 ) ';
			if($counter<count($combinations)){
				$fetchOIDetails .= 'OR';
			}
			$counter++;
		}
		$fetchOIDetails .= ' AND 1 GROUP BY A.products_id';
		
		$checkPIDExist = DB::select($fetchOIDetails);
		$checkPIDExist = json_decode(json_encode($checkPIDExist), true);
		$checkPIDExist = array_map('current', $checkPIDExist);
		
		$categoryDetails = Category::where('id',$subcat)->with(["clean"])->first();
		$attributes = explode(",",$categoryDetails->attr_ids);
		$attributesOptions = explode(",",$categoryDetails->attr_opt_ids);

		if(count($checkPIDExist)>0){
			if($sortby2[0]=='price'){
				$allproductData = Category::find($subcat)->Products($combinations)->whereIn('products.id',$checkPIDExist)->where('enabled','=',1)->orderBy($sortby2[0],$sortby2[1])->paginate($perPage);
			}else{
				$allproductData = Category::find($subcat)->Products($combinations)->whereIn('products.id',$checkPIDExist)->where('enabled','=',1)->paginate($perPage);
			}
		}else{
			if($sortby2[0]=='price'){
				$allproductData = Category::find($subcat)->Products($combinations)->where('enabled','=',1)->orderBy($sortby2[0],$sortby2[1])->paginate($perPage);
			}else{
				$allproductData = Category::find($subcat)->Products($combinations)->where('enabled','=',1)->paginate($perPage);
			}
		}
 		
		
		$morepages = array();
		if($page==1 || $page==2 || $page==3){
			$morepages[] = 2;
			$morepages[] = 3;
			$morepages[] = 4;
			$morepages[] = 5;
			$morepages[] = 6;
		}
		if($page > 3 && $page < ($allproductData->lastPage()-2)){
			$morepages[] = $page-2;
			$morepages[] = $page-1;
			$morepages[] = $page;
			$morepages[] = $page+1;
			$morepages[] = $page+2;
		}
		if($page==($allproductData->lastPage()-2) || $page==($allproductData->lastPage()-1) || $page==$allproductData->lastPage()){
			$morepages[] = $allproductData->lastPage()-5;
			$morepages[] = $allproductData->lastPage()-4;
			$morepages[] = $allproductData->lastPage()-3;
			$morepages[] = $allproductData->lastPage()-2;
			$morepages[] = $allproductData->lastPage()-1;
		}
		//dd($options);
		return response()->json(['categoryDetails'=>$categoryDetails, 'products'=>$allproductData, 'options'=>$options, 'loading_contenttype'=>3, 'metalNames'=>$metalNames, 'styleNames'=>$styleNames, 'shapeNames'=>$shapeNames, 'attributes'=>$attributes, 'attributesOptions'=>$attributesOptions, 'breadcrumb'=>$breadcrumb, 'sortby'=>$sortby, 'perPage'=>$perPage, 'morepages'=>$morepages]);
 
   	}
     
     public function categoryFilters(Request $request)
     {
	 	$cat = $request->input('cat');
	 	$cleanUrl = cleanUrl::where('category_id','!=',NULL)->where('cleanUrl',$cat)->first();
        $categoryDetails = Category::where('id',$cleanUrl->category_id)->with(["clean"])->first();
		$attributes = AttributesModel::whereRaw("FIND_IN_SET(id,'".$categoryDetails->attr_ids."')")->get();
		$attributesOptions = AttributesOptionModel::whereRaw("FIND_IN_SET(id,'".$categoryDetails->attr_opt_ids."')")->get();

        return response()->json(['attributes'=>$attributes, 'attributesOptions'=>$attributesOptions]);
     }

    public function styleAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',10)
                ->get();

          return response()->json($data);
     }

     public function shapeAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',11)
                ->get();
         
          return response()->json($data);
     }

     public function metalAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',1)
                ->get();
         
          return response()->json($data);
     }

     public function stoneTypeAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',2)
                ->get();
         
          return response()->json($data);
     }

     public function MensAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',16)
                ->get();
         
          return response()->json($data);
     }

      public function LadiesAttribute()
     {
        $data = DB::table('attributes_options')
                ->where('attr_id',17)
                ->get();
          return response()->json($data);
     }
     



}
