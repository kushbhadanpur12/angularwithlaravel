<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\OrderTransaction;
use App\Order;

class PaymentController extends Controller
{


}
