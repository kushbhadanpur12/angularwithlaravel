<?php

namespace App\Http\Controllers\AngularControllers;
use App\Customer;
use App\Product;
use App\Wishlist;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Mail;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class WishlistController extends Controller
{
 public function __construct()
   {
       $this->middleware('jwt.auth', ['except' => ['authenticate','registration']]);
   }
  public function index(Request $request)
   {
  
	$token     =  $request->token ;
	 $validuserData = JWTAuth::toUser($token);
	 if($validuserData){
	    $order = Wishlist::where('customer_id','=',$validuserData->id)->with('cleanUrl','wishlistimgs','wishlistProducts')->get();
 		 return json_encode(array('wishlistdata' =>$order, 'status' =>'true', 'statuscode'=>200));
	}else{
       return response()->json(['msg'=>'Token mismatch']);
	}
	
	}
  /*public function index($userId)
	{
		 $newdata = array();
		
		 foreach (Customer::find($userId)->whislist()->get() as $value) {
		 
		 	if(Product::where('id',$value->product_id)->count()>0) {
		  	 $newdata[] = @Product::find($value->product_id);
		  	}
		 	 

 		 }
		return response()->json($newdata);
	/*	$data = DB::table('wishlists')
			->select('products.*')
			->join('products','products.id','=','wishlists.product_id')
			->where('customer_id',$userId)
			->get();
      return response()->json($data);
	}*/

	 public function removefavouriteList(Request $request){
	 
		$token     =  $request->token;
		$product_id  =  $request->product_id;
		$validuserData = JWTAuth::toUser($token);
	
	     if($validuserData){
           $data =  Wishlist::where('id',$product_id)->where('customer_id',$validuserData->id)->delete();
			   if($data){
				  return response()->json(array('statusText' =>'product deleted successfully', 'status' =>'true', 'statuscode'=>200));
			  }else {
	
				 return response()->json(array('statusText' =>'product not available', 'status' =>'false', 'statuscode'=>400));
			  }
          
		}else{

           return response()->json(['msg'=>'Token mismatch']);
		} 

	 }

 /*	  public function mailWishListItems(Request $request){

 	  	 $email         =         $request->input('email');
 	  	 $customerId    =         $request->input('customerId');

 	  	 $msg = array();
 		  foreach (Customer::find($customerId)->whislist()->get() as $value) {
 		 	if(Product::where('id',$value->product_id)->count()>0) {
 		  	 $msg[] = @Product::find($value->product_id);
 		  	}
 }
 	  	$msg = 'hi there this is testing mail';
 	  	 Mail::send('email', ['msg'=>$msg], function($message){
                    $message->to('lavkush@lucidsoftech.in','To Lucidsoftech')->subject('Test Mail');
                 });   
 	  }*/
	 

}