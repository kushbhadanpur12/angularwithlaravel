<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Product;
use App\Wishlist;
use App\Order;
use App\OrderItem;
use App\CustomerSession;
use App\CustomerSessionData;
use App\ProductVariants;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Category;
use App\CategoryProduct;
use App\ProductAttribute;
use App\AttributesOptionModel;

use DB;

class ProductController extends Controller
{
   public function __construct()
   {
       $this->middleware('jwt.auth', ['except' => ['authenticate','registration']]);
   }

	public function productData(Request $request, $page)
	{
	
		$pro_id = $page['product_id'];
		
		$images = DB::table('products as p')
			->select('product_images.*')
			->join('product_images','product_images.product_id','=','p.id')
			->where('product_images.product_id','=',$pro_id)
			->where('product_images.orderby','>',20)
			->get();
			
		$data = Product::find($pro_id);
			
		$groupedProds = Product::select('products.id','products.metal_name','clean_urls.cleanUrl')->join('clean_urls','clean_urls.product_id','=','products.id')->where('products.group_id','=',$data->group_id)->get();
    
		$varient = DB::table('product_variants')
			->select('variant_com_opt_ids','variant_price','id')
			->where('default','=',1)
			->where('product_id',$pro_id)
			->first();
	
		//DB::enableQueryLog();
		$ProductAttributesOptions = array();
		$ProductAttributesOptions[1] = array();
		$ProductAttributesOptions[2] = array();
		$ProductAttributesOptions[3] = array();
		$ProductAttributesOptions[4] = array();
		$ProductAttributesOptions[5] = array();
		$ProductAttributesOptions[9] = array();
		$ProductAttributesOptions[10] = array();
		$ProductAttributesOptions[11] = array();
		$ProductAttributesOptions[12] = array();
		$ProductAttributesOptions[13] = array();
		$ProductAttributesOptions[14] = array();
		$ProductAttributesOptions[15] = array();
		$ProductAttributesOptions[16] = array();
		$ProductAttributesOptions[17] = array();
		$ProductAttributesOptions[18] = array();

		$Product = Product::find($pro_id);
		$PA = $Product->ProductAttributeList;
		
		foreach($PA as $prod){
			$AttrDetails = $prod->AttributeList;
			$AttrOptionDetails = $prod->AttributeOptionList;
			$ProductAttributes[$prod->attributes_id] = $AttrDetails->name;
			$ProductAttributesOptions[$prod->attributes_id][] = array('pa_id'=>$prod->id, 'attrid'=>$prod->attributes_id, 'opt_id'=>$AttrOptionDetails->id, 'name'=>$AttrOptionDetails->name, 'details'=>$AttrOptionDetails->details, 'class'=>$AttrOptionDetails->class);
			ksort($ProductAttributes);
		}

		if(count($ProductAttributesOptions[1])>0){$Metal = $ProductAttributesOptions[1];}else{$Metal = array();}
		if(count($ProductAttributesOptions[2])>0){$StoneType = $ProductAttributesOptions[2];}else{$StoneType = array();}
		if(count($ProductAttributesOptions[3])>0){$RingWidth = $ProductAttributesOptions[3];}else{$RingWidth = array();}
		if(count($ProductAttributesOptions[4])>0){$RingDepth = $ProductAttributesOptions[4];}else{$RingDepth = array();}
		if(count($ProductAttributesOptions[5])>0){$RingSize = $ProductAttributesOptions[5];}else{$RingSize = array();}
		if(count($ProductAttributesOptions[9])>0){$RingShape = $ProductAttributesOptions[9];}else{$RingShape = array();}
		if(count($ProductAttributesOptions[10])>0){$Style = $ProductAttributesOptions[10];}else{$Style = array();}
		if(count($ProductAttributesOptions[11])>0){$Shape = $ProductAttributesOptions[11];}else{$Shape = array();}
		if(count($ProductAttributesOptions[12])>0){$Carat = $ProductAttributesOptions[12];}else{$Carat = array();}
		if(count($ProductAttributesOptions[13])>0){$Colour = $ProductAttributesOptions[13];}else{$Colour = array();}
		if(count($ProductAttributesOptions[14])>0){$Certificate = $ProductAttributesOptions[14];}else{$Certificate = array();}
		if(count($ProductAttributesOptions[15])>0){$Clarity = $ProductAttributesOptions[15];}else{$Clarity = array();}
		if(count($ProductAttributesOptions[16])>0){$Mens = $ProductAttributesOptions[16];}else{$Mens = array();}
		if(count($ProductAttributesOptions[17])>0){$Ladies = $ProductAttributesOptions[17];}else{$Ladies = array();}
		if(count($ProductAttributesOptions[18])>0){$ChainLength = $ProductAttributesOptions[18];}else{$ChainLength = array();}
		
		//------------------ RECENT VIEW ITEM CODE {START} --------------------//
		$tokenid    =   $request->input('tokenid');
		$tokenkey   =   $request->input('tokenkey');
		$userExist = CustomerSession::select('id')->where('custome_token',$tokenkey)->where('id',$tokenid)->first();
		$recentViewedProd = $recentViewedProdCount = NULL;
		if($userExist){
			$rvi = array();
			$recentViewed = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','recent_viewed')->first();
			if($recentViewed){
				$recentViewedItems = json_decode($recentViewed->value);
				$rvi = $recentViewedItems;
				
				$rviFilter = array();
				if(count($rvi)>5){
					for($i=(count($rvi)-5);$i<count($rvi);$i++){
						$rviFilter[] = $rvi[$i];
					}
				}else{
					for($i=0;$i<count($rvi);$i++){
						$rviFilter[] = $rvi[$i];
					}
				}
				//print_r($rviFilter);
				if(!in_array($pro_id,$rviFilter)){
					if(count($rviFilter)>=5){
						unset($rviFilter[0]);
					}
					$rviFilter[] = $pro_id;
				}
				//echo '<br/>';
				$rvi = array_unique(array_values($rviFilter));

				CustomerSessionData::where('sid','=',$tokenid)->where('name','=','recent_viewed')->update(array('value'=>json_encode($rvi)));
				$recentViewedProdCount = count($rvi);
				$recentViewedProd = Product::whereIn('id',$rvi)->with('clean')->with('ProductImages')->get();
			}else{
				$rvi[] = $pro_id;
				$customer_ip = new CustomerSessionData;
				$customer_ip->sid = $tokenid;
				$customer_ip->name = 'recent_viewed';
				$customer_ip->value = json_encode($rvi);
				$customer_ip->save();
				$recentViewedProdCount = 0;
				$recentViewedProd = NULL;
			}
		}
		//------------------ RECENT VIEW ITEM CODE {END} --------------------//
							
		//print_r(DB::getQueryLog());
		$defaultOPTidsVar = explode(",",$varient->variant_com_opt_ids);
		$defaultOPTATTRids = $defaultOPTids = array();
		foreach($defaultOPTidsVar as $vv){
			$defaultOPTids[] = intval($vv);
		}
		$defaultATTRids = AttributesOptionModel::select("attr_id")->whereIn('id',$defaultOPTids)->get();
		foreach($defaultATTRids as $at){
			$defaultOPTATTRids[] = intval($at->attr_id);
		}
		//dd($defaultOPTATTRids);
		return response()->json(array(
								'data'=>array($data),
								'ProductImages'=>$images,
								'groupedProds'=>$groupedProds,
								'ProductAttributes'=>$ProductAttributes,
								'ProductAttributesOptions'=>$ProductAttributesOptions,
								'Metal'=>$Metal,
								'StoneType'=>$StoneType,
								'RingWidth'=>$RingWidth,
								'RingDepth'=>$RingDepth,
								'RingSize'=>$RingSize,
								'RingShape'=>$RingShape,
								'Style'=>$Style,
								'Shape'=>$Shape,
								'Carat'=>$Carat,
								'Colour'=>$Colour,
								'Certificate'=>$Certificate,
								'Clarity'=>$Clarity,
								'Mens'=>$Mens,
								'Ladies'=>$Ladies,
								'ChainLength'=>$ChainLength,
								'defaultOPTids'=>$defaultOPTids,
								'defaultOPTATTRids'=>$defaultOPTATTRids,
								'defaultPrice'=>$varient->variant_price,
								'variant_id'=>$varient->id,
								'recentViewedProdCount'=>$recentViewedProdCount,
								'recentViewedProd'=>$recentViewedProd,
								'loading_contenttype'=>2
							),201);
	
	}


	public function productPrice(Request $request){

		$variant = array_filter(explode(",",$request->variant));
		$product_id = $request->product_id;
		
		$q = DB::table('product_variants')
						->select('variant_price','id')
						->where('product_id',$product_id);
		foreach($variant as $opt){
			$q->whereRaw("find_in_set($opt,variant_com_opt_ids)");
		}
		$data = $q->first();
		return response()->json(array('variant_price'=>$data->variant_price,'variant_id'=>$data->id,'loading_contenttype'=>2),201);
     }

     public function addtofavourite(Request $request){

			/*$tokenkey    =  $request->tokenkey;
			$tokenid     =  $request->tokenid;*/
			$productId   =  $request->productId;
			$token      =  $request->token;
			$validuserData = JWTAuth::toUser($token);
	     	if($validuserData){
				$customerId  = $validuserData->id;
				$data = DB::table('products')->select('sku','name','price')->where('id',$productId)->first();
				$p_name = $data->name;
				$p_sku = $data->sku;
				$p_price = $data->price;

        $customerdata = Wishlist::where('product_id',$productId)->where('customer_id', $customerId)->first();
        if (!isset($customerdata)) 
        {
                  
	        $wl = new Wishlist;
	    	$wl->product_id  =     $productId;
	    	$wl->customer_id =     $customerId;
	    	$wl->sku         =     $p_sku;
	    	$wl->name        =     $p_name;
	    	$wl->price       =     $p_price; 
	    	$wl->save();
    	return json_encode(array('message' => 'product added successfully','status' => 'true', 'statuscode'=>201));
    	 
        }else{

    	 	return json_encode(array('message' => 'product already exists','status' => 'false', 'statuscode'=>208));
    	 }

    }else{

      return json_encode(array('message' => 'Token Mismatch error','status' => 'false', 'statuscode'=>400));
    	
    }
          
     }
     public function checkProductAvaialbility(Request $request){
    

      $productId    =   $request->input('productId');
      $customerId   =   $request->input('customerId');
   
        $customerdata = Wishlist::where('product_id',$productId)->where('customer_id', $customerId)->first();
        if (!isset($customerdata)) 
        {
          
    	return json_encode(array('message' => 'product not available in Wishlist','status' => 'false', 'statuscode'=>208));
    	 
        }else{

    	 	return json_encode(array('message' => 'product already exists','status' => 'true', 'statuscode'=>201));
    	 }
          
     }
	


    

}
