<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

use App\Customer;

class LoginController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['customerlogin']]);
    }

    public function doLogin(Request $request)
    {

       $data = $request->json()->all();

        $email = $data['email'];
        $pass = $data['password']; 
        $credentials = array([   
                                'email' =>           $email,
                                'password' =>        $pass
                           ]);


      // $credentials = request(['email', 'password']);

        if (! $token = auth('api')->attempt($credentials)) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

         $this->respondWithToken($token);




    	

        /*$customerdata = Customer::where('email', '=', $email)->first();
        if (isset($customerdata)) 
        {
    	
    	 if(Hash::check($pass, $customerdata->password)){

    	 		return json_encode(array('message' => 'success','status' => 'true','id' => $customerdata->id,'email' => $customerdata->email)); 

    	 }else{

    	 	return json_encode(array('message' => 'Invalid Email and Password','status' => 'false'));
    	 }
       }else{
    	 	return json_encode(array('message' => 'Email do not exists','status' => 'false'));
    	 }*/
         //return 'kush';
 }

    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth('api')->factory()->getTTL() * 60
        ]);
    }
}
