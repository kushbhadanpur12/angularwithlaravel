 <?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\AdatleyControllers\OrderHistoryController;
use App\Http\Controllers\AdatleyControllers\EmailNotificationController;
use App\Order;
use App\Payment;
use App\ShippingStatu;
use App\GlobalSetting;
use App\CustomerSession;
use App\OrderTransaction;
use App\CustomerSessionData;
use DB;
use Mail;
use Auth;
use Excel;
use Session;
use App\User;
use App\Country;
use App\Shipping;
use App\Currency;
use App\CustAddrBook;
use App\PaymentMethod;
use App\OrderHistoryEvent;
use App\OrderTrackingNumber;
use App\PaymentMethodsSetting;


class ResponseController extends Controller
{

 /****************************************   Received All Response   ****************************************************/

    public function getPaymentResponse(Request $request){
	
		$siteUrl =  GlobalSetting::select('value')->where('name','site_url')->first();
		  	
		$uniqId =''; $res_status =''; $res_result =array(); $txnId =''; $currency_code =''; $angelic_txn_no =''; $amount =''; $paymethod=''; $orderId='';
		
		//---------------- FOR PAYPAL RESPONSES ----------------------------//
		if($request->paymentmethod==='paypal')
		 {
			$paypal_response_all = $request->all();
			$paypal_response = $_POST;
			$uniqId = $request->uniqueId;
			$action = $request->action;
			$paymethod = 'paypal';
			if($request->txn_id){
				$txnId = $request->txn_id;
			}
			if($request->tx){
				$txnId = $request->tx;
			}
			
			if($uniqId!=null && $uniqId!='undefined'){
				$OId = Order::select('id')->where('angelic_transaction_number',$uniqId)->first();
				$orderId  = $OId->id;
				$orderDetails = Order::find($orderId);
				$paymentMDetails = PaymentMethod::find($orderDetails->payment_method_id);
				$author_id = $orderDetails->profile_id;
			}
			
			$res_status = $action;
			$res_result = [ "order_id"=>$orderId, "paypal_response"=>$uniqId  ];
			$this->update_order_transaction_detail($res_result,$orderId,$txnId,$res_status);		 
			$this->save_transaction_history($res_result,$orderId,$txnId,$res_status,$uniqId,$paymethod);
					 
			if($action=='success'){
				
				if($paypal_response['payment_status']=='Completed' || $paypal_response['payment_status']=='Pending'){
 					$current = GlobalSetting::where('name','next_order_number')->first();
					$order_number = $current['value'];
 					if($paypal_response['payment_status']=='Completed'){
						$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>4, 'shipping_status_id' =>1);
						$updated =  Order::where('id',$orderId)->update($data);
						
						$code_key = 'change_payment_status';
						$pstatus = Payment::find($orderDetails->payment_status_id);
						$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Completed]';
						$description = '';
						foreach($paypal_response as $key=>$val){
							$description = $description.$key.': '.$val.'<br/>';
						}
						$olddata = $pstatus->name;
						$newdata = 'Completed';
						OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
					
						$sendEmails = new EmailNotificationController;
						$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
						$confirm = new CustomerSessionData;
						$confirm->sid = $getSessionId[0]->sid;
						$confirm->name = 'confirm_order_number';
						$confirm->value = $order_number;
						$confirm->save();
						
						if($sendEmails->sendOrderEmails('order_processed', $orderId)){
							CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
							$nextOrderId = intval($order_number)+1;
							
							if($updated){
								 $data1 = array('value' => $nextOrderId);
								 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
							}
							return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
						}
					}elseif($paypal_response['payment_status']=='Pending'){
						
						$code_key = 'change_payment_status';
						$pstatus = Payment::find($orderDetails->payment_status_id);
						$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Pending]';
						$description = '';
						foreach($paypal_response as $key=>$val){
							$description = $description.$key.': '.$val.'<br/>';
						}
						
						$olddata = $pstatus->name;
						$newdata = 'Pending';
						OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
						
						$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>1, 'shipping_status_id' =>1);
						$updated =  Order::where('id',$orderId)->update($data);
						
						$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
						$confirm = new CustomerSessionData;
						$confirm->sid = $getSessionId[0]->sid;
						$confirm->name = 'confirm_order_number';
						$confirm->value = $order_number;
						$confirm->save();
						
						CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
						$nextOrderId = intval($order_number)+1;
						
						if($updated){
							 $data1 = array('value' => $nextOrderId);
							 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
						}
						
						return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
					}
				}elseif($paypal_response['payment_status']=='Failed'){
					//--- SAVE PAYMENT HISTORY (Change payment status) -----------//
					$code_key = 'change_payment_status';
					$description = NULL;
					$pstatus = Payment::find($orderDetails->payment_status_id);
					$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Failed]';
					$description = '';
					foreach($paypal_response as $key=>$val){
						$description = $description.$key.': '.$val.'<br/>';
					}
					$olddata = $pstatus->name;
					$newdata = 'Failed';
					OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
					
					$data = array( 'payment_status_id' => 5 );
					$updated =  Order::where('id',$orderId)->update($data);
					
					$sendEmails = new EmailNotificationController;
					if($sendEmails->sendOrderEmails('order_failed', $orderId)){
						return redirect($siteUrl->value.'/checkout.html');
					}
				}
		
			}elseif($action=='cancel'){
				
				//--- SAVE PAYMENT HISTORY (Change payment status) -----------//
				$code_key = 'change_payment_status';
				$description = NULL;
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'cancel: Customer has canceled checkout before completing their payments';
				$description = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Cancelled]';
				$olddata = $pstatus->name;
				$newdata = 'Cancelled';
				OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
				
				$data = array( 'payment_status_id' => 6 );
				$updated =  Order::where('id',$orderId)->update($data);
				
				$sendEmails = new EmailNotificationController;
				$sendEmails->sendOrderEmails('order_canceled', $orderId);
				if($sendEmails->sendOrderEmails('order_canceled', $orderId)){
					return redirect($siteUrl->value.'/checkout.html');
				}
			}else{
				return redirect($siteUrl->value.'/checkout.html');
			}
						
		 }
		 
		//---------------- FOR DEKO (PAY4LATER) RESPONSES ----------------------------//
		if($request->paymentmethod==='deko'){
		    //http://127.0.0.1/api/getdekopaymentresponse?paymentmethod=deko&status=Success&retaileruniqueref=deko_2_1523011017
			$uniqId          =   $request->retaileruniqueref;
			$res_status 	 =   $request->status;
			$paymethod		 =   'deko';
			$action 		 =   $request->status;
			
			if($uniqId!=null && $uniqId!='undefined'){
				$OId = Order::where('angelic_transaction_number',$uniqId)->first();
				$orderId  = $OId->id;
				$methodId = $OId->payment_method_id;
				$orderDetails = Order::find($orderId);
				$paymentMDetails = PaymentMethod::find($orderDetails->payment_method_id);
				$author_id = $orderDetails->profile_id;
			}
			
			$payment_detail = array();
			$pm = PaymentMethod::find($methodId);
			$payment_detail['name'] = $pm->name;
			$pms = PaymentMethodsSetting::where('payment_methods_id',$methodId)->get();
			foreach($pms as $val){
				if(@unserialize($val->value) !== false){
					$payment_detail[$val->name] = unserialize($val->value);
				}else{
					$payment_detail[$val->name] = $val->value;
				}
			}
			
			if($payment_detail['mode']=='test'){
				$interface = "https://test.pay4later.com:3343/";
			}elseif($payment_detail['mode']=='test'){
				$interface = "https://secure.pay4later.com:6686/";
			}
			
			$postFields = array(
								"retaileruniqueref" => $uniqId,
								"api_key" => $payment_detail['api_key'],
								"request_state" => "true",
							);
			$curlSession = curl_init();
			curl_setopt($curlSession, CURLOPT_URL, $interface);
			curl_setopt($curlSession, CURLOPT_HEADER, 0);
			curl_setopt($curlSession, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($curlSession, CURLOPT_POST, 1);
			curl_setopt($curlSession, CURLOPT_POSTFIELDS, $postFields);
			curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curlSession, CURLOPT_TIMEOUT, 180);
			curl_setopt($curlSession, CURLOPT_FOLLOWLOCATION, 1);
			$curl_response = curl_exec($curlSession);
			$ob= simplexml_load_string($curl_response);
			$json  = json_encode($ob);
			$configData = json_decode($json, true);
			$txnId = $configData['cr_id'];
			
			//dd($action);
			
			$res_result = [
						"order_id"=>$orderId,
						"res_status"=>$res_status,
						"txnId"=>$txnId,
						"angelic_transaction_number"=>$uniqId
					 ];
						 
			$this->update_order_transaction_detail($res_result,$orderId,$txnId,$res_status);		 
			$this->save_transaction_history($res_result,$orderId,$txnId,$res_status,$uniqId,$paymethod);
			
			if($action=='Success'){
				if($configData['decision']=='VERIFIED' || $configData['decision']=='ACCEPT'){
					$current = GlobalSetting::where('name','next_order_number')->first();
					$order_number = $current['value'];
					
					$code_key = 'change_payment_status';
					$pstatus = Payment::find($orderDetails->payment_status_id);
					$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Completed]';
					$description = '';
					$description = $description.'Pay4Later Credit ID: '.$configData['cr_id'].'<br/>';
					$description = $description.'Pay4Later Status: '.$configData['decision'].'<br/>';
					$olddata = $pstatus->name;
					$newdata = 'Completed';
					OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
					
					$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>4, 'shipping_status_id' =>1);
					$updated =  Order::where('id',$orderId)->update($data);
					
					$sendEmails = new EmailNotificationController;
					$sendEmails->sendOrderEmails('order_processed', $orderId);
					
				    	$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
						$confirm = new CustomerSessionData;
						$confirm->sid = $getSessionId[0]->sid;
						$confirm->name = 'confirm_order_number';
						$confirm->value = $order_number;
						$confirm->save();
						
					if($sendEmails->sendOrderEmails('order_processed', $orderId)){
						CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
						$nextOrderId = intval($order_number)+1;
						if($updated){
							 $data1 = array('value' => $nextOrderId);
							 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
						}
						return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
					}	
				}
				
			}elseif($action=='Declined'){
				
				$code_key = 'change_payment_status';
				$description = NULL;
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Failed]';
				$description = '';
				$description = $description.'Pay4Later Credit ID: '.$configData['cr_id'].'<br/>';
				$description = $description.'Pay4Later Status: '.$configData['decision'].'<br/>';
				$olddata = $pstatus->name;
				$newdata = 'Failed';
				OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
				
				$data = array( 'payment_status_id' => 5 );
				$updated =  Order::where('id',$orderId)->update($data);
				
				$sendEmails = new EmailNotificationController;
				if($sendEmails->sendOrderEmails('order_failed', $orderId)){
					return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
				}
				
			}elseif($action=='Referred'){
				$current = GlobalSetting::where('name','next_order_number')->first();
				$order_number = $current['value'];

				$code_key = 'change_payment_status';
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Awaiting payment]';
				$description = '';
				$description = $description.'Pay4Later Credit ID: '.$configData['cr_id'].'<br/>';
				$description = $description.'Pay4Later Status: '.$configData['decision'].'<br/>';
				$olddata = $pstatus->name;
				$newdata = 'Awaiting payment';
				OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
				
				$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>1, 'shipping_status_id' =>1);
				$updated =  Order::where('id',$orderId)->update($data);
				
				//$sendEmails = new EmailNotificationController;
				//$sendEmails->sendOrderEmails('order_processed', $orderId);
				
				$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
				$confirm = new CustomerSessionData;
				$confirm->sid = $getSessionId[0]->sid;
				$confirm->name = 'confirm_order_number';
				$confirm->value = $order_number;
				$confirm->save();
				
				CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
				$nextOrderId = intval($order_number)+1;
				if($updated){
					 $data1 = array('value' => $nextOrderId);
					 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
				}
				return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
			}elseif($action=='Cancelled'){
				$code_key = 'change_payment_status';
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Cancelled]';
				$description = '';
				
				$olddata = $pstatus->name;
				$newdata = 'Cancelled';
				OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
				
				$data = array('payment_status_id' =>6, 'shipping_status_id' =>7);
				$updated =  Order::where('id',$orderId)->update($data);
				
				$sendEmails = new EmailNotificationController;
				if($sendEmails->sendOrderEmails('order_processed', $orderId)){
					return redirect($siteUrl->value.'checkout.html');
				}
			}
			
		 }
		 
		//---------------- FOR BANK TRANSFER RESPONSES ----------------------------//
		if($request->paymentmethod === 'banktransfer'){
	
		//http://127.0.0.1:8000/api/getPaymentResponse?paymentmethod=banktransfer&status=success&uniqueId=bank_2_1523019786571
				  
		$uniqId          =   $request->uniqueId;
		$res_status 	 =   $request->status;
		$paymethod		 =   'bank';
		$txnId           =   $uniqId;
		
		if($uniqId!=null && $uniqId!='undefined'){
			$OId = Order::select('id')->where('angelic_transaction_number',$uniqId)->first();
			$orderId  = $OId->id;
			$orderDetails = Order::find($orderId);
			$paymentMDetails = PaymentMethod::find($orderDetails->payment_method_id);
			$author_id = $orderDetails->profile_id;
		}
		
		$res_result = [
			"order_id"=>$orderId,
			"res_status"=>$res_status,
			"txnId"=>$txnId,
			"angelic_transaction_number"=>$uniqId
		   ];
						 
		$this->update_order_transaction_detail($res_result,$orderId,$txnId,$res_status);		 
		$this->save_transaction_history($res_result,$orderId,$txnId,$res_status,$uniqId,$paymethod);
		
		if($res_status==='success'){ 
			$current = GlobalSetting::where('name','next_order_number')->first();
			$order_number = $current['value'];

			$code_key = 'change_payment_status';
			$pstatus = Payment::find($orderDetails->payment_status_id);
			$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Awaiting payment]';
			$description = '';
			$description = 'banktransfer: '.$txnId.'<br/>';
			$olddata = $pstatus->name;
			$newdata = 'Awaiting payment';
			OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
			
			$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>1, 'shipping_status_id' =>1);
			$updated =  Order::where('id',$orderId)->update($data);
			
			//$sendEmails = new EmailNotificationController;
			//$sendEmails->sendOrderEmails('order_processed', $orderId);
			
			$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
			$confirm = new CustomerSessionData;
			$confirm->sid = $getSessionId[0]->sid;
			$confirm->name = 'confirm_order_number';
			$confirm->value = $order_number;
			$confirm->save();
			
			CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
			$nextOrderId = intval($order_number)+1;
			if($updated){
				 $data1 = array('value' => $nextOrderId);
				 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
			}
			return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
		}else{
			return redirect($siteUrl->value.'/checkout.html');	
		}
	}
		 
		 
		//---------------- FOR SAGEPAY RESPONSES ----------------------------//
		if($request->paymentmethod === 'sagepay'){
			$uniqId = $request->angelic_transaction_number;
			$OId = Order::select('id')->where('angelic_transaction_number',$uniqId)->first();
			$orderId  = $OId->id;
			$orderDetails = Order::find($orderId);
			$paymentMDetails = PaymentMethod::find($orderDetails->payment_method_id);
			$author_id = $orderDetails->profile_id;
			
			if($request->PaRes!='' && $request->MD!=''){
			  	
				$paRes   = $request->PaRes;
				$md      = $request->MD;
				$MDX     = $request->MDX;
				
				$methodId = $orderDetails->payment_method_id;
				$payment = PaymentMethod::find($methodId);
				$payment_detail = array();
				$pd = PaymentMethodsSetting::where('payment_methods_id',$methodId)->get();
				
				$payment_detail['id'] = $payment->id;
				$payment_detail['processor_name'] = $payment->processor_name;
				$payment_detail['name'] = $payment->name;
				$payment_detail['instructions'] = $payment->instructions;
				$payment_detail['detail'] = $payment->detail;
				$payment_detail['payment_logo'] = $payment->payment_logo;
				
				foreach($pd as $val){
					if(@unserialize($val->value) !== false){
						$payment_detail[$val->name] = unserialize($val->value);
					}else{
						$payment_detail[$val->name] = $val->value;
					}
				}
				
				if($payment_detail['mode']=='test'){
					$sec3dURL = 'https://pi-test.sagepay.com/api/v1/transactions/';
					$transactionsURL = 'https://pi-test.sagepay.com/api/v1/transactions/';
				}elseif($payment_detail['mode']=='live'){
					$sec3dURL = 'https://pi-live.sagepay.com/api/v1/transactions/';
					$transactionsURL = 'https://pi-live.sagepay.com/api/v1/transactions/';
				}
				
				$transdetail = Order::select('transactionId','id')->where('angelic_transaction_number',$md)->get();
				$transactionId = $transdetail[0]['transactionId'];
				$orderId = $transdetail[0]['id'];
				$userInfo = base64_encode("EsaG02eboKfohQCAT7dXkXFViFilvUpJSEHqv9kAO7pRphu2yh:UVyNWMNKjRzAO8lNCg5Sx53bA7GrlhVGlBIuJJu8hT4VXgI48lOjCIYZCK0059fGz");
				if(isset($paRes)){
					
					$curl = curl_init();
					curl_setopt_array($curl, array(
					CURLOPT_URL => $sec3dURL.$transactionId."/3d-secure",
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_CUSTOMREQUEST => "POST",
					CURLOPT_POSTFIELDS => '{ "paRes": "'.$paRes.'" }',
					CURLOPT_HTTPHEADER => array(
					
						"Authorization: Basic $userInfo",
						"Cache-Control: no-cache",
						"Content-Type: application/json"
					),
					));
					
					$response = curl_exec($curl);
					$response = json_decode($response, true);
					$err = curl_error($curl);
	
					curl_setopt_array($curl, array(
					CURLOPT_URL => $transactionsURL.$transactionId,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_CUSTOMREQUEST => "GET",
					CURLOPT_HTTPHEADER => array(
					"Authorization: Basic $userInfo",
					"Cache-Control: no-cache"
					),
				));
					 
					$response2 = curl_exec($curl);
					$response2 = json_decode($response2, true);
					$err = curl_error($curl);
					curl_close($curl);
					
					$sagepay_response = $response2;
					
					$paymethod = 'sagepay';
					//$res_result = json_encode($response2);
					$res_result = $response2;
					
					$res_status = $response2['status'];
	
					$this->update_order_transaction_detail($res_result,$orderId,$transactionId,$res_status);		 
					$this->save_transaction_history($res_result,$orderId,$transactionId,$res_status,$md,$paymethod);
					
					if($response2['status']==="Ok"){
						$current = GlobalSetting::where('name','next_order_number')->first();
						$order_number = $current['value'];
						
						if($response2['transactionType']==="Payment"){
							$code_key = 'change_payment_status';
							$pstatus = Payment::find($orderDetails->payment_status_id);
							$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Completed]';
							$description = '';
							
							foreach($sagepay_response as $key=>$val){
								$description = $description.$key.': '.serialize($val).'<br/>';
							}
							
							$olddata = $pstatus->name;
							$newdata = 'Completed';
							OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
							
							$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>4, 'shipping_status_id' =>1);
							$updated =  Order::where('id',$orderId)->update($data);
							
							$sendEmails = new EmailNotificationController;
							
							$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
							$confirm = new CustomerSessionData;
							$confirm->sid = $getSessionId[0]->sid;
							$confirm->name = 'confirm_order_number';
							$confirm->value = $order_number;
							$confirm->save();
							
							if($sendEmails->sendOrderEmails('order_processed', $orderId)){
								CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
								$nextOrderId = intval($order_number)+1;
							
								if($updated){
									 $data1 = array('value' => $nextOrderId);
									 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
								}
								
								return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
							}
						}elseif($response2['transactionType']==="Deferred"){
							
							$code_key = 'change_payment_status';
							$pstatus = Payment::find($orderDetails->payment_status_id);
							$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Pending]';
							$description = '';
							foreach($sagepay_response as $key=>$val){
								$description = $description.$key.': '.serialize($val).'<br/>';
							}
							
							$olddata = $pstatus->name;
							$newdata = 'Pending';
							OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
							$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>1, 'shipping_status_id' =>1);
							$updated =  Order::where('id',$orderId)->update($data);
							
							$getSessionId = CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->get();
							$confirm = new CustomerSessionData;
							$confirm->sid = $getSessionId[0]->sid;
							$confirm->name = 'confirm_order_number';
							$confirm->value = $order_number;
							$confirm->save();
							
							CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
							$nextOrderId = intval($order_number)+1;
						
							if($updated){
								 $data1 = array('value' => $nextOrderId);
								 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
							}
							return redirect($siteUrl->value.'/checkout-success.html?order_number='.$order_number);
							
						}
						
					}else{
				
						$code_key = 'change_payment_status';
						$description = NULL;
						$pstatus = Payment::find($orderDetails->payment_status_id);
						$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Failed]';
						$description = '';
						$olddata = $pstatus->name;
						$newdata = 'Failed';
						OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
						
						$data = array( 'payment_status_id' => 5 );
						$updated =  Order::where('id',$orderId)->update($data);
						
						$sendEmails = new EmailNotificationController;
						$sendEmails->sendOrderEmails('order_failed', $orderId);
						return redirect($siteUrl->value.'/checkout.html');
					}
				}
			  }else{
				
				$code_key = 'change_payment_status';
				$description = NULL;
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Failed]';
				$description = '';
				$olddata = $pstatus->name;
				$newdata = 'Failed';
				OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
				$data = array( 'payment_status_id' => 5 );
				$updated =  Order::where('id',$orderId)->update($data);
				$sendEmails = new EmailNotificationController;
				$sendEmails->sendOrderEmails('order_failed', $orderId);
				return redirect($siteUrl->value.'/checkout.html');
			  }
		  }
		  return redirect($siteUrl->value.'/checkout.html');
    }
	
	

	public function update_order_transaction_detail($result,$orderId,$txnId,$status){
		$res = json_encode($result);
		$txnId = $txnId;
		  $data = array(
				'transactionId' => $txnId,
				'response_result' => $res,
				'response_status' =>$status
			);
	   $da =  Order::where('id',$orderId)->update($data);
	   return $da;
	
	
	}
	
	public function save_transaction_history($result,$orderId,$txnId,$status,$angtransno,$paymethod){
	
		$res = json_encode($result);
		$order = new OrderTransaction;
		$order->order_id                   = 	$orderId;
		$order->angelic_transaction_number = 	$angtransno;
		$order->transactionId              = 	$txnId;
		$order->response_result 		   = 	$res;
		$order->response_status 	       = 	$status;
		$order->payment_method 	           = 	$paymethod;
		$order->save();
		return $order;
	}
   
	
 /*************************************  END SECTTION Received All Response   ******************************************/
 
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@







 
 
  /****************************************   DEKO PAYMENT GATEWAY   ****************************************************/


   public function dekopaymentdata( Request $request){

	$product_type 		= $request->product_type;
	$cost_of_goods 	    = $request->cost_of_goods;
	$deposit_percentage = $request->deposit_percentage;
	$deposit_amount 	= $request->deposit_amount;
	$consumer_forename  = $request->fname;
	$consumer_surname   = $request->lname;
	$consumer_email     = $request->email;
	$goodsdes       	= "Angelic Diamonds test" ;
	$interface          = "https://test.dekopay.com:3343/";
	$orderId 			= $request->orderid;
	$retaileruniqueref  = 'deko_'.$request->orderid.'_'.time();
	$paymethod 			= 'deko';
	$methodId 		= $request->methodId;
	$pm = PaymentMethod::find($methodId)->first();
	$pms = PaymentMethodsSetting::where('payment_methods_id',$methodId)->get();
	$PMSET = array();
	foreach($pms as $val){
		$PMSET[$val['name']] = $val['value'];
	}
	
    $postFields = array(
		'action'                           => 'credit_application_link',
		'Identification[api_key]'          => $PMSET['api_key'],
		'Identification[InstallationID]'   => $PMSET['installation_id'],
		'Identification[RetailerUniqueRef]'=> $retaileruniqueref,
		'Consumer[Forename]'               => $consumer_forename,
		'Consumer[Surname]'                => $consumer_surname,
		'Consumer[EmailAddress]'           => $consumer_email,
		'Finance[Code]'                    => $product_type,
		'Finance[Deposit]'                 => (round($cost_of_goods * 100) * $deposit_percentage / 100), 
		'Goods[Price]'                     => round($cost_of_goods * 100), 
		'Goods[Description]'               => $goodsdes
     );
	
	$curlSession = curl_init();
	curl_setopt($curlSession, CURLOPT_URL, $interface);
	curl_setopt($curlSession, CURLOPT_HEADER, 0);
	curl_setopt($curlSession, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($curlSession, CURLOPT_POST, 1);
	curl_setopt($curlSession, CURLOPT_POSTFIELDS, $postFields);
	curl_setopt($curlSession, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($curlSession, CURLOPT_TIMEOUT, 180);
	curl_setopt($curlSession, CURLOPT_FOLLOWLOCATION, 1);
	
	$curlResponse = curl_exec($curlSession);
    $result = array('redirUrl'=>$curlResponse);		
    $calltoSave = $this->update_Orderdetail($result,$orderId,$retaileruniqueref);
	
    return response()->json(array('redirUrl'=>$curlResponse,'status'=>'true','statusText'=>'success'));   	
   }


	public function update_Orderdetail($result,$orderId,$uniqId){
		$res = json_encode($result);
		$data = array(
			'response_result'    => $res,
			'angelic_transaction_number'=> $uniqId
		);
		$order =  Order::where('id',$orderId)->update($data);		
		return $order;
	}
   
  public function dekopaymentresponse(Request $request){
  		  $siteUrl =  GlobalSetting::select('value')->where('name','site_url')->first(); 
		  $uniqId   =  $request->retaileruniqueref;
		  $status 	=  $request->status;

           if($uniqId!=null && $uniqId!='undefined'){
              $OId = Order::select('id')->where('angelic_transaction_number',$uniqId)->get();
              $orderId  = $OId[0]['id'];
     
             $tblorder= $this->update_ordertransaction($status,$orderId,$uniqId);
             $tblordertrans= $this->save_deko_transaction_history($status,$orderId,$uniqId);

			  switch($status)
				{
					case 'Success' :
						CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
						return redirect($siteUrl->value.'/checkout-success.html?order_number='.$orderId);
						break;
			
					case 'Declined' :
						return redirect($siteUrl->value);
						break;
			
					case 'Cancelled' :
						return redirect($siteUrl->value);
						break;
			
					case 'Referred' :
						return redirect($siteUrl->value);
						break;
						
					default :
						return redirect($siteUrl->value);
				}

	   }else{
         return redirect($siteUrl->value);
	   }


  }

	public function update_ordertransaction($status,$orderId,$uniqId){
	
		 $data = array('response_status'    => $status);
		 $order =  Order::where('id',$orderId)->where('angelic_transaction_number',$uniqId)->update($data);		
		 return $order;
	}

  
   public function save_deko_transaction_history($status,$orderId,$uniqId){

            $paymethod = 'deko';
   			$order = new OrderTransaction;
   			$order->order_id                   = 	$orderId;
   			$order->angelic_transaction_number = 	$uniqId;
   			$order->response_status 	       = 	$status;
   			$order->payment_method 	           = 	$paymethod;
	        $order->save();
		    return $order;
   
   }
   
 /****************************************  END DEKO PAYMENT GATEWAY  ****************************************************/
 
  // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 
 
 
 
 
 
  /****************************************  PAYPAL PAYMENT GATEWAY  ****************************************************/
  
  
  
  
  /****************************************  END PAYPAL PAYMENT GATEWAY  ************************************************/
  
  
  // @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
  
  
  
  
  
  
  
  /****************************************  SAGEPAY PAYMENT GATEWAY  ****************************************************/
  
  
   public function get_sagepay_tokendata( Request $request){
   		$methodId = $request->methodId;
		$payment = PaymentMethod::find($methodId);
		$payment_detail = array();
		$pd = PaymentMethodsSetting::where('payment_methods_id',$methodId)->get();
		
		$payment_detail['id'] = $payment->id;
		$payment_detail['processor_name'] = $payment->processor_name;
		$payment_detail['name'] = $payment->name;
		$payment_detail['instructions'] = $payment->instructions;
		$payment_detail['detail'] = $payment->detail;
		$payment_detail['payment_logo'] = $payment->payment_logo;
		
		foreach($pd as $val){
			if(@unserialize($val->value) !== false){
				$payment_detail[$val->name] = unserialize($val->value);
			}else{
				$payment_detail[$val->name] = $val->value;
			}
		}

		if($payment_detail['mode']=='test'){
			$merchantURL = 'https://pi-test.sagepay.com/api/v1/merchant-session-keys';
			$cardURL = "https://pi-test.sagepay.com/api/v1/card-identifiers";
		}elseif($payment_detail['mode']=='live'){
			$merchantURL = 'https://pi-live.sagepay.com/api/v1/merchant-session-keys';
			$cardURL = "https://pi-live.sagepay.com/api/v1/card-identifiers";
		}
		
	  if($request->cardholdername!='' && $request->cardnumber!=''  && $request->mmyy!=''  && $request->cvv!='')
	    {
			$curl = curl_init();
			$userInfo = base64_encode("EsaG02eboKfohQCAT7dXkXFViFilvUpJSEHqv9kAO7pRphu2yh:UVyNWMNKjRzAO8lNCg5Sx53bA7GrlhVGlBIuJJu8hT4VXgI48lOjCIYZCK0059fGz");
			curl_setopt_array($curl, array(
				CURLOPT_URL => $merchantURL,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_SSL_VERIFYPEER => false,
				CURLOPT_SSL_VERIFYHOST => false,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => '{ "vendorName": "'.$payment_detail['vendor_name'].'" }',
				CURLOPT_HTTPHEADER => array(
					"Authorization:  Basic $userInfo ",
					"Cache-Control: no-cache",
					"Content-Type: application/json"
				)
			));
		
		$response = curl_exec($curl);
		$response = json_decode($response, true);
		$merchent_token =  $response['merchantSessionKey'];
		$err = curl_error($curl);
		
		$cardholdername  = 	$request->cardholdername;
		$cardnumber      = 	$request->cardnumber;
		$expiry          = 	$request->mmyy;
		$cvv             = 	$request->cvv;
		
		curl_setopt_array($curl, array(
		  CURLOPT_URL => $cardURL,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => '{' .
									'"cardDetails": {' .
									'    "cardholderName": "'.$cardholdername.'",' .
									'    "cardNumber": "'.$cardnumber.'",' .
									'    "expiryDate": "'.$expiry.'",' .
									'    "securityCode": "'.$cvv.'"' .
									'}' .
								'}',
		  CURLOPT_HTTPHEADER => array(
			"Authorization: Bearer ".$response['merchantSessionKey'],
			"Cache-Control: no-cache",
			"Content-Type: application/json"
		  ),
		));
		
		$response1 = curl_exec($curl);
		$response1 = json_decode($response1, true);
		$err = curl_error($curl);
		curl_close($curl);
			if(isset($response1['errors'])){
			      return response()->json(array('merchantSessionKey'=>$response['merchantSessionKey'],'error'=>$response1,'status'=>'false','statusText'=>'error'));
			}else{
			return response()->json(array('merchantSessionKey'=>$response['merchantSessionKey'],'cardIdentifiers'=>$response1['cardIdentifier'],'cardType'=>$response1['cardType'],'status'=>     'true','statusText'=>'success'));
			}
		}else{
			 return response()->json(array('merchantSessionKey'=>'','req'=>$request,'error'=>'invalid request','status'=>'invalid','statusText'=>'error'));
		}
   }

  public function makesagepay_payments( Request $request){
		$methodId = $request->methodId;
		$payment = PaymentMethod::find($methodId);
		$payment_detail = array();
		$pd = PaymentMethodsSetting::where('payment_methods_id',$methodId)->get();
		$payment_detail['id'] = $payment->id;
		$payment_detail['processor_name'] = $payment->processor_name;
		$payment_detail['name'] = $payment->name;
		$payment_detail['instructions'] = $payment->instructions;
		$payment_detail['detail'] = $payment->detail;
		$payment_detail['payment_logo'] = $payment->payment_logo;
		foreach($pd as $val){
			if(@unserialize($val->value) !== false){
				$payment_detail[$val->name] = unserialize($val->value);
			}else{
				$payment_detail[$val->name] = $val->value;
			}
		}
		
		if($payment_detail['mode']=='test'){
			$transactionsURL = 'https://pi-test.sagepay.com/api/v1/transactions';
		}elseif($payment_detail['mode']=='live'){
			$transactionsURL = 'https://pi-live.sagepay.com/api/v1/transactions';
		}
		$tokenkey  				 =  $request->tokenkey;
		$tokenid   				 =  $request->tokenid;
		$cardIdentifiers         = 	$request->cardidentifiers;
		$merchantSessionKey      = 	$request->merchantSessionKey;
		$sagepaymoto             = 	$request->sagepaymoto;
		$sessionData = CustomerSession::select('id') ->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
			 
		if($sessionData){
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionData->id)->first();
				$orderId   =  $customer_orderid->value;
				$orderDetails = Order::find($customer_orderid->value);
			    $billingAddr  =  CustAddrBook::where('id',$orderDetails->billing_addr_id)->with("country")->get();
				$paymentMDetails = PaymentMethod::find($orderDetails->payment_method_id);
				$author_id = $orderDetails->profile_id;
				$paymethod	 =  'sagepay';
				$amount = intval(round($orderDetails->total,2) * 100);
				$currency = "GBP";
				$firstName = $billingAddr[0]->fname;
				$lastName = $billingAddr[0]->lname;
				$billing_address = $billingAddr[0]->addr1;
				$billing_city = $billingAddr[0]->city;
				$billing_zip = $billingAddr[0]->post_code;
				$billing_country = $billingAddr[0]->Country->name;

	           $curl = curl_init();
			   
			   if($sagepaymoto==1){
				   $userInfo = base64_encode("EsaG02eboKfohQCAT7dXkXFViFilvUpJSEHqv9kAO7pRphu2yh:UVyNWMNKjRzAO8lNCg5Sx53bA7GrlhVGlBIuJJu8hT4VXgI48lOjCIYZCK0059fGz");
					curl_setopt_array($curl, array(
					CURLOPT_URL => $transactionsURL,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_SSL_VERIFYHOST => false,
					CURLOPT_CUSTOMREQUEST => "POST",
					CURLOPT_POSTFIELDS => '{' .
					'"transactionType": "Payment",' .
					'"paymentMethod": {' .
					'    "card": {' .
					'        "merchantSessionKey": "' . $merchantSessionKey . '",' .
					'        "cardIdentifier": "' . $cardIdentifiers . '"' .
					'    }' .
					'},' .
					'"vendorTxCode": "SagePayExample' . time() . '",' .
					'"amount": ' . $amount . ',' .
					'"currency": "' . $currency . '",' .
					'"description": "Sage Payment Integration Example",' .
					'"apply3DSecure": "UseMSPSetting",' .
					'"customerFirstName": "' . $firstName . '",' .
					'"customerLastName": "' . $lastName . '",' .
					'"billingAddress": {' .
					'    "address1": "' . $billing_address . '",' .
					'    "city": "' . $billing_city . '",' .
					'    "postalCode": "' . $billing_zip . '",' .
					'    "country": "' . $billing_country . '"' .
					'},' .
					'"entryMethod": "TelephoneOrder"' .
					'}',
					CURLOPT_HTTPHEADER => array(
					   "Authorization:  Basic $userInfo",
						"Cache-Control: no-cache",
						"Content-Type: application/json"
					),
				));
			}else{
				
			   $userInfo = base64_encode("EsaG02eboKfohQCAT7dXkXFViFilvUpJSEHqv9kAO7pRphu2yh:UVyNWMNKjRzAO8lNCg5Sx53bA7GrlhVGlBIuJJu8hT4VXgI48lOjCIYZCK0059fGz");
					curl_setopt_array($curl, array(
					CURLOPT_URL => $transactionsURL,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_SSL_VERIFYHOST => false,
					CURLOPT_CUSTOMREQUEST => "POST",
					CURLOPT_POSTFIELDS => '{' .
					'"transactionType": "Payment",' .
					'"paymentMethod": {' .
					'    "card": {' .
					'        "merchantSessionKey": "' . $merchantSessionKey . '",' .
					'        "cardIdentifier": "' . $cardIdentifiers . '"' .
					'    }' .
					'},' .
					'"vendorTxCode": "SagePayExample' . time() . '",' .
					'"amount": ' . $amount . ',' .
					'"currency": "' . $currency . '",' .
					'"description": "Sage Payment Integration Example",' .
					'"apply3DSecure": "UseMSPSetting",' .
					'"customerFirstName": "' . $firstName . '",' .
					'"customerLastName": "' . $lastName . '",' .
					'"billingAddress": {' .
					'    "address1": "' . $billing_address . '",' .
					'    "city": "' . $billing_city . '",' .
					'    "postalCode": "' . $billing_zip . '",' .
					'    "country": "' . $billing_country . '"' .
					'},' .
					'"entryMethod": "Ecommerce"' .
					'}',
					CURLOPT_HTTPHEADER => array(
					   "Authorization:  Basic $userInfo",
						"Cache-Control: no-cache",
						"Content-Type: application/json"
					),
				));
			}
			$response = curl_exec($curl);
			$result = json_decode($response);
			$sagepay_response = (array) $result;
			$err = curl_error($curl);
			$res_status='succes';
			$uniqId = 'sage_'.$orderId.'_'.time();
		    $ang = array( 'angelic_transaction_number' => $uniqId);
			$updated =  Order::where('id',$orderId)->update($ang);
			$orderDetails = Order::find($orderId);
			$this->update_order_transaction_detail($result,$orderId,$result->transactionId,$res_status);		 
			$this->save_transaction_history($result,$orderId,$result->transactionId,$res_status,$uniqId,$paymethod);
			if(isset($result->errors)){
			      return response()->json(array('data'=>$result,'status'=>'false','statusText'=>'error'));
			}else{
				 	if($result->status==="Ok"){
						$current = GlobalSetting::where('name','next_order_number')->first();
						$order_number = $current['value'];
						
						if($result->transactionType==="Payment"){
							$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>4, 'shipping_status_id' =>1);
							$updated =  Order::where('id',$orderId)->update($data);
							
							$code_key = 'change_payment_status';
							$pstatus = Payment::find($orderDetails->payment_status_id);
							$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Completed]';
							$description = '';
							
							foreach($sagepay_response as $key=>$val){
								$description = $description.$key.': '.serialize($val).'<br/>';
							}
							
							$olddata = $pstatus->name;
							$newdata = 'Completed';
							OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
							
							$sendEmails = new EmailNotificationController;
							$sendEmails->sendOrderEmails('order_processed', $orderId);	
						}elseif($result->transactionType==="Deferred"){
							
							$data = array( 'orderNumber' => $order_number, 'confirm_date' => time(), 'is_order' =>1, 'payment_status_id' =>1, 'shipping_status_id' =>1);
							$updated =  Order::where('id',$orderId)->update($data);
							
							$code_key = 'change_payment_status';
							$pstatus = Payment::find($orderDetails->payment_status_id);
							$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Pending]';
							$description = '';
							foreach($sagepay_response as $key=>$val){
								$description = $description.$key.': '.serialize($val).'<br/>';
							}
							
							$olddata = $pstatus->name;
							$newdata = 'Pending';
							OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
						}
						CustomerSessionData::where('name','=','customer_orderid')->where('value','=',$orderId)->delete();
						  
						$nextOrderId = intval($order_number)+1;
					
						if($updated){
							 $data1 = array('value' => $nextOrderId);
							 $update2 =  GlobalSetting::where('id',$current->id)->where('name','next_order_number')->update($data1);
						}
						
						return response()->json(array('data'=>$result,'order_number'=>$order_number,'status'=>'true','statusText'=>'success'));
						
					}elseif($result->status==="NotAuthed" || $result->status==="Rejected" || $result->status==="Malformed" || $result->status==="Invalid" || $result->status==="Error"){
						//--- SAVE PAYMENT HISTORY (Change payment status) -----------//
						$code_key = 'change_payment_status';
						$description = NULL;
						$pstatus = Payment::find($orderDetails->payment_status_id);
						$code = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: Failed]';
						$description = '';
						foreach($paypal_response as $key=>$val){
							$description = $description.$key.': '.$val.'<br/>';
						}
						$olddata = $pstatus->name;
						$newdata = 'Failed';
						OrderHistoryController::saveOrderHistoryByOrderId($orderId, $author_id, $code_key, $code, $description, $olddata, $newdata);
						
						$data = array( 'payment_status_id' => 5 );
						$updated =  Order::where('id',$orderId)->update($data);
						
						$sendEmails = new EmailNotificationController;
						$sendEmails->sendOrderEmails('order_failed', $orderId);
						
						return response()->json(array('message'=>'Transaction failed. Please try again','status'=>'failed','statusText'=>'Failed'));;
					}elseif($result->statusCode==="2007"){
						return response()->json(array('data'=>$result, 'order_number'=>$orderId, 'angelic_transaction_number'=>$orderDetails->angelic_transaction_number, 'status'=>'true', 'statusText'=>'3DAuth'));
					}
			}
		}else{
		     return response()->json(array('message'=>'token does not match','status'=>'false','statusText'=>'Error'));;
		}

   }

  
  /****************************************  END SAGEPAY PAYMENT GATEWAY  ************************************************/

}

