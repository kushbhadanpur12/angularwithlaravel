<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Currency;
use App\Order;
use App\CustomerSession;
use App\CustomerSessionData;
use App\Staticpages;
use App\Category;
use Session;
use DB;

class CommonController extends Controller
{
    
    public function createCustomerToken(Request $request){
        
        $tokenid = (int)$request->input('tokenid');
        $currencies = Currency::all();
		
		$CustomerSession = CustomerSession::find($tokenid);
		
		if($CustomerSession){
			$customerCurrency = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_currency')->first();
			$response = [
				'tokenid'   => $tokenid,
				'tokenkey'   => $CustomerSession->custome_token,
				'currenciesAll' => $currencies,
				'customer_currency' => $customerCurrency->value
			];
			return response()->json(array('new' => 0, 'result' => $response));
		}else{
            $token = md5(uniqid(rand().time(), true));
            
            $CustomerSession = new CustomerSession;
            $CustomerSession->custome_token = $token;
            $CustomerSession->save();
            $tokenid = $CustomerSession->id;
            
            $defaultCur = Currency::where('default',1)->first();
            
            $customer_ip = new CustomerSessionData;
            $customer_ip->sid = $tokenid;
            $customer_ip->name = 'customer_ip';
            $customer_ip->value = $_SERVER['REMOTE_ADDR'];
            $customer_ip->save();
            
            $customerCurrency = new CustomerSessionData;
            $customerCurrency->sid = $tokenid;
            $customerCurrency->name = 'customer_currency';
            $customerCurrency->value = json_encode(array(
                                                        'id' => $defaultCur->id,
                                                        'name' => $defaultCur->name,
                                                        'code' => $defaultCur->code,
                                                        'prefix' => $defaultCur->prefix,
                                                        'suffix' => $defaultCur->suffix,
                                                        'rate' => $defaultCur->rate
                                                    ));
            $customerCurrency->save();
            $response = [
				'tokenid'   => $tokenid,
				'tokenkey'   => $CustomerSession->custome_token,
				'currenciesAll' => $currencies,
				'customer_currency' => $customerCurrency->value
			];
			return response()->json(array('new' => 1, 'result' => $response));
        }
    }
    
    public function getCurrency(Request $request)
    {
        $currencies = Currency::all();
        $totalCurrencies = Currency::all()->count();
        
        $defaultCurrency = Currency::where('default',1)->first();
        //$SessionSet = Session::get('SessionSet');
        
        if(!Session::has('SessionSet')){
             Session::put('SessionSet', $defaultCurrency);
        }else{
            Session::put('SessionSet', Session::get('SessionSet'));
        }
        Session::save();
        
        //print_r(Session::get('SessionSet'));die;
        $response=[
            'defaultCurrency'   => $defaultCurrency,
            'currencies' => $currencies,
            'totalCurrencies' => $totalCurrencies,
            'SessionSet' => Session::get('SessionSet')
        ];
        //echo $defaultCurrency->default;
        //echo $SessionSet;
        
        //$settt = Session::get('key');
        return response()->json(($response),200);
    }

    function getCurrencyValue(Request $request)
    {
        $currid = $request->input('currid');
        $tokenid = $request->input('tokenid');

        $defaultCur = Currency::find($currid);
        $customerCurrency = json_encode(array(
                                            'id' => $defaultCur->id,
                                            'name' => $defaultCur->name,
                                            'code' => $defaultCur->code,
                                            'prefix' => $defaultCur->prefix,
                                            'suffix' => $defaultCur->suffix,
                                            'rate' => $defaultCur->rate
                                        ));
		$customer_order_id = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_orderid')->first();
        if(isset($customer_order_id->value) && $customer_order_id->value > 0){
			Order::where('id','=',$customer_order_id->value)->update(array('multi_currency_id'=>$defaultCur->id));
		}               
        $response = CustomerSessionData::where('sid','=',$tokenid)->where('name','=','customer_currency')->update(array('value'=>$customerCurrency));
		
        return response()->json($response,200);
    }
   
    public function checkRequest(Request $request){

                $tokenkey    =  $request->tokenkey;
                $tokenid    =  $request->tokenid;
                $sessionId   ='';

                $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->where('id','=',$tokenid)->get();
                
                if(count($sessionData)>0){
                     $sessionId = $sessionData[0]->id;
                     $userExist = CustomerSessionData::where('sid','=',$sessionId)->get();
                     $usessiondata = array();
                        foreach($userExist as $value){
                            $usessiondata[$value->name] = $value->value;
                        }
                      return array('user_session_data'=>$usessiondata,'status'=>'true','statusText'=>'Ok');
                     
                }else{

                    return false;
                }
                
                

    }
    public function getSitemapData(Request $request){

        $tokenkey    =  $request->tokenkey;
        $tokenid    =  $request->tokenid;

        $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->where('id','=',$tokenid)->get();
        
        if(count($sessionData)>0){


          $cat = Category::select('parent_id','id','name')->where('enabled',1)->where('parent_id',1)->with("countSubCategory")->with("clean")->get();
     
           $staticpage = Staticpages::select('id','name')->where('enabled',1)->with("clean")->get();
     
          return response()->json(array('Catalogs' =>$cat,'staticPage' =>$staticpage,'status'=>'true','statusCode'=>200)); 

        }else{

           return response()->json(array('Catalogs' =>'category','staticPages' =>'Static pages','status'=>'false')); 
        }
    }

}