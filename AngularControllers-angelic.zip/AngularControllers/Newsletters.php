<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Subscriber;

class Newsletters extends Controller
{

	 public function storeEmails(Request $request)
    {

    	$data = $request->json()->all();
      	$email = $data['email'];
        $newsletter = new Subscriber;
        $mail = Subscriber::where('email', '=', $email)->first();
        if (isset($mail)) 
        {

    	  return json_encode(array('message' => 'Email already exists','status' => 'already_exists'));
    	
       }else{

	       	$newsletter->first_name = '';
	    	$newsletter->last_name = '';
	    	$newsletter->email = $email;
	    	$newsletter->status = 1;   
	    	$newsletter->save();

	    	if($newsletter){
	    		return json_encode(array('message' => 'Email Save successfully','status' => 'true'));
	    	}else{
	    		return json_encode(array('message' => 'Error in Saving Email','status' => 'false'));
	    	}

    	 }
 }    
}
