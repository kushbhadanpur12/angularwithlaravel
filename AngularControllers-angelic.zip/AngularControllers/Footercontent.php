<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;
class Footercontent extends Controller
{


	public function staticPages(Request $request)
  {
      $url = $request->input('statiValue');
      $data = DB::table('static_pages')->where('slug',$url)->get();

      if (isset($data)) {
			return response()->json($data,201);
      }

     }

	public function aboutus(){

      $data = DB::table('static_pages')->where('slug', 'about-us')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }

     }

     public function Ourshowroom(){

      $data = DB::table('static_pages')->where('slug', 'our-showroom')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function termsandconditions(){

      $data = DB::table('static_pages')->where('slug', 'terms-and-conditions')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function privacyandcookies(){

      $data = DB::table('static_pages')->where('slug', 'privacy-and-cookies')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function educationguide(){

      $data = DB::table('static_pages')->where('slug', 'education-guide')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function luxurypackaging(){

      $data = DB::table('static_pages')->where('slug', 'luxury-packaging')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function ringsizeguide(){

      $data = DB::table('static_pages')->where('slug', 'ring-size-guide')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function ringresizing(){

      $data = DB::table('static_pages')->where('slug', 'ring-resizing')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


     public function diamondsizeguide(){

      $data = DB::table('static_pages')->where('slug', 'diamond-size-guide')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function insurancevaluation(){

      $data = DB::table('static_pages')->where('slug', 'insurance-valuation')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function faqs(){

      $data = DB::table('static_pages')->where('slug', 'faq-s')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function bespokedesign(){

      $data = DB::table('static_pages')->where('slug', 'bespoke-design')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function finance(){

      $data = DB::table('static_pages')->where('slug', 'finance')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function returnspolicy(){

      $data = DB::table('static_pages')->where('slug', 'returns-policy')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

     public function deliveryinformation(){

      $data = DB::table('static_pages')->where('slug', 'delivery-information')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }

      public function pricematchpromise(){

     $data = DB::table('static_pages')->where('slug', 'price-match-promise')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }


      public function warranty(){

      $data = DB::table('static_pages')->where('slug', 'warranty')->get();

      if (isset($data)) {
			return response()->json($data,201);
      }
     }
    
}
