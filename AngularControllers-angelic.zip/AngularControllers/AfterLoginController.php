<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\AuthController;
use Hash;
use App\Customer;
use App\User;
use App\CustAddrBook;
use App\CustomerSessionData;
use App\CustomerSession;
use App\Order;
use App\OrderItem;
use DB;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AfterLoginController extends Controller
{
   
   public function __construct()
   {
       $this->middleware('jwt.auth', ['except' => ['authenticate','registration']]);
   }

    //For Customer address data store
    public function postAddr( Request $request, $id )
    {
        $getData = $request->json()->all();
        $custAddrBook = new CustAddrBook([
            'user_id'  =>  $id,
            'country_id' => $getData['country'],
            'fname' =>      $getData['fname'],
            'lname' =>      $getData['lname'],
            'addr1' =>      $getData['addr1'],
            'addr2' =>      $getData['addr2'],
            'city' =>       $getData['city'],
            'post_code' =>  $getData['post_code'],
            'phone' =>      $getData['phone'],
            'status' =>      0   
        ]);
        $resp = $custAddrBook->save();
        
        $response = [
            'id'    => $id,
           'data' => $resp
        ];

        return response()->json($response,201);
    }

    

    //For Gatting Customer address data
    public function getAddress($user_id)
    {
        $dataAddress='';
        $data = CustAddrBook::where('user_id','=',$user_id)->with('country')->get();
        //$data = DB::table('cust_addr_books')
                       // ->join('countries','cust_addr_books.user_id','=','countries.id')
                      //  ->select('cust_addr_books.*','countries.id as cid','countries.code as ccode')
                     //   ->where('user_id','=',$user_id)->get();
        if($data)
        {
            $dataAddress = $data;
        } else {
            $dataAddress = 'No data';
        }
        //$data = CustAddrBook::find($id)->country;
        $response = [
            'dataAddress' => $dataAddress
        ];

        return response()->json($response,201);
    }

    //For data showing in pop
    public function cust_address($id)
    {
        $dataAddress = DB::table('cust_addr_books')
                        ->join('countries','cust_addr_books.user_id','=','countries.id')
                        ->select('cust_addr_books.*','countries.*')
                        ->where('cust_addr_books.id','=',$id)->get();
        $response = [
            'dataAddress' => $dataAddress
        ];

        return response()->json($response,201);  
        
    }

    

    public function updatecustaddress(Request $request, $id)
    {
        $getData = $request->json()->all();

        $custAddrBook = [
            //'user_id'  =>  $getData['user_id'],
           
            'fname' =>  $getData['fname'],
            'lname' =>  $getData['lname'],
            'addr1' =>  $getData['addr1'],
            'addr2' =>  $getData['addr2'],
            'city' =>  $getData['city'],
            'post_code' =>  $getData['post_code'],
            'phone' =>  $getData['phone'],
            'country_id' =>  $getData['country'],
            'status' =>  0 
        ];
        $custAddrBook = CustAddrBook::where('id',$id)->update($custAddrBook);
       $response = [
            'dataAddress' => $custAddrBook
        ];
        return response()->json($response,201); 
    }


    //For Update Customer password
    public function updateProfile(Request $request, $id)
    {
        $getData = $request->json()->all();
		$token   =  $request->token;
        $data = array(
            'email' => $getData['email'],
            'password' => Hash::make($getData['password'])      
        );

	
		$validuserData = JWTAuth::toUser($token)
		if($validuserData){
			$customer = User::where('id',$id)->update($data);
			$response = [
				'id'    => $id,
			   'data' => $customer
			];

          return response()->json($response,201);
		}else{
		
		 return response()->json('msg'=>'Error','statusCode'=>401);
		
		}
    }
	


    public function addressDelete($id)
    {
        $delete = CustAddrBook::where('id',$id)->delete();
        $response = [
            'delete'    => $delete,
            'message'   =>'Record Deleted Successfully!'
        ];

        return response()->json($response,201);
    }

    //////For Order Data

    public function orderData($profile_id)
    {
        //$order = Order::where('profile_id','=',$profile_id)->with('orderItem')->get();
        $count = Order::where('orig_profile_id','=',$profile_id)->count();
        $order = Order::where('orig_profile_id','=',$profile_id)->with(['orderItem','paymentStatus','shippingStatus','orderMultiCurrency'])->get();
        $response = [
            'count'    => $count,
            'orders'   =>$order,
           // 'item'  => $item
        ];
        return response()->json($response,201);
    }
	
	public function getCustomerOrderDetails(Request $request){
		$token           =  $request->token;
		$id                 =  $request->orderId;
		
		
		if(!$validuserData = JWTAuth::toUser($token)){
			return response()->json(array('msg'=>'Token does not match','statusText'=>'Error'));
		}else{
			$validuserData = JWTAuth::toUser($token);
			$OD = Order::where('orig_profile_id',$validuserData->id)->where('orderNumber','=',$id)->first();
			
			if($OD){
				$order = Order::where('id','=',$OD->id)->with(["orderProfile", 'paymentStatus', 'shippingStatus', "orderBillingDetails", "orderShippingDetails", "orderDefaultCurrency", "orderMultiCurrency",  "orderInvoiceItemDetails"])->first();
				return response()->json(array('order'=>$order, 'statusText'=>'Success'));
			}else{
				return response()->json(array('msg'=>'Token does not match', 'statusText'=>'Error'));
			}
		}
	}

    public function orderDetailsData($id)
    {
        $data = Order::find($id)->with('paymentStatus')->with('customerAddr')->get();
        $response = [
            'data'  => $data
        ];
        return response()->json($response,201);
    }


    public function update_session_data_table(Request $request){

		$userId    = $request->userId;
		$data['tokenid'] = $tokenid   = $request->tokenid;
		$data['tokenkey'] = $tokenkey  = $request->tokenkey;
		
		$customer = CustomerSession::where('id','=',$tokenid)->where('custome_token','=',$tokenkey)->get();
		
		if(count($customer)>0){
		
			CustomerSessionData::where('sid','=',$tokenid)->where('name','=','login_user_id')->delete();
		
			$cust = new CustomerSessionData;
			$cust->sid = $tokenid;
			$cust->name = 'login_user_id';
			$cust->value = $userId;
			$cust->save();
			$id = $userId;
			
			$Sdata = CustomerSession::where('id','=',$data['tokenid'])->where('custome_token','=',$data['tokenkey'])->first();
			if($Sdata){
			
				$order = Order::where('orig_profile_id','=',$id)->where('is_order','=',0)->where('not_finished_order_id','=',0)->first();
				
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$data['tokenid'])->first();
				$customer_currency = CustomerSessionData::where('name','=','customer_currency')->where('sid','=',$data['tokenid'])->first();
				$multicurr = json_decode($customer_currency['value']);
				
				if($customer_orderid){
					
					if($order){
						/*$billing_addr_id = CustomerSessionData::where('name','=','billing_addr_id')->where('sid','=',$data['tokenid'])->first();
						if($billing_addr_id){
							
						}else{
							
						}
						$shipping_addr_id = CustomerSessionData::where('name','=','shipping_addr_id')->where('sid','=',$data['tokenid'])->first();*/
						
						OrderItem::where('order_id','=',$customer_orderid->value)->update(['order_id'=>$order->id]);
						
						Order::where('id',$order->id)->update(['multi_currency_id'=>$multicurr->id]);
						CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$data['tokenid'])->update(['value'=>$order->id]);
						
						$totalOrderValue = OrderItem::where('order_id','=',$order->id)->sum('total');
						Order::where('id',$order->id)->update(array('total'=>$totalOrderValue,'subtotal'=>(($totalOrderValue*5)/6),));
		
						Order::where('id','=',$customer_orderid->value)->delete();
						
					}else{
						Order::where('id','=',$customer_orderid->value)->update(['orig_profile_id'=>$id]);
					}
				}else{
					if($order){
						Order::where('id',$order->id)->update(['multi_currency_id'=>$multicurr->id]);
						CustomerSessionData::insert(['name'=>'customer_orderid','sid'=>$data['tokenid'],'value'=>$order->id]);
					}
				}
			}
			
			return response()->json(['user'=>$cust,'status'=>'true'],201);
		 
		
		}
		return response()->json(['user'=>'token not available','status'=>'true'],201);
    }
	
	
		public function checkUser_islogedin(Request $request){
		$token           =  $request->token;
	
		if(!$validuserData = JWTAuth::toUser($token)){
			return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','statusCode'=>400));
		}else{
			$validuserData = JWTAuth::toUser($token);
			return response()->json(array('data'=>$validuserData,'statusCode'=>200,'statusText'=>'success'));
			
		  }
	}
}
