<?php

namespace App\Http\Controllers\AngularControllers;

use App\Http\Controllers\Controller;
use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use App\Customer;
use Illuminate\Support\Facades\Input;
use Hash;
use JWTAuth;
use App\CustAddrBook;
use App\Country;
use App\User;
use App\GlobalSetting;

class OperateCustomer extends Controller
{

	//-------- Operate as user ---------//
	public function operateAsThisUser(Request $request)
    {
		$key = $request->input('key');
		$cid = $request->input('cid');
		$user = User::find($cid);
		$opass = Hash::check($key, $user->operate_as_password);
		if($opass){
			$userToken = JWTAuth::fromUser($user);
			return response()->json([
					'access_token' => $userToken,
				]);
		}else{
			return array('status'=>$status, 'opus'=>$opus, 'randnum'=>$randnum, 'site_url'=>$site_url->value);
		}
    }
	
	public function operateCustomerQuit(Request $request)
    {
		$loginuserid = $request->loginuserid;
		$user = User::where('id',$loginuserid)->update(["operate_as_password"=>NULL]);
		return array('status'=>true, 'operate_as_password'=>'quit');
    }
}
