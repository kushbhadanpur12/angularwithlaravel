<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Contactu;
use App\CustomerSession;
use App\CustomerSessionData;
use App\User;
use App\GlobalSetting;

use App\Http\Controllers\AdatleyControllers\SmtpController;
use App\Http\Controllers\AdatleyControllers\EmailNotificationController;

class ContactUsController extends Controller
{
    public function store(Request $request)
    {

        $data = $request->json()->all();
        $contact = new Contactu;
        $contact->name = $data['name'];
        $contact->email = $data['email'];
        $contact->subject = $data['subject'];
        $contact->message = $data['message'];

        $data2 = $contact->save();

        if(isset($data2)){

      $emailNotice  = new EmailNotificationController;

    /// $aaa = $emailNotice->sendContactusEmails('contactus',$contact);

      return response()->json(['contactus'=>$contact,'status'=>'true'],201);
        }else{
            return response()->json(['contactus'=>$contact,'status'=>'false'],201);
        }
    
    }

    function rand_string( $length ) {
       $chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz@*";  
       $size = strlen( $chars );
       $str='';
       for( $i = 0; $i < $length; $i++ ) {
              $str .= $chars[ rand( 0, $size - 1 ) ];
        }
         return $str;
   }



    public function sendmailforresetPassword(Request $request)
    {
         $tokenkey      =  $request->tokenkey;
         $tokenid       =  $request->tokenid;
         $receiver_mail =   $request->email; 

        $site_name = GlobalSetting::where('name','=','site_url')->first();
    
         $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->where('id','=',$tokenid)->get();
         if(count($sessionData)>0){
               $userExist = CustomerSessionData::where('sid','=',$sessionData[0]->id)->get();
                if($userExist){
                      $emailExist = User::where('email',$receiver_mail)->where('password','!=','')->where('password','!=','null')->get();
                     if(count($emailExist)>0){
                             $passToken = $this->rand_string(128); 
                              $reSetPasswordTime =  time();
                              foreach ($emailExist as $value) {
                                $a =  User::where('id',$value->id)->update(["reSetPasswordToken"=>$passToken,"reSetPasswordTime"=>$reSetPasswordTime]);
                              }
                                   $tkn = $site_name->value.'/recover_password?emailid='.$receiver_mail.'&attempt=1&token='.$passToken;
                                   $data123 = array("receiver"=>$receiver_mail,"token"=>$tkn );
                                   $mailToken =   new EmailNotificationController;
                                   $mailToken->sendChangedPassword('change_password',$data123);
                                    return response()->json(['status'=>'true','msg'=>'The confirmation URL link was sent to '.$receiver_mail,'statusCode'=>200]);
                                 
                           }else{
                       return response()->json(['status'=>'false','msg'=>'Error: There is no user with the specified email address','statusCode'=>404]);
                     }
            
                  }else{
                     return response()->json(['status'=>'false'],201);
                  }
        }else{
          return response()->json(['status'=>'false','msg'=>'unauthorized user'],201);
        }
    }

    public function getUserInfo(Request $request)
    {
        $tokenid   = $request->tokenid;
        $tokenkey  = $request->tokenkey;
        $sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();

    if($sessionData){
       $login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=', $sessionData->id)->first();

       if($login_user_id){
         $user =  User::find($login_user_id)->first();
         return response()->json(['email'=>$user->email,'name'=>$user->fname.' '.$user->lname,'status'=>'true','statusCode'=>200]);
       }else{

        return response()->json(['email'=>'','name'=>'','status'=>'true','statusCode'=>202]);

       }
      }else{

         return response()->json(['msg'=>'Token mismatch Error','status'=>'error'],400);
      }
    }
}
