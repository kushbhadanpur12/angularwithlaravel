<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\AngularControllers\CommonController;
use DB;
use App\Customer;
use App\User;
use App\Http\Controllers\AngularControllers\CartController;
use App\Order;
use App\OrderItem;
use App\Order_transaction;
use App\PaymentMethod;
use App\PaymentMethodsSetting;
use App\Payment;
use App\Vat;
use App\Shipping;
use App\CustAddrBook;
use App\Country;
use App\AbandonedCart;
use App\CustomerSession;
use App\CustomerSessionData;
use App\Product;
use App\ProductAttribute;
use App\ProductVariants;
use App\Subscriber;
use Hash;
use App\AttributesOptionModel;
use App\Http\Controllers\AdatleyControllers\PaymentMethodController;
use App\Http\Controllers\AdatleyControllers\OrderHistoryController;

class CheckoutController extends Controller
{

	 public function getCountryList(){
    	return $country = Country::all();
     }
	 
     public function get_payment_methods(Request $request){
	 
	 	$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		$sessionId = $sessionData->id;
		$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
		
		$orderDetails = Order::find($customer_orderid->value);

		$pm = PaymentMethod::where('status',1)->with(["PaymentMethodDetails"])->get();
		$payment_method = array();
		$defaultpaymmethod = PaymentMethod::select("id")->where('status',1)->first()->id;
		
		foreach($pm as $payment){
			if($payment->id==$orderDetails->payment_method_id){
				$defaultpaymmethod = $payment->id;
			}
			
			if($payment->processor_name=='deko'){
				foreach($payment->PaymentMethodDetails as $key=>$val){
					if($val->name=='min_total' && $orderDetails->total >= floatval($val->value)){
						$payment_method[] = $payment;
					}
				}
			}else{
				$payment_method[] = $payment;
			}
			
			/*$payment_method[$payment->id]['details']['id'] = $payment->id;
			$payment_method[$payment->id]['details']['processor_name'] = $payment->processor_name;
			$payment_method[$payment->id]['details']['name'] = $payment->name;
			$payment_method[$payment->id]['details']['instructions'] = $payment->instructions;
			$payment_method[$payment->id]['details']['detail'] = $payment->detail;
			$payment_method[$payment->id]['details']['payment_logo'] = $payment->payment_logo;
			
			if($payment->PaymentMethodDetails){
				$settings = array();
				foreach($payment->PaymentMethodDetails as $val){
					$settings[$val->name] = $val->value;
				}
				$payment_method[$payment->id]['details']['settings'] = $settings;
			}*/
		}
		
		return response()->json(array('payment_method'=>($payment_method),'defaultpaymmethod'=>$defaultpaymmethod,'status'=>'true','statusText'=>'success'));

     }
	 
	 public function getSelectedPaymentMethodDetils(Request $request){
		$payment = PaymentMethod::find($request->paymentid);
		$payment_detail = array();
		$pd = PaymentMethodsSetting::where('payment_methods_id',$request->paymentid)->get();
		
		$deko = new PaymentMethodController;
		$dekop = $deko->globalDeko;
		foreach($pd as $val){
			if(@unserialize($val->value) !== false){
				$payment_detail[$val->name] = unserialize($val->value);
			}else{
				$payment_detail[$val->name] = $val->value;
			}
		}
		//print_r($dekop);die;
		return array('deko'=>$dekop, 'payment'=>$payment, 'payment_detail'=>$payment_detail, 'status'=>'true', 'statusText'=>'success');
	 }
	 
	 public function updatePaymentMethods(Request $request){
	 
	 	$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		$payment_id    =  $request->payment_id;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		$sessionId = $sessionData->id;
		if($sessionId){
			$payment_method = PaymentMethod::find($payment_id);
			$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
			$orderDetails = Order::find($customer_orderid->value);
			$orderDetails->payment_method_id = $payment_method->id;
			$orderDetails->payment_method_name = $payment_method->name;
			$orderDetails->save();
			return response()->json(array('status'=>'true','statusText'=>'success'));
		}else{
			return response()->json(array('status'=>'false','statusText'=>'error'));
		}

     }

     public function get_shipping_methods(Request $request){
	 	$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		$sessionId = $sessionData->id;
		$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
		$orderDetails = Order::find($customer_orderid->value);

		if($orderDetails->same_as_billing==1 || $orderDetails->same_as_billing==3){
			$cusaddrid = $orderDetails->billing_addr_id;
		}else{
			$cusaddrid = $orderDetails->shipping_addr_id;
		}
		$cusaddr = CustAddrBook::find($cusaddrid);
    	$sm = Shipping::where('status',1)->whereRaw('FIND_IN_SET('.$cusaddr->country_id.',countries)')->get();
		$shipping_method = array();
		
    	foreach($sm as $shipping){
			if($shipping->id==$orderDetails->shipping_id){
				$defaultshipid = $shipping->id;
			}
			$shipping_method[] = $shipping;
		}
		if(empty($defaultshipid)){
			$dsm = Shipping::where('status',1)->whereRaw('FIND_IN_SET('.$cusaddr->country_id.',countries)')->first();
			$orderDetails->shipping_id = $dsm->id;
			$orderDetails->shipping_method_name = $dsm->name;
			$orderDetails->shipping_cost = $dsm->delivery_cost;
			$orderDetails->save();
			$defaultshipid = $dsm->id;
		}
		
		CartController::recalculateOrderTotal($customer_orderid->value);
    	return response()->json(array('shipping_method'=>$shipping_method, 'defaultshipid'=>$defaultshipid, 'status'=>'true','statusText'=>'success'));

     }

	public function addAddressBook($user_id,$new_entry,$default_shipping,$default_billing,$country_id,$fname,$lname,$addr1,$addr2,$city,$post_code,$status,$phone){
		$addr = new CustAddrBook;
		$addr->new_entry = $new_entry;
		$addr->user_id = $user_id;
		$addr->default_shipping = $default_shipping;
		$addr->default_billing = $default_billing;
		$addr->country_id = $country_id;
		$addr->fname = $fname;
		$addr->lname = $lname;
		$addr->addr1 = $addr1;
		$addr->addr2 = $addr2;
		$addr->city = $city;
		$addr->post_code = $post_code;
		$addr->status = $status;
		$addr->phone = $phone;
		$addr->save();
		return $addr;
	}
	
	public function updateAddressBook($addr_id,$country_id,$fname,$lname,$addr1,$addr2,$city,$post_code,$phone){
		$addr = CustAddrBook::find($addr_id);
		$addr->country_id = $country_id;
		$addr->fname = $fname;
		$addr->lname = $lname;
		$addr->addr1 = $addr1;
		$addr->addr2 = $addr2;
		$addr->city = $city;
		$addr->post_code = $post_code;
		$addr->phone = $phone;
		$addr->save();
		return $addr;
	}

    public function updateBillingshipping(Request $request){
		
		$tokenid			=  $request->input('tokenid');
		$tokenkey    	=  $request->input('tokenkey');
		$sameaddr        =  $request->input('sameasbilling');
		
		$billing_addr_idh      =   $request->billing_addr_idh;
		$bill_fname      =   $request->input('bill_fname');
		$bill_lname      =   $request->input('bill_lname');
		$bill_addr1      =   $request->input('bill_addr1');
		$bill_addr2      =   $request->input('bill_addr2');
		$bill_city       =   $request->input('bill_city');
		$bill_postcode   =   $request->input('bill_postcode');
		$bill_countrycode=   $request->input('bill_countrycode');
		$bill_phone      =   $request->input('bill_phone');
		$bill_email      =   $request->input('bill_email');
		$bill_password   =   $request->input('bill_password');
		
		$shipping_addr_idh      =   $request->input('shipping_addr_idh');
		$ship_fname      =   $request->input('ship_fname');
		$ship_lname      =   $request->input('ship_lname');
		$ship_addr1      =   $request->input('ship_addr1');
		$ship_addr2      =   $request->input('ship_addr2');
		$ship_city       =   $request->input('ship_city');
		$ship_postcode   =   $request->input('ship_postcode');
		if($request->input('ship_countrycode'))
			$ship_countrycode=   $request->input('ship_countrycode');
		else
			$ship_countrycode=   $request->input('bill_countrycode');
		$ship_phone      =   $request->input('ship_phone');
		
		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		if($sessionData){
			$sessionId = $sessionData->id;
			$shipping = $billing = $useremail = null;
			if($sessionId){
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
				$orderDetails = Order::find($customer_orderid->value);
				
				if($login_user_id){
					$userinfo = User::find($orderDetails->orig_profile_id);
					
					if($orderDetails->orig_profile_id==$orderDetails->profile_id){
						if($userinfo->email!=$bill_email){
							
							$newuser = new User;
							$newuser->orig_profile_id = $orderDetails->orig_profile_id;
							$newuser->type = 3;
							$newuser->email = $bill_email;
							$newuser->fname = $bill_fname;
							$newuser->lname = $bill_lname;
							$newuser->status = 1;
							$newuser->not_anonymous = 1;
							$newuser->save();
							
							$orderDetails->profile_id = $newuser->id;
							$orderDetails->save();
						}else{
							
						}
					}else{
						$profile_id = User::find($orderDetails->profile_id);
						$profile_id->email = $bill_email;
						$profile_id->fname = $bill_fname;
						$profile_id->lname = $bill_lname;
						$profile_id->save();

						$orig_profile_id = User::find($orderDetails->orig_profile_id);
						$orig_profile_id->fname = $bill_fname;
						$orig_profile_id->lname = $bill_lname;
						$orig_profile_id->save();
					}
					
					if($billing_addr_idh){
						$billaddr = CustAddrBook::find($billing_addr_idh);
						if($billaddr->new_entry==1){
							$billaddr = $this->updateAddressBook($billaddr->id,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,$bill_phone);
						}else{
							$billaddrmatch = CustAddrBook::where('user_id',$orderDetails->orig_profile_id)->where('country_id',$bill_countrycode)->where('fname',$bill_fname)->where('lname',$bill_lname)->where('addr1',$bill_addr1)->where('addr2',$bill_addr2)->where('city',$bill_city)->where('post_code',$bill_postcode)->where('phone',$bill_phone)->first();
							
							if($billaddrmatch && $billaddrmatch->id==$billing_addr_idh){
								$billaddr = $billaddrmatch;
							}else{
								
								$billaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,0,1,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
							}
						}
					}else{
						$billaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,0,1,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
					}
					
					
					if($shipping_addr_idh){
						$shipaddr = CustAddrBook::find($shipping_addr_idh);
						
						if($shipaddr->new_entry==1){
								$shipaddr = $this->updateAddressBook($shipaddr->id,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,$ship_phone);
						}else{
							if($sameaddr==1){
								$shipaddrmatch = CustAddrBook::where('user_id',$orderDetails->orig_profile_id)->where('country_id',$bill_countrycode)->where('fname',$bill_fname)->where('lname',$bill_lname)->where('addr1',$bill_addr1)->where('addr2',$bill_addr2)->where('city',$bill_city)->where('post_code',$bill_postcode)->where('phone',$bill_phone)->first();
								$shipaddr = $shipaddrmatch;
							}else{
								$shipaddrmatch = CustAddrBook::where('user_id',$orderDetails->orig_profile_id)->where('country_id',$ship_countrycode)->where('fname',$ship_fname)->where('lname',$ship_lname)->where('addr1',$ship_addr1)->where('addr2',$ship_addr2)->where('city',$ship_city)->where('post_code',$ship_postcode)->where('phone',$ship_phone)->first();
								if($shipaddrmatch && $shipaddrmatch->id==$shipping_addr_idh){
									$shipaddr = $shipaddrmatch;
								}else{
									if($sameaddr==1){
										$shipaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,1,0,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
									}else{
										$shipaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,1,0,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,1,$ship_phone);
									}
								}
							}
							
						}
					}else{
						if($sameaddr==1){
							if($billing_addr_idh){
								$shipaddr = $billaddr;
							}else{
								$shipaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,1,0,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
							}
						}else{
							$shipaddr = $this->addAddressBook($orderDetails->orig_profile_id,1,1,0,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,1,$ship_phone);
						}
					}
					
					CustAddrBook::where('user_id',$orderDetails->orig_profile_id)->update(["default_billing"=>0, "default_shipping"=>0]);
					CustAddrBook::where('id',$billaddr->id)->update(["default_billing"=>1]);
					CustAddrBook::where('id',$shipaddr->id)->update(["default_shipping"=>1]);
					
					$orderDetails->billing_addr_id = $billaddr->id;
					$orderDetails->shipping_addr_id = $shipaddr->id;
					$orderDetails->same_as_billing = $sameaddr;
					$orderDetails->save();
					$useremail = User::find($orderDetails->profile_id);
				}else{
					
					if($user_id){
						$profile_id = User::find($orderDetails->profile_id);
						$profile_id->email = $bill_email;
						$profile_id->fname = $bill_fname;
						$profile_id->lname = $bill_lname;
						$profile_id->save();
						
						if($orderDetails->billing_addr_id > 0){
							$billaddr = $this->updateAddressBook($orderDetails->billing_addr_id,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,$bill_phone);
							
							if($orderDetails->shipping_addr_id > 0){
								if($sameaddr==1){
									$shipaddr = $this->updateAddressBook($orderDetails->shipping_addr_id,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,$bill_phone);
								}else{
									$shipaddr = $this->updateAddressBook($orderDetails->shipping_addr_id,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,$ship_phone);
								}
							}else{
								if($sameaddr==1){
									$shipaddr = $this->addAddressBook($profile_id->id,1,1,0,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
								}else{
									$shipaddr = $this->addAddressBook($profile_id->id,1,1,0,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,1,$ship_phone);
								}
							}
						}else{
							$billaddr = $this->addAddressBook($profile_id->id,1,0,1,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
							
							if($orderDetails->shipping_addr_id > 0){
								if($sameaddr==1){
									$shipaddr = $this->updateAddressBook($orderDetails->shipping_addr_id,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,$bill_phone);
								}else{
									$shipaddr = $this->updateAddressBook($orderDetails->shipping_addr_id,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,$ship_phone);
								}
							}else{
								if($sameaddr==1){
									$shipaddr = $this->addAddressBook($profile_id->id,1,1,0,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
								}else{
									$shipaddr = $this->addAddressBook($profile_id->id,1,1,0,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,1,$ship_phone);
								}
							}
							
						}
						
						$orderDetails->same_as_billing = $sameaddr;
						$orderDetails->save();
						$useremail = User::find($user_id);
					}else{
						$newuser = new User;
						$newuser->orig_profile_id = 0;
						$newuser->type = 3;
						$newuser->email = $bill_email;
						$newuser->fname = $bill_fname;
						$newuser->lname = $bill_lname;
						$newuser->status = 1;
						$newuser->not_anonymous = 0;
						$newuser->save();
						
						$user_id = new CustomerSessionData;
						$user_id->sid = $sessionId;
						$user_id->name = 'user_id';
						$user_id->value = $newuser->id;
						$user_id->save();
						
						$orderDetails->profile_id = $newuser->id;
						$orderDetails->save();
						
						$billaddr = $this->addAddressBook($newuser->id,1,0,1,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
						
						if($ship_countrycode && $ship_fname && $ship_lname && $ship_addr1 && $ship_addr2 && $ship_city && $ship_postcode && 1 && $ship_phone){
							if($sameaddr==1){
								$shipaddr = $this->addAddressBook($newuser->id,1,1,0,$bill_countrycode,$bill_fname,$bill_lname,$bill_addr1,$bill_addr2,$bill_city,$bill_postcode,1,$bill_phone);
							}else{
								$shipaddr = $this->addAddressBook($newuser->id,1,1,0,$ship_countrycode,$ship_fname,$ship_lname,$ship_addr1,$ship_addr2,$ship_city,$ship_postcode,1,$ship_phone);
							}
						}else{
							$shipaddr = false;
						}
						$orderDetails->billing_addr_id = $billaddr->id;
						if($shipaddr)
							$orderDetails->shipping_addr_id = $shipaddr->id;
						$orderDetails->same_as_billing = $sameaddr;
						$orderDetails->save();
						
					}
				}

				$orderDetails = Order::find($customer_orderid->value);
				$orderDetails->shipping_status_id = 7;
				$orderDetails->save();
				
				if($orderDetails->shipping_addr_id>0){
					$shipping = CustAddrBook::find($orderDetails->shipping_addr_id);
				}
				if($orderDetails->billing_addr_id>0){
					$billing =  CustAddrBook::find($orderDetails->billing_addr_id);
				}
				
				return response()->json(array('shipping'=>$shipping,'billing'=>$billing,'useremail'=>$useremail,'orderDetails'=>$orderDetails,'status'=>'true','statusText'=>'Ok'));
			}
		}
		
    }

   public function check_user_email( Request $request){

			$tokenkey    =  $request->tokenkey;
			$email       =  $request->email;
			$sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->first();

			if($sessionData){
				 $sessionId = $sessionData->id;
			}
			
			$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
			$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
			$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
			
			$OrderDetails = Order::find($customer_orderid->value);
			
			if(filter_var($email, FILTER_VALIDATE_EMAIL)){
				if($login_user_id){
					$nopass = 0;
					$signin = 0;
				}else{
					$finduser = User::where('email',$email)->where('password','!=','')->first();
					if($finduser){
						$nopass = 0;
						$signin = 1;
					}else{
						$nopass = 1;
						$signin = 0;
					}
				}
				$validemail = 1;
			}else{
				$nopass = 0;
				$signin = 0;
				$validemail = 0;
			}
			
			return response()->json(array('validemail'=>$validemail, 'signin'=>$signin, 'nopass'=>$nopass));
	   }

      public function update_order_notes( Request $request){

      		    $tokenkey   =  $request->tokenkey;
				$note       =  $request->note;

			    $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->get();
				
	    	   	if(count($sessionData)>0){

	    	   		 $sessionDataExist = CustomerSessionData::where('name','=','customer_orderid')
   	   							->where('sid','=',$sessionData[0]['id'])
   	   							->get();
	    	   	       if(count($sessionDataExist)>0){
					        $orderId =  $sessionDataExist[0]->value;
	    	   		        $data = Order::where('id','=',$orderId)->update(['notes' => $note]);
         		           return response()->json(array('status'=>'true','statusText'=>'success'));
         		       }
         		         return response()->json(array('status'=>'false','statusText'=>'Error'));

	    	   	}else{

	    	   		  return response()->json(array('status'=>'false','statusText'=>'Error'));
	    	      	}

      } 

      public function check_order_notes( Request $request){

      		    $tokenkey   =  $request->tokenkey;
  	            $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->get();
				
	    	   	if(count($sessionData)>0){

	    	   		 $sessionDataExist = CustomerSessionData::where('name','=','customer_orderid')
   	   							->where('sid','=',$sessionData[0]['id'])
   	   							->get();
	    	   	       if(count($sessionDataExist)>0){
					        $orderId =  $sessionDataExist[0]->value;
                     
	    	   	   $data = Order::select("notes")->where('id','=',$orderId)->get();
         		              
         		 return response()->json(array('notes'=>$data,'status'=>'true','statusText'=>'success'));
}
	    	   	}else{
	    	   		 $sessionId ='';
	    	   		 return response()->json(array('status'=>'false','statusText'=>'error','notes'=>'',));
	    	   	}

      }

     public function customer_shipping_methods(Request $request){

     	 $tokenkey                =  $request->tokenkey;
     	 $shipping_id             =  $request->shipping_id;
     	 $shipping_method_name    =  $request->shipping_method_name;
		 $ShippingDetails = Shipping::find($shipping_id);
		 
     	 $sessionId = '';
     	 $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->get();
				
	    	   	if(count($sessionData)>0){
                     $sessionId = $sessionData[0]->id;
	    	   	}

	    	   	if($sessionId!=''){
	    	   		 $customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->get();
					 
						if(count($customer_orderid)>0){
				 			$orderid = $customer_orderid[0]->value;
		             
							$data = Order::where('id','=',$orderid)->update(['shipping_id' => $shipping_id, 'shipping_method_name' => $ShippingDetails->name, 'shipping_cost' => $ShippingDetails->delivery_cost]);
							
							CartController::recalculateOrderTotal($orderid);
         		      		return response()->json(array('status'=>'true','statusText'=>'success'));
						}
	    	   	}else{

	    	   		 return response()->json(array('status'=>'false','statusText'=>'error'));
	    	   	}
	    	    

     }
     
	public function getConfirmOrderDetails(Request $request){
		$tokenid           =  $request->tokenid;
		$tokenkey           =  $request->tokenkey;
		$id                 =  $request->orderId;
		
		$custmer_exist = CustomerSession::where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		
		$OD = Order::where('orderNumber','=',$id)->first();
		
		if($custmer_exist){
			/*$custmerOrder = CustomerSessionData::where('sid',$custmer_exist->id)->where('name','customer_orderid')->first();
			if($custmerOrder){
				$custmerOrder->delete();
			}*/
			$orderNumber = CustomerSessionData::where('sid',$tokenid)->where('name','confirm_order_number')->first();
		
			if($orderNumber->value == $id ){
			$order = Order::where('id','=',$OD->id)->with(["orderProfileData", "orderBillingDetails", "orderShippingDetails", "orderDefaultCurrency", "orderMultiCurrency",  "orderInvoiceItemDetails"])->first();
			
			  return response()->json(array('order'=>$order,'statusText'=>'success','statusCode'=>200));
			
			}else{
				return response()->json(array('msg'=>'Invalid Order','statusText'=>'Error','statusCode'=>404));
			}
		}else{
			return response()->json(array('msg'=>'Token does not match','statusText'=>'Error','statusCode'=>400));
		}
	}
	
	
	
	

    public function getOrderItem_finalPayment(Request $req){

       $tokenid  = $req->tokenid;
       $tokenkey = $req->tokenkey;

       $custmer_exist = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		 if($custmer_exist){
			 $custmerOrder = CustomerSessionData::select('value')->where('sid',$custmer_exist->id)->where('name','customer_orderid')->first();

                 $orderId =  $custmerOrder->value;

			 if($orderId){

	 	        $product =  OrderItem::where("order_id","=",$orderId)->with('product_variant')->with('variant_option')->with('clean_url')->with('productImg')->get();
	 	        foreach($product as $key=>$product_variant){
               $opt = AttributesOptionModel::with('attributeByOption')->whereIn('attributes_options.id',explode(",",$product_variant->product_variant->variant_com_opt_ids))->get();
    
     $product[$key]['attr_options'] = $opt;
    }
		 	 return response()->json(array('products'=>$product,'status'=>'true','statusText'=>'success'));	
			 		
			 }else{
			    return response()->json(array('status'=>'order not placed'));
			 }

			 }else{
				return response()->json(array('status'=>'customer does not exist'));
			 }

	}

   public function get_customer_address(Request $request){
   
                $tokenid     = $request->tokenid;
				$tokenkey    =  $request->tokenkey;
  	            $sessionData = CustomerSession::select("id")->where('id','=',$tokenid)->where('custome_token','=',$tokenkey)->get();
				
	    	   	if(count($sessionData)>0){
				
					$sessionId = $sessionData[0]->id;
					$customer_orderId = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
					if(count($customer_orderId)>0){
						$userbilling = null;
						$orderId =  $customer_orderId->value;
						$orderData = 	Order::find($orderId);
	
						$userbilling  =  CustAddrBook::where('id',$orderData->billing_addr_id)->with("country")->with("PayPalCheckout")->get();
						foreach($userbilling as $val)
						{
						    $email = $val->PayPalCheckout->email;
						}
			             return response()->json(array('userbilling'=>$userbilling,'email'=>$email,'status'=>'true','statusText'=>'success'));
					 }
				 
			  	}else{
						return response()->json(array('msg'=>'Token does not match','statusText'=>'Error'));
				     }
}


   public function get_CustomerDataWithoutLogin(Request $request){

   	            $tokenkey    =  $request->tokenkey;
				$tokenid    =  $request->tokenid;
				
                $userbilling = $usershiping = null;
  	            $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->where('id','=',$tokenid)->get();
				
	    	   	if(count($sessionData)>0){
				
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionData[0]->id)->first();
				$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionData[0]->id)->first();
                   
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionData[0]->id)->first();
				$orderDetails = Order::find($customer_orderid->value);
				
				$userbilling  =  CustAddrBook::find($orderDetails->billing_addr_id);
				$usershiping =  CustAddrBook::find($orderDetails->shipping_addr_id);
				
				if($login_user_id){
					 $userdata = User::find($login_user_id->value);
					 return response()->json(array('userbilling'=>$userbilling,'usershiping'=>$usershiping,'emailID'=>$userdata->email,'status'=>'true'));
				}else{
					$userdata = User::find($user_id->value);
					return response()->json(array('userbilling'=>$userbilling,'usershiping'=>$usershiping,'emailID'=>$userdata->email,'status'=>'true'));
				}
	    	   
		}else{
		
			return response()->json(array('msg'=>'Token does not match','statusText'=>'Error'));
		}
   
   }

   public function storeTransactionNumberInOrdertbl(Request $request){

   	        $orderId =  $request->orderId;
   	        $uniqueId =  $request->uniqueId;

   	         $data = Order::where('id','=',$orderId)
         		   ->update([
         		   				'angelic_transaction_number' => $uniqueId,
         		   			]);
           if($data)
           		{
             		return response()->json(array('status'=>'true','statusText'=>'Ok','orderId'=>$orderId));
                }
           else{
					return response()->json(array('status'=>'false','statusText'=>'Error','orderId'=>$orderId));
               }
   }

      public function getcustomerorderid(Request $request) {

   	            $tokenkey    =  $request->tokenkey;
				$tokenid    =  $request->tokenid;
                $sessionId   ='';
  	            $sessionData = CustomerSession::select("id")->where('custome_token','=',$tokenkey)->where('id','=',$tokenid)->get();
				
	    	   	if(count($sessionData)>0){
                     $sessionId = $sessionData[0]->id;
	    	   	}
				
				 $sessionDataExist = CustomerSessionData::where('name','=','customer_orderid')
   	   							->where('sid','=',$sessionId)
   	   							->get();
								
	    	   	if(count($sessionDataExist)>0){
				    return response()->json(array('orderid'=>$sessionDataExist[0]->value,'status'=>'true','statusText'=>'Ok'));
                 }else{

                 	 return response()->json(array('orderid'=>'','status'=>'false','statusText'=>'Error','orderid'=>''));
                 }

   }

	public function getcustomeraddr(Request $request) {
		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		if($sessionData){
			$sessionId = $sessionData->id;
			if($sessionId){
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				if($login_user_id){
					$addr =  CustAddrBook::where('user_id',$login_user_id->value)->get();
					if(count($addr)>0){
						return response()->json(array('data'=>$addr,'status'=>'true','statusText'=>'Ok'));
					}else{
						return response()->json(array('data'=>'','status'=>'false','statusText'=>'Error'));
					}
				}else{
					return response()->json(array('data'=>'','status'=>'false','statusText'=>'Error'));
				}
			}
		}
	}


	public function get_billing_shipping_addr(Request $request){
	
		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		if($sessionData){
			$allAddress = $shipping = $billing = $useremail =  null;
			
			$sessionId = $sessionData->id;
			if($sessionId){
			
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$orderDetails = Order::find($customer_orderid->value);
				
				if($login_user_id){
					if($orderDetails->orig_profile_id==0 || $orderDetails->orig_profile_id==''){
						Order::where('id','=',$orderDetails->id)->update(['profile_id'=>$login_user_id->value,'orig_profile_id'=>$login_user_id->value]);
					}
					$shipping = CustAddrBook::where('user_id',$login_user_id->value)->where('default_shipping',1)->first();
					$billing =  CustAddrBook::where('user_id',$login_user_id->value)->where('default_billing',1)->first();
					
					if($billing){
						Order::where('id','=',$customer_orderid->value)->update(['billing_addr_id'=>$billing->id]);
					}
					if($shipping){
						Order::where('id','=',$customer_orderid->value)->update(['shipping_addr_id'=>$shipping->id]);
					}
					if($shipping && $billing){
						if($shipping->id==$billing->id){
							Order::where('id','=',$customer_orderid->value)->update(['same_as_billing'=>1]);
						}else{
							Order::where('id','=',$customer_orderid->value)->update(['same_as_billing'=>0]);
						}
					}
					$orderDetails = Order::find($customer_orderid->value);
					$useremail = User::find($orderDetails->profile_id);
					$allAddress = CustAddrBook::where('user_id',$login_user_id->value)->where('status',1)->get();
				}else{
					if($user_id){
						if($orderDetails->profile_id==0 || $orderDetails->profile_id==''){
							Order::where('id','=',$orderDetails->id)->update(['profile_id'=>$user_id->value,'orig_profile_id'=>0]);
						}
						$shipping = CustAddrBook::where('user_id',$user_id->value)->where('default_shipping',1)->first();
						$billing =  CustAddrBook::where('user_id',$user_id->value)->where('default_billing',1)->first();
						if($billing){
							Order::where('id','=',$customer_orderid->value)->update(['billing_addr_id'=>$billing->id]);
						}
						if($shipping){
							Order::where('id','=',$customer_orderid->value)->update(['shipping_addr_id'=>$shipping->id]);
						}
						if($shipping && $billing){
							if($shipping->id==$billing->id){
								Order::where('id','=',$customer_orderid->value)->update(['same_as_billing'=>1]);
							}else{
								Order::where('id','=',$customer_orderid->value)->update(['same_as_billing'=>0]);
							}
						}
						$useremail = User::find($user_id->value);
					}
				}
			}
			
			$orderDetails = Order::find($customer_orderid->value);
			
			if($orderDetails->shipping_addr_id>0){
				$shipping = CustAddrBook::where('id',$orderDetails->shipping_addr_id)->with("country")->first();			
			}
			
			if($orderDetails->billing_addr_id>0){
				$billing =  CustAddrBook::where('id',$orderDetails->billing_addr_id)->with("country")->first();
			}
			
			return response()->json(array('shipping'=>$shipping,'billing'=>$billing,'useremail'=>$useremail,'orderDetails'=>$orderDetails,'allAddress'=>$allAddress,'status'=>'true','statusText'=>'Ok'));
		}
	}
	
	public function getOrderDetails(Request $request){
	
		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		if($sessionData){
			$allAddress = $shipping = $billing = $useremail = $billing_country =  $shiping_country = null;
			
			$sessionId = $sessionData->id;
			if($sessionId){
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$orderDetails = Order::find($customer_orderid->value);
				
				if($login_user_id){
					$orderDetails = Order::find($customer_orderid->value);
					$useremail = User::find($orderDetails->profile_id);
					$allAddress = CustAddrBook::where('user_id',$login_user_id->value)->where('status',1)->get();
				}else{
					if($user_id){
						$useremail = User::find($user_id->value);
					}
				}
			}
			
			$orderDetails = Order::where('id','=',$customer_orderid->value)->with("orderCoupon")->first();
			
			if($orderDetails->shipping_addr_id>0){
				$shipping = CustAddrBook::where('id',$orderDetails->shipping_addr_id)->with("country")->first();
			}
			if($orderDetails->billing_addr_id>0){
				$billing =  CustAddrBook::where('id',$orderDetails->billing_addr_id)->with("country")->first();
			}
			
			return response()->json(array('shipping'=>$shipping,'billing'=>$billing,'useremail'=>$useremail, 'orderDetails'=>$orderDetails,'allAddress'=>$allAddress,'status'=>'true','statusText'=>'Ok'));
		}
	}

	public function updateshippingaddr(Request $request){

		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		$addrid    =  $request->addrid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
			 
		if($sessionData){
			$sessionId = $sessionData->id;
			if($sessionId){
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				CustAddrBook::where('user_id',$login_user_id->value)->update(["default_shipping"=>0]);
				CustAddrBook::where('id',$addrid)->update(["default_shipping"=>1]);
				$orderDetails = Order::find($customer_orderid->value);
				$orderDetails->shipping_addr_id = $addrid;
				if($orderDetails->billing_addr_id==$addrid){
					$orderDetails->same_as_billing = 1;
				}else{
					$orderDetails->same_as_billing = 0;
				}
				$orderDetails->save();
			}
		}
		return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'Ok'));
	}
	
	public function updatebillingaddr(Request $request){

		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		$addrid    =  $request->addrid;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
			 
		if($sessionData){
			$sessionId = $sessionData->id;
			if($sessionId){
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				CustAddrBook::where('user_id',$login_user_id->value)->update(["default_billing"=>0]);
				CustAddrBook::where('id',$addrid)->update(["default_billing"=>1]);
				$orderDetails = Order::find($customer_orderid->value);
				$orderDetails->billing_addr_id = $addrid;
				if($orderDetails->same_as_billing==1){
					$orderDetails->shipping_addr_id = $addrid;
				}else{
					if($orderDetails->shipping_addr_id==$addrid){
						$orderDetails->same_as_billing = 1;
					}else{
						$orderDetails->same_as_billing = 0;
					}
				}
				$orderDetails->save();
			}
		}
		return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'Ok'));
	}
	
	public function updatesameasbilling(Request $request){

		$tokenkey       =  $request->tokenkey;
		$tokenid        =  $request->tokenid;
		$sameasbilling  =  $request->sameasbilling;
		
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
			 
		if($sessionData){
			$sessionId = $sessionData->id;
			if($sessionId){
				$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
				$login_user_id = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
				$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
				$orderDetails = Order::find($customer_orderid->value);
				if($sameasbilling==1){
					if($login_user_id){
						$orderDetails->same_as_billing = 1;
						$orderDetails->shipping_addr_id = $orderDetails->billing_addr_id;
						CustAddrBook::where('user_id',$login_user_id->value)->update(["default_shipping"=>0]);
						CustAddrBook::where('id',$orderDetails->billing_addr_id)->update(["default_shipping"=>1]);

					}
					else if($user_id ){
						$orderDetails->same_as_billing = 1;
						$orderDetails->shipping_addr_id = $orderDetails->billing_addr_id;
						CustAddrBook::where('user_id',$user_id->value)->update(["default_shipping"=>0]);
						CustAddrBook::where('id',$orderDetails->billing_addr_id)->update(["default_shipping"=>1]);

					}
					
				}else{

					$orderDetails->same_as_billing = 0;
					$orderDetails->shipping_addr_id = 0;


				if($login_user_id){
					CustAddrBook::where('user_id',$user_id->value)->update(["default_shipping"=>0]);

					}
					else if($user_id ){
						CustAddrBook::where('user_id',$user_id->value)->update(["default_shipping"=>0]);

					}	
				}
				
				$vat = Vat::find(1);
				$vatCountry = explode(",",$vat->vat_countries);
				$vatprice = $vat->price;
				
				if($orderDetails->same_as_billing==1){
					if($orderDetails->billing_addr_id > 0){
						$cusaddr = CustAddrBook::find($orderDetails->billing_addr_id);
						$country_id = $cusaddr->country_id;
						if(in_array($country_id,$vatCountry)){
							$orderDetails->vat = $vatprice;
						}else{
							$orderDetails->vat = 0;
						}
					}
				}elseif($orderDetails->same_as_billing==0){
					if($orderDetails->shipping_addr_id > 0){
						$cusaddr = CustAddrBook::find($orderDetails->shipping_addr_id);
						$country_id = $cusaddr->country_id;
						if(in_array($country_id,$vatCountry)){
							$orderDetails->vat = $vatprice;
						}else{
							$orderDetails->vat = 0;
						}
					}
				}
				
				$orderDetails->save();
				CartController::recalculateOrderTotal($customer_orderid->value);
			}
		}
		return response()->json(array('message'=>'updated successfully','status'=>'true','statusText'=>'Ok'));
	}

	public function storeAbandonedCartdata(Request $request){

				$aa = 	new CommonController;
				$userdata =  $aa->checkRequest($request);
                if($userdata)
                {
        			

                 $order =  AbandonedCart::where('order_id',$userdata['user_session_data']['customer_orderid'])->count();
                 if($order<1){
                 	$abondone = new AbandonedCart;
					$abondone->order_id = $userdata['user_session_data']['customer_orderid'];
					$abondone->save();
                return response()->json(array('message'=>'order save successfully','status'=>'true','statusText'=>'Ok'));;
             
                }
            
                  }else{

					 return response()->json(array('message'=>'token does not match','status'=>'false','statusText'=>'Error'));;
                  }
			

	}


	public function newsLetterSubscribe(Request $request){
	
		$tokenkey    =  $request->tokenkey;
		$tokenid    =  $request->tokenid;
		$status    =  $request->status;
		
		$sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		if($sessionData){
		
		   $sessionId = $sessionData->id;
		
		$user_id = CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionId)->first();
		$login_user_id    = CustomerSessionData::where('name','=','login_user_id')->where('sid','=',$sessionId)->first();
	 
		if($login_user_id){
		
		    $user = User::find($login_user_id->value);
			$email = $user->email;
			$fname = $user->fname;
			$lname = $user->lname;
			

		}else{
		
			$user =  User::find($user_id->value);
			$email = $user->email;
			$fname = $user->fname;
			$lname = $user->lname;

		}
			
		$Exist = Subscriber::where('email',$email)->get();
		
		if(count($Exist)>0){
		      $data1= array('status' => $status );
		         Subscriber::where('id',$Exist[0]->id)->update($data1);
		         return response()->json(array('message'=>'subscribe updated successfully','status'=>'true'));;
		}else{
		
			$s  =  new Subscriber;
			$s->first_name = $fname;
			$s->last_name = $lname;
			$s->email = $email;
			$s->status = $status;
			$s->save();

			return response()->json(array('message'=>'subscribe successfully','status'=>'true'));
		}
        
	}else {
		return response()->json(array('message'=>'token does not match','status'=>'false','statusText'=>'Error'));;
	}
	
  }
  
  public function getOrderId(Request $request){
  
        $tokenkey    =  $request->tokenkey;
		$tokenid     =  $request->tokenid;
		
		
		$sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		if($sessionData){
		
		      $customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionData->id)->first();
			  if($customer_orderid){
			  
		       return response()->json(array('orderId'=>$customer_orderid->value,'status'=>'true'));
			}else{
			
			return response()->json(array('orderId'=>'','status'=>'false','statusText'=>'Error'));;
			}
			
		}else {
			return response()->json(array('message'=>'token does not match','status'=>'false','statusText'=>'Error'));;
		}
  
  }
  
	public function initiatePayment(Request $request){
		
		$tokenkey =  $request->tokenkey;
		$tokenid =  $request->tokenid;
		$methodId =  $request->methodId;
		$sessionData = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();
		$sessionId = $sessionData->id;
		
		if($sessionId){
			$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
			$order_id = $customer_orderid->value;
			$orderDetails = Order::find($order_id);
			$userDetails = User::find($orderDetails->profile_id);
			$paymentMDetails = PaymentMethod::find($methodId);
			$author_id = $userDetails->id;
			
			//--- SAVE PAYMENT HISTORY (Change payment status) -----------//
			$code_key = 'change_payment_status';
			$description = NULL;
			if($orderDetails->payment_status_id>0 && $orderDetails->payment_status_id!=1){
				$pstatus = Payment::find($orderDetails->payment_status_id);
				$code = 'Order payment status changed from '.$pstatus->name.' to Awaiting payment';
				$olddata = $pstatus->name;
				$newdata = 'Awaiting payment';
			}else{
				$code = 'Order payment status changed to Awaiting payment';
				$olddata = NULL;
				$newdata = 'Awaiting payment';
			}
			OrderHistoryController::saveOrderHistoryByOrderId($order_id, $author_id, $code_key, $code, $description, $olddata, $newdata);
			
			//--- SAVE PAYMENT HISTORY (Payment in process) -----------//
			
			$code_key = 'initiate_payment_progress';
			$code = 'Payment has been initiated by customer('.$userDetails->email.')';
			$description = 'Payment transaction [method: '.$paymentMDetails->name.', type: sale, amount: '.$orderDetails->total.', status: In progress]';
			$olddata = NULL;
			$newdata = NULL;
			OrderHistoryController::saveOrderHistoryByOrderId($order_id, $author_id, $code_key, $code, $description, $olddata, $newdata);
			return response()->json(array('status'=>true));
		}else{
			return response()->json(array('status'=>false));
		}
	}
	
	public function removeOrderIdAfterConfirm(Request $request){
		$tokenkey =  $request->tokenkey;
		$tokenid =  $request->tokenid;
		$sessionData = CustomerSession::select('id') ->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		if($sessionData){
			CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionData->id)->delete();
			CustomerSessionData::where('name','=','user_id')->where('sid','=',$sessionData->id)->delete();
			return response()->json(array('status'=>true));
		}else{
			return response()->json(array('status'=>false));
		}
	}
	
	public function updateVat(Request $request){
		$tokenkey =  $request->tokenkey;
		$tokenid =  $request->tokenid;
		$country_id =  $request->country_id;
		$type =  $request->type;

		$sessionData = CustomerSession::select('id') ->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		if($sessionData){
			$sessionId = $sessionData->id;
			$customer_orderid = CustomerSessionData::where('name','=','customer_orderid')->where('sid','=',$sessionId)->first();
			$order_id = $customer_orderid->value;
			$orderDetails = Order::find($order_id);

			$vat = Vat::find(1);
			$vatCountry = explode(",",$vat->vat_countries);
			$vatprice = $vat->price;
			
			if($type=='bill'){
				if($orderDetails->same_as_billing==1){
					if(in_array($country_id,$vatCountry)){
						$orderDetails->vat = $vatprice;
					}else{
						$orderDetails->vat = 0;
						
					}
					$orderDetails->save();
				}
				if($orderDetails->billing_addr_id > 0){
					$cusaddr = CustAddrBook::find($orderDetails->billing_addr_id);
					$cusaddr->country_id = $country_id;
					$cusaddr->save();
				}
			}elseif($type=='ship'){
				if(in_array($country_id,$vatCountry)){
					$orderDetails->vat = $vatprice;
				}else{
					$orderDetails->vat = 0;
				}
				$orderDetails->save();
				if($orderDetails->shipping_addr_id > 0){
					$cusaddr = CustAddrBook::find($orderDetails->shipping_addr_id);
					$cusaddr->country_id = $country_id;
					$cusaddr->save();
				}
			}
			CartController::recalculateOrderTotal($order_id);
			return response()->json(array('status'=>true));
		}else{
			return response()->json(array('status'=>false));
		}
		
	}
	public function dynamicjsontoken(Request $request){

   		$tokenkey    =  $request->tokenkey;
		$tokenid     =  $request->tokenid;
		$userid     =  $request->tokenvalue;
		
		$sessionData = CustomerSession::select('id')->where('id',$tokenid)->where('custome_token',$tokenkey)->first();
		if($sessionData){
		    $customer =  new CustomerSessionData;
			$customer->name = 'login_user_id';
			$customer->sid = $tokenid;
			$customer->value = $userid;
			$customer->save();
			if($customer){
			      return response()->json(array('message'=>'successfully generate token','status'=>'true','statusText'=>'Success'));
			}
		
		}else {
			return response()->json(array('tokenkey'=>$tokenkey,'tokenid'=>$tokenid,'userid'=>$userid));
		}

 }
}
