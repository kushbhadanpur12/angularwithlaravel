<?php

namespace App\Http\Controllers\AngularControllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Category;
use App\Product;
use App\Staticpages;
use \Cache;
use DB;

class SearchController extends Controller
{
    //
	public function index()
    {
        return view('angelic.mainCategory');
    }

    public function quickSearch(Request $request)
    {
		$searchTerm = $searchStr = $request->input('search');
		$searchStr = explode(" ",$searchStr);
		
        //$categories = Category::inRandomOrder()->where('parent_id',1)->get()->take(6);
		
		$q = Category::with(["clean"]);
		if(isset($searchStr)){
			if(count($searchStr)>0){
				$q->where(function ($q)  use ($searchStr){
					foreach ($searchStr as $key => $value) {
						$q->where('name', 'like', $value.'%');
						$q->orWhere('name', 'like', '% '.$value.'%');
						$q->orWhere('description', 'like', $value.'%');
						$q->orWhere('description', 'like', '% '.$value.'%');
					}
				});
			}
        }
		$q->where('id','!=',1);
		$categories = $q->offset(0)->limit(3)->get();
		
		$q = Staticpages::with(["clean"]);
		if(isset($searchStr)){
			if(count($searchStr)>0){
				$q->where(function ($q)  use ($searchStr){
					foreach ($searchStr as $key => $value) {
						$q->where('name', 'like', $value.'%');
						$q->orWhere('name', 'like', '% '.$value.'%');
						$q->orWhere('description', 'like', $value.'%');
						$q->orWhere('description', 'like', '% '.$value.'%');
					}
				});
			}
        }
		$q->where('id','!=',1);
		$pages = $q->offset(0)->limit(3)->get();
		
		$q = Product::select("products.*");
		$q->with(["ProductImages","ProductUrl"]);
		if(isset($searchStr)){
			if(count($searchStr)>0){
				$q->where(function ($q)  use ($searchStr){
					foreach ($searchStr as $key => $value) {
						$q->where('name', 'like', $value.'%');
						$q->orWhere('name', 'like', '% '.$value.'%');
						$q->orWhere('sku', 'like', $value.'%');
						$q->orWhere('sku', 'like', '% '.$value.'%');
						$q->orWhere('short_desc', 'like', $value.'%');
						$q->orWhere('short_desc', 'like', '% '.$value.'%');
						$q->orWhere('full_desc', 'like', $value.'%');
						$q->orWhere('full_desc', 'like', '% '.$value.'%');
					}
				});
			}
        }
		$allproductData = $q->orderBy('ordering','ASC')->offset(0)->limit(10)->get();
		//dd($allproductData);
		$count = count($categories) + count($allproductData) + count($pages);
        $response = $categories;
        //return response()->json($response,200);
		return response()->json(['categories'=>$categories, 'pages'=>$pages, 'products'=>$allproductData, 'searchTerm'=>$searchTerm, 'count'=>$count, 'categoriesCount'=>count($categories), 'productCount'=>count($allproductData), 'pageCount'=>count($pages)]);
    }

    /*//public function Filter(Request $request)
    public function Filter(Request $request)
    {
        $search = $request->input('search');
		
        //$categories = Category::Where('name','like', '%'.$search.'%')->get();
        $categories = Cache::remember('xc_products', 22*60, function() {
            return DB::table("xc_products")->where('metal_name','like', '%'.$search.'%')->get();
        });
    	$products = Product::Where('name','like', '%'.$search.'%')->get();
    	$response = [
            'categories' =>$categories,
            'products'  => $products
        ];

        return response()->json($response,201);
    }

    /////////////Test purpose
    public function testFilter(Request $request)
    {
        $search = $request->input('search');
        $categories = DB::table('xc_products')
                                ->Where('metal_name','like', '%'.$search.'%')
                                ->orWhere('h1_title','like', '%'.$search.'%')
                                ->orWhere('group_name','like', '%'.$search.'%')
                                 ->limit(10)
                                ->get();
                            
                            //
                            //
                            
        // $categories = Cache::remember('categories', 22*60, function() {
        //     return Category::Where('name','like', '%'.$search.'%')->get();
        // });
       // $products = Product::Where('name','like', '%'.$search.'%')->get();
        $response = [
            'categories' =>$categories,
            //'products'  => $products
        ];

        return response()->json($response,201);
    }*/
	
	public function combinations($arrays, $i = 0) {
		if (!isset($arrays[$i])) {
			return array();
		}
		if ($i == count($arrays) - 1) {
			return $arrays[$i];
		}
	
		// get combinations from subsequent arrays
		$tmp = $this->combinations($arrays, $i + 1);
	
		$result = array();
	
		// concat each array from tmp with each element from $arrays[$i]
		foreach ($arrays[$i] as $v) {
			foreach ($tmp as $t) {
				$result[] = is_array($t) ? 
					array_merge(array($v), $t) :
					array($v, $t);
			}
		}
	
		return $result;
	}
	
	public function getSearchStr(Request $request)
    {
		$searchTerm = $searchStr = $request->input('searchStr');
		$searchStr = explode(" ",$searchStr);
		
		$attr_opt = $request->input('attr_opt');
		$sortby = $request->input('sortby');
		$perPage = $request->input('perPage');
		$page = $request->input('page');
		
		
		$rtOptVal = $checkPIDExist = $combinations = $optionsVals = array();
		
		if($attr_opt!=''){
			$attr_opt2 = array_filter(explode(":",$attr_opt));
			foreach($attr_opt2 as $key=>$val){
				$aa = explode(",",$val);
				$optionsVals[$aa[0]][] = $aa[1];
				$rtOptVal[] = intval($aa[1]);
			}
			$optionsVals = array_values($optionsVals);
			$combinations = $this->combinations($optionsVals);
		}
		
		if(count($optionsVals)>1){
			if(count($combinations)>0){
				$fetchOIDetails = 'SELECT  A.products_id FROM product_attributes A Where ';
				$counter = 1;
				foreach($combinations as $com){
					$fetchOIDetails .= '(';
					foreach($com as $OPT){
						$fetchOIDetails .= ' Exists
											(
												Select  *
												From    product_attributes  B
												Where   A.products_id = B.products_id
												And     B.options_id = '.$OPT.'
											)
											And ';
					}
					$fetchOIDetails .= '1 ) ';
					if($counter<count($combinations)){
						$fetchOIDetails .= 'OR';
					}
					$counter++;
				}
				$fetchOIDetails .= ' AND 1 GROUP BY A.products_id';
				$checkPIDExist = DB::select($fetchOIDetails);
				$checkPIDExist = json_decode(json_encode($checkPIDExist), true);
				$checkPIDExist = array_map('current', $checkPIDExist);
			}
		}elseif(count($optionsVals)>0){
			$optionsVals = array_shift($optionsVals);
			$fetchOIDetails = 'SELECT  A.products_id FROM product_attributes A Where ';
			$counter = 1;
			foreach($optionsVals as $com){
				$fetchOIDetails .= ' A.options_id='.$com;
				if($counter<count($optionsVals)){
					$fetchOIDetails .= ' OR ';
				}
				$counter++;
			}
			
			$checkPIDExist = DB::select($fetchOIDetails);
			$checkPIDExist = json_decode(json_encode($checkPIDExist), true);
			$checkPIDExist = array_map('current', $checkPIDExist);
		}
		
		
		if($sortby!=''){
			$sortby2 = explode("-",$sortby);
		}else{
			$sortby2[0] = 'name';
			$sortby2[1] = 'ASC';
			$sortby = 'recommended-asc';
		}
		
		$metalOPT = array(1,2,3,4,5,6,7,8);
		$metaltrue = 0;
		
		$style_id   = 10;
		$metal_id   = 1;
		$stone_id   = 2;
		$shape_id   = 11;
		$mens_id    = 16;
		$ladies_id  = 17;
		
		$q = Product::select("products.*");
		
		/*if(isset($searchStr)){
			if(count($searchStr)>0){
				$q->where(function ($q)  use ($searchStr){
					foreach ($searchStr as $key => $value) {
						$q->selectRaw("MATCH(name) against ('".$value."' IN BOOLEAN MODE) AS relevance");
					}
				});
			}
        }*/
		//$q->selectRaw("MATCH(name) against ('".$searchTerm."' IN BOOLEAN MODE) AS relevance");
		$q->with(["ProductImages","ProductUrl"]);
		
		if(isset($searchStr)){
			if(count($searchStr)>0){
				$q->where(function ($q)  use ($searchStr){
					foreach ($searchStr as $key => $value) {
						$q->where('name', 'like', $value.'%');
						$q->orWhere('name', 'like', '% '.$value.'%');
						$q->orWhere('sku', 'like', $value.'%');
						$q->orWhere('sku', 'like', '% '.$value.'%');
						$q->orWhere('short_desc', 'like', $value.'%');
						$q->orWhere('short_desc', 'like', '% '.$value.'%');
						$q->orWhere('full_desc', 'like', $value.'%');
						$q->orWhere('full_desc', 'like', '% '.$value.'%');
					}
				});
			}
        }
		
		
		if(count($checkPIDExist)>0){
			$q->whereIn('products.id',$checkPIDExist);
		}
		
		//Product::where('enabled','=',1)->where('name','like','%'.$searchStr.'%')->orderBy($sortby2[0],$sortby2[1])->with(["ProductImages","ProductUrl"])->paginate(48);
		
		/*$allproductData = $q->orderBy('relevance','DESC')->toSql();
		print_r($allproductData);die;*/
		
		if($sortby2[0]=='price'){
			$allproductData = $q->orderBy($sortby2[0],$sortby2[1])->orderBy('ordering','ASC')->paginate($perPage);
		}else{
			$allproductData = $q->orderBy('ordering','ASC')->paginate($perPage);
		}
		//print_r($allproductData->lastPage());die;
		$morepages = array();
		if($page==1 || $page==2 || $page==3){
			$morepages[] = 2;
			$morepages[] = 3;
			$morepages[] = 4;
			$morepages[] = 5;
			$morepages[] = 6;
		}
		if($page > 3 && $page < ($allproductData->lastPage()-2)){
			$morepages[] = $page-2;
			$morepages[] = $page-1;
			$morepages[] = $page;
			$morepages[] = $page+1;
			$morepages[] = $page+2;
		}
		if($page==($allproductData->lastPage()-2) || $page==($allproductData->lastPage()-1) || $page==$allproductData->lastPage()){
			$morepages[] = $allproductData->lastPage()-5;
			$morepages[] = $allproductData->lastPage()-4;
			$morepages[] = $allproductData->lastPage()-3;
			$morepages[] = $allproductData->lastPage()-2;
			$morepages[] = $allproductData->lastPage()-1;
		}
		
		//print_r($allproductData);die;
		return response()->json(['products'=>$allproductData, 'searchTerm'=>$searchTerm, 'sortby'=>$sortby, 'perPage'=>$perPage, 'rtOptVal'=>$rtOptVal, 'morepages'=>$morepages]);
 
   	}
}
