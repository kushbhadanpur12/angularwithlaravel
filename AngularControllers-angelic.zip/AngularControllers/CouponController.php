<?php

namespace App\Http\Controllers\AngularControllers;

use App\Http\Controllers\AngularControllers\CartController;
use App\Product;
use App\Wishlist;
use App\ProductAttribute;
use App\Order;
use App\OrderItem;
use App\OrderItemAttributeValue;
use App\Currency;
use App\CustomerSession;
use App\CustomerSessionData;
use App\ProductVariants;
use App\AttributesOptionModel;
use App\AbandonedCart;
use App\Coupon;
use App\OrderCoupon;
use App\CategoryProduct;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use DB;

class CouponController extends Controller
{
	public function applyCoupon(Request $req){
		
		$tokenid  = $req->tokenid;
		$tokenkey = $req->tokenkey;
		$couponcode = $req->couponcode;
		
		$couponcode_exist = Coupon::where(DB::raw('BINARY `code`'),$couponcode)
			 ->where('enabled',1)
			 ->first();
		
		$custmer_exist = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();

		 if($custmer_exist && $couponcode_exist){
		 
			 $custmerOrder = CustomerSessionData::select('value')->where('sid',$custmer_exist->id)->where('name','customer_orderid')->first();
			 $orderId =  $custmerOrder->value;
			 
			 if($orderId){
				$OrderDetails =  Order::find($orderId);
				$findOrderCoupon = OrderCoupon::where('order_id','=',$orderId)->where(DB::raw('BINARY `code`'),$couponcode)->first();

				if(!$findOrderCoupon){

					if($couponcode_exist){

						if(time() > strtotime($couponcode_exist->active_to)){
							return response()->json(array('message'=>'This coupon has been expired ', 'status'=>'false', 'statusCode'=>403));
						}elseif($OrderDetails->total < $couponcode_exist->subtotal_start){
							return response()->json(array('message'=>'This coupon can be applied only to orders with a subtotal amount of at least '.number_format($couponcode_exist->subtotal_start,2), 'status'=>'false', 'statusCode'=>403));
						}elseif($OrderDetails->total > $couponcode_exist->subtotal_end){
							return response()->json(array('message'=>'This coupon can be applied only to orders with a subtotal amount not exceeding '.number_format($couponcode_exist->subtotal_end,2), 'status'=>'false', 'statusCode'=>403));
						}elseif($OrderDetails->total >= $couponcode_exist->subtotal_start && $OrderDetails->total <= $couponcode_exist->subtotal_end){

							$alldata =  OrderItem::where('order_id',$orderId)->get();
							$discountProd = array();
							
							 $availableCategories = array_unique(explode(",",$couponcode_exist->categories));
							 foreach($alldata as $item){
							 	$CategoryProduct = CategoryProduct::where('product_id',$item->object_id)->get();
								foreach ($CategoryProduct as $ct) {
									if(in_array($ct->category_id,$availableCategories)){
										$discountProd[] = $item->object_id;
									}
								}
							 }
							 $discountProd = array_unique($discountProd);
   		            		if(count($availableCategories) > 0 && count($discountProd)==0){
								return response()->json(array('message'=>'Sorry, the coupon you entered cannot be applied to the items in your cart ', 'status'=>'false','statusCode'=>403));
   		            		}elseif(count($availableCategories) > 0 && count($discountProd) > 0){
								$addcounpon = new OrderCoupon;
								$addcounpon->order_id = $orderId;
								$addcounpon->coupon_id = $couponcode_exist->id;
								$addcounpon->code = $couponcode_exist->code;
								$addcounpon->value = $couponcode_exist->discount_amount;
								$addcounpon->type = $couponcode_exist->discount_type;
								$addcounpon->save();
								
								CartController::recalculateOrderTotal($orderId);
								
								return response()->json(array('message'=>'success','status'=>'true','statusText'=>'Ok','statusCode'=>200));
							}elseif(count($availableCategories)==0){
								$addcounpon = new OrderCoupon;
								$addcounpon->order_id = $orderId;
								$addcounpon->coupon_id = $couponcode_exist->id;
								$addcounpon->code = $couponcode_exist->code;
								$addcounpon->value = $couponcode_exist->discount_amount;
								$addcounpon->type = $couponcode_exist->discount_type;
								$addcounpon->save();
								
								CartController::recalculateOrderTotal($orderId);
								
								return response()->json(array('message'=>'success','status'=>'true','statusText'=>'Ok','statusCode'=>200));
							}
						}
					}else{
						return response()->json(array('message'=>'Invalid coupon code, please check the spelling: "'.$couponcode.'"', 'status'=>'false','statusCode'=>403));
					}
				}else{
					return response()->json(array('message'=>'Coupon already added.','status'=>'false','statusText'=>'Error','statusCode'=>403));
				}
			 }else{
                 return response()->json(array('message'=>'order not placed','status'=>'false','statusText'=>'Error','statusCode'=>403));		
			 }
		 }else{
            return response()->json(array('message'=>'Invalid coupon code, please check the spelling: "'.$couponcode.'"', 'status'=>'false','statusText'=>'Error','statusCode'=>403));		
		 }
	}
	
	public function removeCoupon(Request $req){
		
		$tokenid  = $req->tokenid;
		$tokenkey = $req->tokenkey;
		$couponid = $req->couponid;
		
		$couponcode_exist = OrderCoupon::find($couponid);
		
		$custmer_exist = CustomerSession::select('id')
			 ->where('id',$tokenid)
			 ->where('custome_token',$tokenkey)
			 ->first();

		 if($custmer_exist && $couponcode_exist){
			 $custmerOrder = CustomerSessionData::select('value')->where('sid',$custmer_exist->id)->where('name','customer_orderid')->first();
			 $orderId =  $custmerOrder->value;
			 
			 if($orderId){
				$removeOrderCoupon =  OrderCoupon::where('order_id','=',$orderId)->where('id','=',$couponid)->delete();
				OrderItem::where('order_id','=',$orderId)->update(array('discountedSubtotal'=>DB::raw('price')));
				CartController::recalculateOrderTotal($orderId);
				return ' success';
			 }else{
               return 'order not placed';
			 }
		 }else{
           return 'customer does not exist';

		 }
	}

}